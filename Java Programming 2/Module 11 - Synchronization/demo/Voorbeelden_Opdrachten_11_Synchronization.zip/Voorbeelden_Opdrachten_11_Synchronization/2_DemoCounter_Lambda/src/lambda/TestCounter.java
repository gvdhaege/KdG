package lambda;

public class TestCounter {
    public static void main(String[] args) {
        Counter counter = new Counter();

        // Aan te vullen!


        // Verwachte uitvoer: Value = 0
        System.out.println("Value = " + counter.value());
    }
}

