package immutable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Person {
    private String name;
    private int age;
    private Address address;
    private List<String> friends;

    public Person(String name, int age, Address address, List<String> friends) {
        this.name = name;
        this.age = age;
        this.address = address;
        this.friends = friends;
    }

    public Address getAddress() {
        return address;
    }

    public List<String> getFriends() {
        return friends;
    }

    @Override
    public String toString() {
        return String.format("%s (age %d)\n\tAdress: %s\n\tFriends: %s",
                name, age, address, friends);
    }
}
