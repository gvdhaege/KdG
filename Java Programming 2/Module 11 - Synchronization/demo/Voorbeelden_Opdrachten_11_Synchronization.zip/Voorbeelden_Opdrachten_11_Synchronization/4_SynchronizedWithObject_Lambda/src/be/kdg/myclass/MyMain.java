package be.kdg.myclass;

public class MyMain {
    public static void main(String[] args) {
        // Aan te vullen

    }
}
