
package be.kdg.dubbeltellen;

public class DubbelTellen {
    public static void main(String[] args) {
        Runnable teller = new Runnable() {
            public synchronized void run() {
                for (int i = 1; i <= 10; i++) {
                    System.out.print(i + " ");
                    try {
                        Thread.sleep(200);
                    } catch (InterruptedException e) {
                        throw new RuntimeException(e);
                    }
                }
            }
        };
        new Thread(teller).start();
        new Thread(teller).start();
    }
}

