package synchronization;

public class Carwash {
    private boolean bezet = false;

    public synchronized void aankomstWagen(int nr) {
        if (bezet) {
            System.out.println("Wagen nr " + nr + " moet wachten!");
            try {
                wait(); //wachten op een notify of notifyAll
            }
            catch (InterruptedException e) {
                // leeg
            }
        }
        bezet = true;
    }

    public synchronized void vertrekWagen(int nr) {
        System.out.println("Wagen nr " + nr + " klaar");
        bezet = false;
        notify();  //om een thread die in wait-modus staat te verwittigen
    }
}
