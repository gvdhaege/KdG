package synchronization;

public class Carwash {
    public static final int MAXAANTAL = 3;
    private int bezetting = 0;

    public synchronized void aankomstWagen(int nr) {
        if (bezetting == MAXAANTAL) {
            System.out.println("Wagen nr " + nr + " moet wachten!");
            try {
                wait();
            } catch (InterruptedException e) {  // leeg
            }
        }
        ++bezetting;
    }

    public synchronized void vertrekWagen(int nr) {
        System.out.println("Wagen nr " + nr + " klaar");
        --bezetting;
        notifyAll();
    }
}
