package synchronization;

/**
 * @author Kristiaan Behiels
 * @version 1.0 10/12/11
 */
public class RunCarwashDuo {
    public static void main(String[] args) {
        Carwash carwash = new Carwash();

        Car[] cars = {
                new Car(1, 0, carwash),
                new Car(2, 1, carwash),
                new Car(3, 1, carwash),
                new Car(4, 2, carwash),
                new Car(5, 3, carwash),
                new Car(6, 5, carwash),
                new Car(7, 7, carwash),
                new Car(8, 8, carwash),
                new Car(9, 9, carwash)
        };

        for (Car car : cars) {
            new Thread(car).start();
        }
    }
}

/*
Wagen nr 1 komt aan.
Start wagen nr 1
Wagen nr 3 komt aan.
Start wagen nr 3
Wagen nr 2 komt aan.
Wagen nr 2 moet wachten!
Wagen nr 1 klaar
Start wagen nr 2
Wagen nr 4 komt aan.
Wagen nr 4 moet wachten!
Wagen nr 3 klaar
Start wagen nr 4
Wagen nr 5 komt aan.
Wagen nr 5 moet wachten!
Wagen nr 2 klaar
Start wagen nr 5
Wagen nr 4 klaar
Wagen nr 5 klaar
Wagen nr 6 komt aan.
Start wagen nr 6
Wagen nr 6 klaar
Wagen nr 7 komt aan.
Start wagen nr 7
Wagen nr 8 komt aan.
Start wagen nr 8
Wagen nr 7 klaar
Wagen nr 9 komt aan.
Start wagen nr 9
Wagen nr 8 klaar
Wagen nr 9 klaar
*/