package immutable;

import java.util.ArrayList;
import java.util.List;

public final class Person {
    private final String name;
    private final int age;
    private final Adress adress;
    private final List<String> friends;

    public Person(String name, int age, Adress adress, List<String> friends) {
        this.name = name;
        this.age = age;
        this.adress = new Adress(adress.getStreet(), adress.getZip(), adress.getCity());
        this.friends = new ArrayList<>(friends);
    }

    public String getName() {
        return this.name;
    }

    public int getAge() {
        return this.age;
    }

    /*
    Zeker geen setters in een immutable class!

    public void setName(String name) {
        this.name = name;
    }

    public void setAge(int age) {
        this.age = age;
    }


    public void setAdress(Adress adress) {
        this.adress = adress;
    }
    */

    public Adress getAdress() {
        return new Adress(adress.getStreet(), adress.getZip(), adress.getCity());
    }

    public List<String> getFriends() {
        return new ArrayList<>(friends);
    }

    @Override
    public String toString() {
        return String.format("%s (age %d)\n\tAdress: %s\n\tFriends: %s",
                name, age, adress, friends);
    }
}
