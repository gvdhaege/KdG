package immutable;

import java.util.ArrayList;
import java.util.List;

/**
 * Mark Goovaerts
 * 18/11/2014
 */
public class DemoPerson {
    public static void main(String[] args) {
        Adress adress1 = new Adress("Pennsylvania Avenue", 1600, "Washington DC");
        List<String> list1 = new ArrayList<>();
        list1.add("Michelle Obama");
        list1.add("Joe Biden");
        list1.add("Hillary Clinton");
        Person per = new Person("Barack Obama",53, adress1, list1);

        //Controle afdruk:
        System.out.println("Na aanmaak:");
        System.out.println(per);

        //Proberen te wijzigen:
        Adress adress2 = per.getAdress();
        adress2.setStreet("Nationalestraat 5");
        adress2.setZip(2000);
        adress2.setCity("Antwerpen");
        List<String> list2 = per.getFriends();
        list2.clear();
        list2.add("Vladimir Poetin");

        //Controle afdruk:
        System.out.println("Na poging tot wijziging:");
        System.out.println(per);
    }
}

/*
Verwachte afdruk:
Na aanmaak:
Barack Obama (age 53)
	Adress: Pennsylvania Avenue, 1600 Washington DC
	Friends: [Michelle Obama, Joe Biden, Hillary Clinton]
Na poging tot wijziging:
Barack Obama (age 53)
	Adress: Pennsylvania Avenue, 1600 Washington DC
	Friends: [Michelle Obama, Joe Biden, Hillary Clinton]
 */