package be.kdg.overdruk;

public class Besturing extends Thread {
    private static final int TOENAME = 15;

    public static synchronized void verhoogDruk(int toename) { // static gemaakt!
        if (Stoomketel.getDrukWaarde()	< Stoomketel.getAlarmWaarde() - TOENAME) {
            try {
                sleep(100);
            } catch (InterruptedException e) {
                // negeer
            }
            Stoomketel.verhoogDruk(toename);
        }
    }

    public void run() {
        verhoogDruk(TOENAME);
    }
}
