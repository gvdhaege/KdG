package deadlock;

public class WisselVriendin {
    public static void main(String args[]) {
        String vEen = "Jane";
        String vTwee = "Lucy";

        Runnable sEen = new Student("John", vEen, vTwee);
        Runnable sTwee = new Student("Mike", vTwee, vEen);

        Thread threadEen = new Thread(sEen);
        Thread threadTwee = new Thread(sTwee);

        threadEen.start();
        threadTwee.start();
    }
}

// Verwachte uitvoer:
/*
John belt Jane
Mike belt Lucy
John maakt het af met Jane
Mike maakt het af met Lucy
John belt Lucy
Mike belt Jane
Mike vraagt het aan bij Jane
Mike heeft een nieuwe vriendin.
John vraagt het aan bij Lucy
John heeft een nieuwe vriendin.
*/