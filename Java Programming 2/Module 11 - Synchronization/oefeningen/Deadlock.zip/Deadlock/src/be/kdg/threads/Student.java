package be.kdg.threads;

/**
 * @author Jan de Rijke.
 */
public class Student implements Runnable {
	private final String naam;
	private final String oudLief;
	private final String nieuwLief;
	public Student(String naam, String oudLief, String nieuwLief) {
		this.naam = naam;
		this.oudLief = oudLief;
		this.nieuwLief = nieuwLief;
	}
	public void run() {
		System.out.println(naam + " belt " + oudLief);
		synchronized (oudLief) {
			System.out.println(naam + " dumpt " + oudLief);
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
// negeer
			}
			System.out.println(naam + " belt " + nieuwLief);
			synchronized (nieuwLief) {
				System.out.println(naam + " vraagt het aan bij "
					+ nieuwLief);
			}
		}
		System.out.println(naam + " heeft een nieuw lief.");
	}
}

