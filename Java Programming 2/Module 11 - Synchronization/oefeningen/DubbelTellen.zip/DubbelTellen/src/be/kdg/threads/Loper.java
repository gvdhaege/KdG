package be.kdg.threads;

/**
 * @author Jan de Rijke.
 */
class Loper implements Runnable {
	Teller teller;

	public Loper(Teller teller) {
		this.teller=teller;
	}

	@Override
	public void run() {
		try {
			Thread.sleep(200);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		teller.tel();
	}
}
