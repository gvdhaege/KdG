package be.kdg.threads;

public class DubbelTellen {

    public static void main(String[] args) {
			Runnable loper = new Loper(new Teller(10));
			Thread t1 = new Thread(loper);
			t1.start();
	    Thread t2 = new Thread(loper);
	    t2.start();

    }

}
