package be.kdg.threads;

/**
 * @author Jan de Rijke.
 */
public class Teller {
	private int tot;
	public Teller(int max) {
		tot=max;
	}

	public void tel(){
		for (int i = 1; i <= tot; i++) {
			System.out.print(i + " ");
		}
	}
}
