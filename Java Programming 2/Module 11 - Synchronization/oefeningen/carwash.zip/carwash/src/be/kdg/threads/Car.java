package be.kdg.threads;

/**
 * @author Jan de Rijke.
 */
	public class Car implements Runnable {
		private int wagenNummer;
		private int aankomstTijd;
		private Carwash carwash;
		public Car(int wagenNr, int aankomstTijd, Carwash carwash) {
			wagenNummer = wagenNr;
			this.aankomstTijd = aankomstTijd;
			this.carwash = carwash;
		}
		public void run() {
			try {
				Thread.sleep(1000 * aankomstTijd);
				System.out.println("Wagen nr " + wagenNummer + " komt aan.");
				carwash.aankomstWagen(wagenNummer);
				// wastijd
				Thread.sleep(1600);
				carwash.vertrekWagen(wagenNummer);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
