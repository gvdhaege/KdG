package be.kdg.threads;

/**
 * @author Jan de Rijke.
 */
public class Carwash {
	// TODO: zorg er voor dat er slechts 1 wagen tegelijk in de carwash kan

	// TODO: als de carwash bezet is, druk je af welke wagen moet wachten
	// druk af als je de wagen begint te wassen (+ zijn nummer)

	public void aankomstWagen(int wagenNummer) {
	}
	// TODO: Druk af dat de wagen klaar is
	public void vertrekWagen(int wagenNummer) {

	}
}
