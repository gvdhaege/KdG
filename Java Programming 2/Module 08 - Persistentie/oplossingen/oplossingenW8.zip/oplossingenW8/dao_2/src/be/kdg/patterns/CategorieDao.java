package be.kdg.patterns;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Set;

public class CategorieDao extends HsqlDao {
    private ProductDao productDao;

    public CategorieDao(ProductDao productDao) {
        this.productDao = productDao;
        laadDriver();
        Connection connection = maakConnectie();
        Statement statement = maakStatement(connection);
        maakTabel(statement);
        sluitStatementEnConnectie(statement, connection);
    }

    private void maakTabel(Statement statement) {
        try {
            statement.execute("CREATE TABLE categorieen (id INTEGER IDENTITY, naam CHAR(20))");
        } catch (SQLException e) {
            // no problem, table already exists
        }
    }

    public boolean clear() {
        Connection connection = null;
        Statement statement = null;
        try {
            connection = maakConnectie();
            statement = maakStatement(connection);
            statement.execute("DROP TABLE categorieen IF EXISTS");
            maakTabel(statement);
            sluitStatementEnConnectie(statement, connection);
            return true;
        } catch (SQLException e) {
            sluitStatementEnConnectie(statement, connection);
            return false;
        }
    }

    public boolean create(Categorie categorie) {
        Connection connection = null;
        Statement statement = null;
        try {
            if (categorie.getId() >= 0) return false;
            connection = maakConnectie();
            statement = maakStatement(connection);
            String naam = categorie.getNaam();
            int rowsAffected = statement.executeUpdate("INSERT INTO categorieen VALUES (NULL, '" + naam + "')");
            if (rowsAffected != 1) {
                sluitStatementEnConnectie(statement, connection);
                return false;
            }
            ResultSet resultSet = statement.executeQuery("CALL IDENTITY()");
            if (!resultSet.next()) {
                sluitStatementEnConnectie(statement, connection);
                return false;
            }
            int id = resultSet.getInt(1);
            categorie.setId(id);
            sluitStatementEnConnectie(statement, connection);
            boolean success = true;
            for(Product product : categorie.getProducten()) {
                product.setCategorieId(categorie.getId());
                if (product.getId()<0) {
                    success = success & productDao.create(product);
                } else {
                    success = success & productDao.update(product);
                }
            }
            return success;
        } catch (SQLException e) {
            sluitStatementEnConnectie(statement, connection);
            return false;
        }
    }

    public boolean update(Categorie categorie) {
        Connection connection = null;
        Statement statement = null;
        try {
            if (categorie.getId() < 0) return false;
            connection = maakConnectie();
            statement = maakStatement(connection);
            int id = categorie.getId();
            String naam = categorie.getNaam();
            statement.executeUpdate("UPDATE categorieen SET naam = '" + naam + "' WHERE id=" + id );
            sluitStatementEnConnectie(statement, connection);
            Set<Product> producten = categorie.getProducten();
            Set<Product> oudeProducten = productDao.retrieveByCategorie(id);

            // wis de producten die verwijderd werden
            for(Product oudProduct : oudeProducten) {
                if (!producten.contains(oudProduct)) {
                    productDao.delete(oudProduct.getId());
                }
            }

            // update producten en voeg nieuwe producten toe
            boolean success = true;
            for(Product product : producten) {
                product.setCategorieId(id);
                if (product.getId() == -1) {
                    success = success & productDao.create(product);
                } else {
                    success = success & productDao.update(product);
                }
            }
            
            return success;
        } catch (SQLException e) {
            sluitStatementEnConnectie(statement, connection);
            return false;
        }
    }

    public Categorie retrieve(int id) {
        Connection connection = null;
        Statement statement = null;
        try {
            connection = maakConnectie();
            statement = maakStatement(connection);
            ResultSet resultSet = statement.executeQuery("SELECT naam FROM categorieen WHERE id=" + id);
            if (!resultSet.next()) {
                sluitStatementEnConnectie(statement, connection);
                return null;
            }
            String naam = resultSet.getString("naam");
            Categorie categorie = new Categorie(id, naam);
            sluitStatementEnConnectie(statement, connection);
            Set<Product> producten = productDao.retrieveByCategorie(id);
            categorie.setProducten(producten);
            return categorie;
        } catch (SQLException e) {
            sluitStatementEnConnectie(statement, connection);
            return null;
        }
    }

    public boolean delete(int id) {
        Connection connection = null;
        Statement statement = null;
        try {
            connection = maakConnectie();
            statement = maakStatement(connection);
            int rowsAffected = statement.executeUpdate("DELETE FROM categorieen WHERE id = " + id );
            if (rowsAffected != 1) {
                sluitStatementEnConnectie(statement, connection);
                return false;
            }
            sluitStatementEnConnectie(statement, connection);

            // wis alle producten van deze categorie
            Set<Product> producten = productDao.retrieveByCategorie(id);
            for(Product product : producten) {
                if (!productDao.delete(product.getId())) return false;
            }

            return true;
        } catch (SQLException e) {
            sluitStatementEnConnectie(statement, connection);
            return false;
        }
    }
}
