package be.kdg.patterns;

import java.util.Set;
import java.util.HashSet;
import java.util.Collections;

public class Categorie {
    private int id;
    private String naam;
    private Set<Product> producten;

    public Categorie(String naam) {
        this(-1, naam);
    }

    Categorie(int id, String naam) {
        this.id = id;
        this.naam = naam;
        this.producten = new HashSet<Product>();
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNaam() {
        return naam;
    }

    public void setNaam(String naam) {
        this.naam = naam;
    }

    public void voegProductToe(Product product) {
        producten.add(product);
    }

    public void verwijderProduct(Product product) {
        producten.remove(product);
    }

    public Set<Product> getProducten() {
        return Collections.unmodifiableSet(producten);
    }

    void setProducten(Set<Product> products) {
        this.producten = products;
    }

    public String toString() {
        StringBuffer result =  new StringBuffer("categorie[" + id + ", " + naam + "]");
        for(Product product : producten) {
            result.append("\n\t" + product);
        }
        return result.toString();
    }

    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Categorie)) return false;

        final Categorie categorie = (Categorie) o;

        if (id != categorie.id) return false;

        return true;
    }

    public int hashCode() {
        return id;
    }
}
