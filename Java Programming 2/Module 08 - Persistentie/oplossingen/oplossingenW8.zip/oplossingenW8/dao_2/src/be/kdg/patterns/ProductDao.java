package be.kdg.patterns;

import java.math.BigDecimal;
import java.sql.*;
import java.util.Set;
import java.util.HashSet;
import java.util.Collections;

public class ProductDao extends HsqlDao {

    public ProductDao() {
        laadDriver();
        Connection connection = maakConnectie();
        Statement statement = maakStatement(connection);
        maakTabel(statement);
        sluitStatementEnConnectie(statement, connection);
    }

    private void maakTabel(Statement statement) {
        try {
            statement.execute("CREATE TABLE producten (id INTEGER IDENTITY, omschrijving CHAR(12), prijs CHAR(10), categorieId INTEGER)");
        } catch (SQLException e) {
            // no problem, table already exists
        }
    }

    public boolean clear() {
        Connection connection = null;
        Statement statement = null;
        try {
            connection = maakConnectie();
            statement = maakStatement(connection);
            statement.execute("DROP TABLE producten IF EXISTS");
            maakTabel(statement);
            sluitStatementEnConnectie(statement, connection);
            return true;
        } catch (SQLException e) {
            sluitStatementEnConnectie(statement, connection);
            return false;
        }
    }

    public boolean create(Product product) {
        Connection connection = null;
        Statement statement = null;
        try {
            if (product.getId() >= 0) return false;
            connection = maakConnectie();
            statement = maakStatement(connection);
            String omschrijving = product.getOmschrijving();
            BigDecimal prijs = product.getPrijs();
            int categorieId = product.getCategorieId();
            int rowsAffected = statement.executeUpdate("INSERT INTO producten VALUES (NULL, '" + omschrijving + "', '" + prijs + "', '" + categorieId + "')");
            if (rowsAffected != 1) {
                sluitStatementEnConnectie(statement, connection);
                return false;
            }
            ResultSet resultSet = statement.executeQuery("CALL IDENTITY()");
            if (!resultSet.next()) {
                sluitStatementEnConnectie(statement, connection);
                return false;
            }
            int id = resultSet.getInt(1);
            product.setId(id);
            sluitStatementEnConnectie(statement, connection);
            return true;
        } catch (SQLException e) {
            sluitStatementEnConnectie(statement, connection);
            return false;
        }
    }

    public boolean update(Product product) {
        Connection connection = null;
        Statement statement = null;
        try {
            if (product.getId() < 0) return false;
            connection = maakConnectie();
            statement = maakStatement(connection);
            int id = product.getId();
            String omschrijving = product.getOmschrijving();
            BigDecimal prijs = product.getPrijs();
            int categorieId = product.getCategorieId();
            statement.executeUpdate("UPDATE producten SET omschrijving = '" + omschrijving + "' WHERE id=" + id );
            statement.executeUpdate("UPDATE producten SET prijs = '" + prijs + "' WHERE id=" + id );
            statement.executeUpdate("UPDATE producten SET categorieId = '" + categorieId + "' WHERE id=" + id );
            sluitStatementEnConnectie(statement, connection);
            return true;
        } catch (SQLException e) {
            sluitStatementEnConnectie(statement, connection);
            return false;
        }
    }

    public Product retrieve(int id) {
        Connection connection = null;
        Statement statement = null;
        try {
            connection = maakConnectie();
            statement = maakStatement(connection);
            ResultSet resultSet = statement.executeQuery("SELECT omschrijving, prijs, categorieId FROM producten WHERE id=" + id);
            if (!resultSet.next()) {
                sluitStatementEnConnectie(statement, connection);
                return null;
            }
            String omschrijving = resultSet.getString("omschrijving");
            BigDecimal prijs = new BigDecimal(resultSet.getString("prijs"));
            int categorieId = resultSet.getInt("categorieId");
            Product product = new Product(id, omschrijving, prijs, categorieId);
            sluitStatementEnConnectie(statement, connection);
            return product;
        } catch (SQLException e) {
            sluitStatementEnConnectie(statement, connection);
            return null;
        }
    }

    public Set<Product> retrieveByCategorie(int categorieId) {
        Connection connection = null;
        Statement statement = null;
        try {
            connection = maakConnectie();
            statement = maakStatement(connection);
            ResultSet resultSet = statement.executeQuery("SELECT id, omschrijving, prijs FROM producten WHERE categorieId=" + categorieId);
            Set<Product> producten = new HashSet<>();
            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String omschrijving = resultSet.getString("omschrijving");
                double prijs = Double.parseDouble(resultSet.getString("prijs"));
                Product product = new Product(id, omschrijving, new BigDecimal(prijs), categorieId);
                producten.add(product);
            }
            sluitStatementEnConnectie(statement, connection);
            return producten;
        } catch (SQLException e) {
            sluitStatementEnConnectie(statement, connection);
            return Collections.emptySet();
        }
    }

    public boolean delete(int id) {
        Connection connection = null;
        Statement statement = null;
        try {
            connection = maakConnectie();
            statement = maakStatement(connection);
            int rowsAffected = statement.executeUpdate("DELETE FROM producten WHERE id = " + id );
            if (rowsAffected != 1) {
                sluitStatementEnConnectie(statement, connection);
                return false;
            }
            sluitStatementEnConnectie(statement, connection);
            return true;
        } catch (SQLException e) {
            sluitStatementEnConnectie(statement, connection);
            return false;
        }
    }
}
