package be.kdg.patterns;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class HsqlDao {
    protected void laadDriver() {
        final String driverName = "org.hsqldb.jdbcDriver";
        try {
            Class.forName(driverName);
        } catch (ClassNotFoundException e) {
            System.err.println("Fatal error: cannot load database driver" + driverName);
            System.exit(1);
        }
    }

    protected Connection maakConnectie() {
        Connection connection = null;
        try {
            connection = DriverManager.getConnection("jdbc:hsqldb:file:db/mijnDatabase", "sa", "");
        } catch (SQLException e) {
            System.err.println("Fatal error: cannot get a connection to the database");
            System.exit(1);
        }
        return connection;
    }

    protected Statement maakStatement(Connection connection) {
        Statement statement = null;
        try {
            statement = connection.createStatement();
        } catch (SQLException e) {
            System.err.println("Fatal error: cannot create statement");
            try {
                connection.close();
            } catch (SQLException e1) {
            }
            System.exit(1);
        }
        return statement;
    }

    protected void sluitStatementEnConnectie(Statement statement, Connection connection) {
        try {
            statement.execute("CHECKPOINT");
            statement.close();
            connection.close();
        } catch (SQLException e) {
            // do nothing, we don't need the connection anymore
        }
    }

    public void close() {
        try {
            Connection connection = maakConnectie();
            Statement statement = maakStatement(connection);
            statement.execute("SHUTDOWN COMPACT");
            sluitStatementEnConnectie(statement, connection);
        } catch (SQLException e) {
            // do nothing, database is not needed anymore
        }
    }
}
