package be.kdg.patterns;

import java.math.BigDecimal;

public class Product {
    private int id;
    private String omschrijving;
    private BigDecimal prijs;
    private int categorieId; // foreign key naar gerelateerd categorie-record

    public Product(String omschrijving, BigDecimal prijs) {
        this(-1, omschrijving, prijs, -1);
    }

    public Product(String omschrijving, BigDecimal prijs, int categorieId) {
        this(-1, omschrijving, prijs, categorieId);
    }

    // Bewust niet public, alleen opgeroepen vanuit DAO klasse.
    Product(int id, String omschrijving, BigDecimal prijs, int categorieId) {
        this.id = id;
        this.omschrijving = omschrijving;
        this.prijs = prijs;
        this.categorieId = categorieId;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getOmschrijving() {
        return omschrijving;
    }

    public void setOmschrijving(String omschrijving) {
        this.omschrijving = omschrijving;
    }

    public BigDecimal getPrijs() {
        return prijs;
    }

    public void setPrijs(BigDecimal prijs) {
        this.prijs = prijs;
    }

    public int getCategorieId() {
        return categorieId;
    }

    public void setCategorieId(int categorieId) {
        this.categorieId = categorieId;
    }

    public String toString() {
        return String.format("product[%2d, %-7s, €%.2f, cat: %d]", id, omschrijving, prijs, categorieId);
    }

    @Override
    public boolean equals(Object object) {
        if (this == object) return true;
        if (object == null || getClass() != object.getClass()) return false;

        Product product = (Product) object;

        return id == product.id;
    }

    @Override
    public int hashCode() {
        return id;
    }
    /*
    private int id;
    private String omschrijving;
    private double prijs;
    private int categorieId;

    public Product(String omschrijving, BigDecimal prijs) {
        this(-1, omschrijving, prijs, -1);
    }

    public Product(String omschrijving, BigDecimal prijs, int categorieId) {
        this(-1, omschrijving, prijs, categorieId);

    }

    Product(int id, String omschrijving, BigDecimal prijs, int categorieId) {
        this.id = id;
        this.omschrijving = omschrijving;
        this.prijs = prijs;
        this.categorieId = categorieId;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getOmschrijving() {
        return omschrijving;
    }

    public void setOmschrijving(String omschrijving) {
        this.omschrijving = omschrijving;
    }

    public BigDecimal getPrijs() {
        return prijs;
    }

    public void setPrijs(BigDecimal prijs) {
        this.prijs = prijs;
    }

    public int getCategorieId() {
        return categorieId;
    }

    public void setCategorieId(int categorieId) {
        this.categorieId = categorieId;
    }

    public String toString() {
        return String.format("product[%2d, %-7s, €%.2f, cat: %d]", id, omschrijving, prijs, categorieId);
    }

    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Product)) return false;

        final Product product = (Product) o;

        if (id != product.id) return false;

        return true;
    }

    public int hashCode() {
        return id;
    }
    */
}
