package dao;

import laptop.Laptop;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class LaptopDao {
    private Connection connection;
    private static LaptopDao instance = new LaptopDao();

    private LaptopDao() {
        final String driverName = "org.hsqldb.jdbcDriver";
        try {
            Class.forName(driverName);
        } catch (ClassNotFoundException e) {
            System.out.println("Fatal error: cannot load database driver " + driverName);
        }
        connection = null;
        try {
            connection = DriverManager.getConnection("jdbc:hsqldb:file:2_laptop/db/laptopdb", "sa", "");
        } catch (SQLException e) {
            System.out.println("Fatal error: cannot get a connection to the database " + e);
        }
        try {
            Statement statement = connection.createStatement();
            statement.execute("DROP TABLE laptops");
            statement.execute("CREATE TABLE laptops (id INTEGER IDENTITY, " +
                    "naam VARCHAR(30), processor VARCHAR(30), ram INTEGER, " +
                    "harddisk INTEGER, inch DOUBLE, prijs DOUBLE)");
        } catch (SQLException e) {
            // ok, table bestond al
        }
    }

    public static LaptopDao getInstance() {
        return instance;
    }

    public void create(Laptop laptop) {
        try {
            Statement statement = connection.createStatement();
            String naam = laptop.getNaam();
            String processor = laptop.getProcessor();
            int ram = laptop.getRam();
            int harddisk = laptop.getHardDisk();
            double inch = laptop.getInch();
            double prijs = laptop.getPrijs();
            //Opgelet: NULL als primary key, want die wordt door database zelf aangemaakt!
            statement.execute("INSERT INTO laptops VALUES (NULL, '"
                    + naam + "', '"
                    + processor + "', " + ram + ", " + harddisk
                    + ", " + inch + ", " + prijs + ")");
            statement.close();
        } catch (SQLException e) {
            System.out.println("Fatal error: cannot create " + e);
        }
    }

    public List<Laptop> retrieve(double max) {
        try {
            List<Laptop> myList = new ArrayList<>();
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery("SELECT * FROM laptops where prijs < " + max);
            while (resultSet.next()) {
                //recordgegevens lezen uit resultSet:
                String naam = resultSet.getString("naam");
                String processor = resultSet.getString("processor");
                int ram = resultSet.getInt("ram");
                int harddisk = resultSet.getInt("harddisk");
                double inch = resultSet.getDouble("inch");
                double prijs = resultSet.getDouble("prijs");
                //Met die gegevens een Laptop-object maken:
                Laptop laptop = new Laptop(naam, processor, ram, harddisk, inch, prijs);
                myList.add(laptop);  //toevoegen aan ArrayList
            }
            statement.close();
            return myList;
        } catch (SQLException e) {
            System.out.println("Error: cannot retrieve" + e);
            return null;
        }
    }

    public void close() {
        try {
            Statement statement = connection.createStatement();
            statement.execute("SHUTDOWN");
            statement.close();
            connection.close();
        } catch (SQLException e) {
            System.out.println("Error: cannot close connection " + e);
        }
    }
}




