package klant;

import java.io.*;
import java.util.HashMap;
import java.util.Map;

public class Klanten {
    private static final String FILENAME = "1_serialization/data/klantendata.txt";
    private Map<Integer, Klant> klantenMap = new HashMap<>();

    public void voegToe(Klant nieuw) {
        if (klantenMap.containsKey(nieuw.getKlantNr())) {
            System.out.println("KlantenNr is niet uniek");
            return;
        }
        klantenMap.put(nieuw.getKlantNr(), nieuw);
    }

    public Klant verwijderKlant(Klant oud) {
        return klantenMap.remove(oud.getKlantNr());
    }

    public void verwijderAlles() {
        klantenMap = new HashMap<Integer, Klant>();
    }

    public Klant zoekKlant(Klant zoek) {
        return klantenMap.get(zoek.getKlantNr());   //null indien niet gevonden
    }

    public void updateKlant(Klant klant) {
        if (!klantenMap.containsKey(klant.getKlantNr())) {
            System.out.println("Klant komt niet voor!");
            return;
        }
        klantenMap.put(klant.getKlantNr(), klant); //overschrijven bestaande klantgegevens
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder("Klanten:\n");
        for (Klant k : klantenMap.values()) {
            sb.append("\t");
            sb.append(k.toString());
            sb.append("\n");
        }
        return sb.toString();
    }

    public void serialize() {
        try {
            ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(FILENAME));
            oos.writeObject(klantenMap);
            oos.close();
        } catch (IOException e) {
            System.out.println("Problemen bij het wegschrijven van de klantgegevens: " + e.toString());
        }
    }

    public void deserialize() {
        try {
            ObjectInputStream ois = new ObjectInputStream(new FileInputStream(FILENAME));
            try {
                klantenMap = (HashMap<Integer, Klant>)ois.readObject();
            } catch (ClassNotFoundException e) {
                System.out.println("Fout bij het ophalen van de klantgegevens: " + e.toString());
            }
            ois.close();
        } catch (IOException e) {
            System.out.println("Fout bij het ophalen van de klantgegevens: " + e.toString());
        }
    }
}
