package klant;

import java.io.Serializable;

/**
 * Deze klasse moet OOK Serializable zijn!
 */
public class Adres implements Serializable {
    private String straatNr;
    private int postcode;
    private transient String gemeente; //Niet opgeslagen; dus transient

    public Adres(String straatNr, int postcode, String gemeente) {
        this.gemeente = gemeente;
        this.postcode = postcode;
        this.straatNr = straatNr;
    }

    @Override
    public String toString() {
        return String.format("%s, %s - %d", straatNr, gemeente, postcode);
    }
}
