package concurrency;

import java.util.concurrent.ArrayBlockingQueue;

public class Carwash {
    private final ArrayBlockingQueue<Integer> carwash;

    public Carwash() {
        carwash = new ArrayBlockingQueue<>(1); //Als er 2 wasstraten zijn, dan geven we hier 2 mee
    }

    public void aankomstWagen(int nr) {
        if (!carwash.offer(nr)) { //Queue zit vol, dus wachten
            System.out.println("Wagen met nr " + nr + " moet wachten!");
            try {
                carwash.put(nr); //put wacht tot de blokkering is opgeheven
            } catch (InterruptedException e) {
            }
        }
    }

    public void vertrekWagen(int nr) {
        try {
            carwash.take(); //trake wacht tot er een element in de queue zit
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println("Wagen nr " + nr + " klaar");
    }
}