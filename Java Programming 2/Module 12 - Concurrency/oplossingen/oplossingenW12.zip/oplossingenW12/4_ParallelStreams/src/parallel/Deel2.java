package parallel;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

/**
 * Mark Goovaerts
 * 6/01/2016
 */
public class Deel2 {
    public static void main(String[] args) {
        /*
        creatie van een lijst getallen van 1 tot en met 10000 via een IntStream
         */
        List<Integer> getallen =
                IntStream.rangeClosed(1, 10000)
                        .boxed()
                        .collect(Collectors.toList());

        /*
        1. Bepaal de som van alle getallen in de lijst getallen en stop het resultaat in de Integer variabele totaal.
        Werk met parallelStream en reduce.
        */
        int totaal = getallen
                .parallelStream()
                .reduce(0, (a, b) -> a + b);
        System.out.println("Totaal: " + totaal);

        /*
        2. Bepaal het aantal getallen in de lijst getallen dat deelbaar is door 3 en een veelvoud van 5
        en stop het resultaat ervan in de long variabele aantal.
        Maak gebruik van een parallelStream en count.
         */
        long aantal = getallen
                .parallelStream()
                .filter(n -> n % 3 == 0)
                .filter(n -> n % 5 == 0)
                .map(n -> 1)
                .count();
        System.out.println("Aantal: " + aantal);

        /*
        3. Opdracht 3 is zeker geen basisleerstof en wordt volgend jaar verwijderd.
        Ik voorzie zelfs geen oplossing...
         */

    }
}

/*
Totaal: 50005000
Aantal: 10000
Counter: 8636
 */
