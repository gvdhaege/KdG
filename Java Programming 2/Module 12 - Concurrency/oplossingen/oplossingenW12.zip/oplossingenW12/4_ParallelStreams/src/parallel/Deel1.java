package parallel;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * Mark Goovaerts
 * 6/01/2016
 */
public class Deel1 {
    public static void main(String[] args) {
        List<Integer> getallen =
                Stream.iterate(1, n -> n + 1)
                        .limit(10)
                        .collect(Collectors.toList());

        /*
         1. Maak op basis van getallen een parallelStream en gebruik daarna
         de forEach methode om de getallen af te drukken.
        */
        getallen.forEach(g -> System.out.print(g + " "));
        System.out.println();

        /*
        2. Maak een nieuwe List<Integer> collected op basis van getallen.
        Maak daarvoor gebruik van een parallelStream methode gevolgd door een collect.
        Druk de inhoud van collected vervolgens af.
        */
        List<Integer> collected = getallen
                .parallelStream()
                .collect(Collectors.toList());

        collected.forEach(g -> System.out.print(g + " "));
        System.out.println();

        /*
        Maak een String met de naam string. Zet de getallen van de List getallen via een parallelStream,
        een map en een collect om naar ��n string waarbij de getallen van elkaar gescheiden worden
        door een komma gevolgd door een spatie.
        */

        String string = getallen
                .parallelStream()
                .map(String::valueOf)   //omzetten naar String
                .collect(Collectors.joining(", "));

        System.out.println(string);
    }
}
