package parallel;

/**
 * Mark Goovaerts
 * 6/01/2016
 */
public class Deel3 {
    public static void main(String[] args) {
         /*
        Deel 3 is zeker geen basisleerstof en wordt volgend jaar verwijderd.
        Ik voorzie zelfs geen oplossing...
         */
    }
}