package concurrency;

import java.util.concurrent.Callable;

public class Som implements Callable<Long> {
    private final long beginWaarde;
    private final long eindWaarde;
    public Som(long beginWaarde, long eindWaarde) {
        this.beginWaarde = beginWaarde;
        this.eindWaarde = eindWaarde;
    }

    // Hier moet een functie komen die de som van alle getallen
    // vanaf de beginwaarde tot en met de eindwaarde teruggeeft.
    @Override
    public Long call() throws Exception {
        long som = 0;
        for(long i = beginWaarde; i <= eindWaarde; i++) {
            som += i;
        }
        return som;
    }
}