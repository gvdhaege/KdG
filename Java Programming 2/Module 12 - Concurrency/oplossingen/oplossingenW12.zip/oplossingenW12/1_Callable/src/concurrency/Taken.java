package concurrency;

import java.util.ArrayList;

public class Taken {
    private ArrayList<Som> taken = new ArrayList<>();

    public Taken() {
        taken.add(new Som(1, 10));
        taken.add(new Som(1, 100));
        taken.add(new Som(1, 1000));
        taken.add(new Som(1, 10_000));
        taken.add(new Som(1, 100_000));
        taken.add(new Som(1, 1_000_000));
    }

    public ArrayList<Som> getTaken() {
        return taken;
    }
}