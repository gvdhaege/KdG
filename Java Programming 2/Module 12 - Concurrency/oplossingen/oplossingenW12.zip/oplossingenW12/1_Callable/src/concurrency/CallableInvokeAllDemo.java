package concurrency;

import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class CallableInvokeAllDemo {
    public static void main(String[] args) {
        ExecutorService executor = Executors.newFixedThreadPool(4);
        List<Future<Long>> results = null;
        try {
            results = executor.invokeAll(new Taken().getTaken());
        } catch (InterruptedException e) {
            e.printStackTrace(); // Voor testfase.
        }
        executor.shutdown(); // Niet vergeten, loopt anders door na main!

        // Hier moet je met behulp van een lus de resultaten van
        // elke afzonderlijk taak onder mekaar afdrukken.
        for(Future<Long> future : results){
            try {
                System.out.println(future.get());
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
/*
De uitvoer zou het volgende moeten worden:
        55
        5050
        500500
        50005000
        5000050000
        500000500000
*/