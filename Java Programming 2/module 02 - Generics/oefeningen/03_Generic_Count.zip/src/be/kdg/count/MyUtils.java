package be.kdg.count;

import java.util.Collection;

// Op dit moment zijn beide methoden alleen geldig voor het type String
// en moeten ze beiden nog aangevuld worden met het eigenlijke tellen.

public class MyUtils {
    public static int telFrequentie(String[] reeks, String teTellenElement) {
        int frequentie = 0;

        return frequentie;
    }

    public static int telFrequentie(Collection<String> collection, String teTellenElement) {
        int frequentie = 0;

        return frequentie;
    }
}
