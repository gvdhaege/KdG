package be.kdg.generics;

import java.util.Collection;

/**
 * Vul hier eerst de methode aan zodat alle elementen uit de collection na elkaar gescheiden door
 * de separator in de string komen. Tip: Je kunt een for each lus gebruiken.
 */
public class MyUtil {
    public static String join(Collection<String> collection, String seperator) {
        String string = "";

        return string.substring(0, string.length() - 1);
    }
}
