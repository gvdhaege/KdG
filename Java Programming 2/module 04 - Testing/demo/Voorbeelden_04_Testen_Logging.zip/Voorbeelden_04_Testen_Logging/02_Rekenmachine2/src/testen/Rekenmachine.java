package testen;

public class Rekenmachine {
    public double sommeer(double a, double b) {
        return a + b;

    }

    public double vermenigvuldig(double a, double b) {
        return a * b;
    }
}

