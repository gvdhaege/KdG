package demo;

public class Punt  {
    int x;
    int y;

    public Punt(int x, int y) {
        this.x = x;
        this.y = y;
    }

	public double distanceToCenter() {
    	// TODO: vervang door correcte implementatie
    	return 0.0;
	}

	public int compareTo(Punt pTwo) {
		// TODO: vervang door correcte implementatie
    	return 0;
	}

	public double distance(Punt pTwo) {
		// TODO: vervang door correcte implementatie
		return  0.0;
	}
}
