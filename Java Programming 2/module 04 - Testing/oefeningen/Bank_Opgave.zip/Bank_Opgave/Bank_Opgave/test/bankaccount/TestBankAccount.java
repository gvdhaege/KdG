package bankaccount;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 * Testklasse voor JUnit, test de klasse BankAccount.
 */
public class TestBankAccount {


	/**
	 * Todo 1: Test de toString methode  van BankAccount.
	 */



}

