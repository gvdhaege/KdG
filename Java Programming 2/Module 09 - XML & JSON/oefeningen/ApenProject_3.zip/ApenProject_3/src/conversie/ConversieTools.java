package conversie;

import apen.Aap;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.io.*;
import java.util.*;

public class ConversieTools {

    public static List<Aap> GsonReadList(String fileName) throws FileNotFoundException {
	    List<Aap> result = null;
	    //Todo 3A parse de file en geef een list van Aap objecten terug

        return result;
    }

    public static void GsonWriteList(List<Aap> apenList, String fileName) throws FileNotFoundException {
        //Todo 3D schrijf apenList weg als JSON

    }
}
