package apen;


public enum Geslacht {
    MAN, VROUW
}
