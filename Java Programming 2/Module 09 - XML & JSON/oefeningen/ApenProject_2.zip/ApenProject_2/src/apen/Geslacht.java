package apen;

/**
 * Mark Goovaerts
 * 26/11/2015
 */
public enum Geslacht {
    MAN, VROUW
}
