import apen.Aap;
import apen.Apen;
import apen.Geslacht;
import conversie.ConversieTools;

import javax.xml.bind.JAXBException;
import javax.xml.stream.XMLStreamException;
import java.io.FileNotFoundException;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.stream.Collectors;

public class DemoApen {
    public static void main(String[] args) {
        try {
            Apen apen = ConversieTools.JaxbReadXML("AlleApen.xml");
            List<Aap> myApenList = apen.getApenList();

            Map<String, List<Aap>> soortMap = new TreeMap<>(myApenList
                    .stream()
                    .sorted()
                    .collect(Collectors.groupingBy(Aap::getSoort)));

            System.out.println("\nAlle apen alfabetisch per soort:");
            soortMap.forEach((k, v) -> System.out.printf("%-8s -> %s\n",
                    k, v.stream()
                            .map(Aap::getNaam)
                            .collect(Collectors.joining(", "))));

            Aap zwaarste = myApenList
                    .stream()
                    .filter(a -> a.getGeslacht() == Geslacht.MAN)
                    .sorted(Comparator.comparing(Aap::getGewicht).reversed())
                    .findFirst()
                    .get();
            System.out.printf("\nZwaarste mannetjesaap: %s = %.1f kg\n"
                    , zwaarste.getNaam(), zwaarste.getGewicht());
            ConversieTools.StaxWriteXML(soortMap, "ApenPerSoort.xml");
        } catch (JAXBException | FileNotFoundException | XMLStreamException e) {
            System.out.println(e.getMessage());
        }
    }
}
