package conversie;

import apen.Aap;
import apen.Apen;
import com.sun.xml.internal.txw2.output.IndentingXMLStreamWriter;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import javax.xml.stream.XMLOutputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;
import java.io.*;
import java.util.List;
import java.util.Map;

public class ConversieTools {

    public static Apen JaxbReadXML(String fileName) throws JAXBException {
        JAXBContext jc = JAXBContext.newInstance(Apen.class);
        Unmarshaller u = jc.createUnmarshaller();
        File f = new File(fileName);
        Apen apen = (Apen) u.unmarshal(f);
        return apen;
    }

    public static void StaxWriteXML(Map<String, List<Aap>> myMap, String fileName) throws XMLStreamException, FileNotFoundException {
        PrintWriter writerXml = new PrintWriter(new OutputStreamWriter(new FileOutputStream(fileName)));
        XMLOutputFactory xmlOutputFactory = XMLOutputFactory.newInstance();
        XMLStreamWriter xmlStreamWriter = xmlOutputFactory.createXMLStreamWriter(writerXml);
        xmlStreamWriter = new IndentingXMLStreamWriter(xmlStreamWriter);
        xmlStreamWriter.writeStartDocument();
        xmlStreamWriter.writeStartElement("apen");

        for (String soort : myMap.keySet()) {
            xmlStreamWriter.writeStartElement("soort");
            xmlStreamWriter.writeCharacters(soort);
            for (Aap aap : myMap.get(soort)) {
                xmlStreamWriter.writeStartElement("aap");

                xmlStreamWriter.writeStartElement("naam");
                xmlStreamWriter.writeCharacters(aap.getNaam());
                xmlStreamWriter.writeEndElement();

                xmlStreamWriter.writeStartElement("gewicht");
                xmlStreamWriter.writeCharacters(String.valueOf(aap.getGewicht()));
                xmlStreamWriter.writeEndElement();

                xmlStreamWriter.writeStartElement("geboorte");
                xmlStreamWriter.writeCharacters(String.valueOf(aap.getGeboorte()));
                xmlStreamWriter.writeEndElement();

                xmlStreamWriter.writeStartElement("kooi");
                xmlStreamWriter.writeCharacters(aap.getKooi());
                xmlStreamWriter.writeEndElement();

                xmlStreamWriter.writeEndElement(); // </aap>
            }

            xmlStreamWriter.writeEndElement(); // </soort>
        }
        xmlStreamWriter.writeEndElement(); // </apen>
        xmlStreamWriter.writeEndDocument();

        xmlStreamWriter.flush();
        xmlStreamWriter.close();
        writerXml.close();

        System.out.println("File saved!");
    }
}
