import apen.Aap;
import conversie.ConversieTools;

import java.io.IOException;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class DemoApen {
    public static void main(String[] args) {
        try {
            List<Aap> myApenList = ConversieTools.GsonReadList("AlleApen.json");

            System.out.println("Alle apen per leeftijd:");
            myApenList
                    .stream()
                    .sorted(Comparator.comparing(Aap::getLeeftijd))
                    .map(a -> String.format("%-12s --> %d jaar", a.getNaam(), a.getLeeftijd()))
                    .forEach(System.out::println);

            Map<Boolean, List<Aap>> myMap =
                    myApenList
                            .stream()
                            .collect(Collectors.partitioningBy(a -> a.getKooi().charAt(0) == 'K'));

            ConversieTools.GsonWriteList(myMap.get(true), "KleineApen.json");

            List<Aap> newList = ConversieTools.GsonReadList("KleineApen.json");
            System.out.println("\nIngelezen JSON data (alle kleine apen):");
            for (Aap aap : newList) {
                System.out.println(aap);
            }

        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }
}
