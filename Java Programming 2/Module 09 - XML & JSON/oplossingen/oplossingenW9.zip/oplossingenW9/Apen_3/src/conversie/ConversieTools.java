package conversie;

import apen.Aap;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.io.*;
import java.util.Arrays;
import java.util.List;

public class ConversieTools {

    public static List<Aap> GsonReadList(String fileName) throws FileNotFoundException {
        GsonBuilder builder = new GsonBuilder();
        Gson gson = builder.create();
        BufferedReader data = new BufferedReader(new FileReader(fileName));
        Aap[] aapArray = gson.fromJson(data, Aap[].class);
        List<Aap> newList = Arrays.asList(aapArray);
        return newList;
    }

    public static void GsonWriteList(List<Aap> apenList, String fileName) throws FileNotFoundException {
        GsonBuilder builder = new GsonBuilder();
        Gson gson = builder.create();

        String jsonString = gson.toJson(apenList);
        PrintWriter jsonWriter = new PrintWriter(new OutputStreamWriter(new FileOutputStream(fileName)));
        jsonWriter.write(jsonString);
        jsonWriter.close();
    }
}
