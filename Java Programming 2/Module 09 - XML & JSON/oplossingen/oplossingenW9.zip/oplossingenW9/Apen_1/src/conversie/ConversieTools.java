package conversie;

import apen.Aap;
import apen.Geslacht;
import org.jdom2.Attribute;
import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.output.Format;
import org.jdom2.output.XMLOutputter;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.StringTokenizer;

public class ConversieTools {

    public static List<Aap> readTxtFile(String bestand) throws IOException {
        List<Aap> list = new ArrayList<>();
        String regel = "";
        try (BufferedReader br = new BufferedReader(new FileReader(bestand))) {
            while ((regel = br.readLine()) != null) {
                StringTokenizer tokenizer = new StringTokenizer(regel, ",");

                String naam = tokenizer.nextToken();
                String soort = tokenizer.nextToken();
                String familie = tokenizer.nextToken();
                Geslacht geslacht = tokenizer.nextToken().charAt(0) == 'M' ? Geslacht.MAN : Geslacht.VROUW;
                LocalDate geboorte = LocalDate.parse(tokenizer.nextToken());
                double gewicht = Double.parseDouble(tokenizer.nextToken());
                String kooi = tokenizer.nextToken();

                list.add(new Aap(naam, soort, familie, geslacht, geboorte, gewicht, kooi));
            }
            return list;
        } catch (NoSuchElementException | NumberFormatException e1) {
            throw new IOException("Leesfout in regel: " + regel, e1);
        } catch (IOException e2) {
            throw new IOException("Het bronbestand " + bestand + " kan niet geopend worden", e2);
        }
    }

    public static String JdomWriteXML(List<Aap> myList, String fileName) throws IOException {
        //root element maken:
        Element rootElement = new Element("apen");
        //document maken:
        Document doc = new Document(rootElement);

        //aap elementen toevoegen:
        for (Aap aap : myList) {
            Element aapElement = new Element("aap");
            aapElement.setAttribute(new Attribute("kooi", aap.getKooi()));

            //content toevoegen:
            Element naamElement = new Element("naam");
            naamElement.setText(aap.getNaam());
            aapElement.addContent(naamElement);

            Element soortElement = new Element("soort");
            soortElement.setText(aap.getSoort());
            aapElement.addContent(soortElement);

            Element geslachtElement = new Element("geslacht");
            geslachtElement.setText(aap.getGeslacht().name().toLowerCase());
            aapElement.addContent(geslachtElement);

            Element gewichtElement = new Element("gewicht");
            gewichtElement.setText(String.valueOf(aap.getGewicht()));
            aapElement.addContent(gewichtElement);

            rootElement.addContent(aapElement);
        }

        //XMLOutputter object aanmaken en wegschrijven:
        XMLOutputter xmlOutput = new XMLOutputter();
        xmlOutput.setFormat(Format.getPrettyFormat());

        //save file
        xmlOutput.output(doc, new FileWriter(fileName));

        //return String
        return xmlOutput.outputString(doc);
    }
}
