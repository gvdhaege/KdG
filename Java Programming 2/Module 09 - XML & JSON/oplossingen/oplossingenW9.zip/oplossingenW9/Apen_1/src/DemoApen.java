import apen.Aap;
import apen.Geslacht;
import conversie.ConversieTools;

import java.io.IOException;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class DemoApen {
    public static void main(String[] args) {
        try {
            List<Aap> apenList = ConversieTools.readTxtFile("Apendata.txt");
            apenList = apenList
                    .stream()
                    .filter(a -> a.getGeslacht() == Geslacht.MAN)
                    .sorted(Comparator.comparing(Aap::getKooi))
                    .collect(Collectors.toList());

            System.out.println("Alle mannetjes apen, gesorteerd op kooi:");
            for (Aap aap : apenList) {
                System.out.println(aap);
            }

            double gemLeeftijd = apenList
                    .stream()
                    .filter(a -> a.getGeslacht() == Geslacht.MAN)
                    .mapToDouble(Aap::getLeeftijd)
                    .average()
                    .getAsDouble();

            System.out.printf("Gemiddelde leeftijd van de mannetjes: %.1f jaar\n\n", gemLeeftijd);

            String XMLresult = ConversieTools.JdomWriteXML(apenList, "MannetjesApen.xml");
            System.out.println(XMLresult);

        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }
}
