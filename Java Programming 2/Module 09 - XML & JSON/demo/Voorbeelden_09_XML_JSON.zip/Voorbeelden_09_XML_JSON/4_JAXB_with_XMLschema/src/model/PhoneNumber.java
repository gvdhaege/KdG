package model;

/**
 * Voorbeeld: http://blog.bdoughan.com/2010/12/jaxb-and-marshalunmarshal-schema.html
 */
public class PhoneNumber {
}
