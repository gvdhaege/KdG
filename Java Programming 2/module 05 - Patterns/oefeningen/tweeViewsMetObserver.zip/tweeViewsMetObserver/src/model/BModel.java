package model;

public class BModel {
    private int b = 0;

    public int getB() {
        return b;
    }

    public void setB(int b) {
        this.b = b;
    }
}
