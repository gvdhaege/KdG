package quarto;

import java.util.HashSet;
import java.util.Set;

/**
 * Todo: Werk uit volgens de instructies.
 */

public class QuartoFactory {


	public static QuartoBlock createBlock(
		QuartoBlock.Length length, QuartoBlock.Color
		color,
		QuartoBlock.Shape shape, QuartoBlock.Volume volume
	) {

		return null;
	}

	public static int countBlocks(){
		return 0;
	}

}

