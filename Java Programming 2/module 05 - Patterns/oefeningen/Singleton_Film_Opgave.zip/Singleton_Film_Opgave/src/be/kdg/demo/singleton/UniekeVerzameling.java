package be.kdg.demo.singleton;

/**
 * Todo Vul deze klasse aan.
 */
public class UniekeVerzameling {
}
