package staticfactory;

public interface Persoon {
    String naam();

    RijksregisterNummer nummer();
}

