package factorydemo;

public interface Figuur {
    public double oppervlakte();
}
