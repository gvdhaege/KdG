package factorydemo;

public class FiguurFactory {

    private FiguurFactory() {
        //private constructor, want typisch voor static factory
    }

    public static Figuur getVierkant(double zijde) {
        return Vierkant.newVierkant(zijde);
    }

    public static Figuur getRechthoek(double breedte, double hoogte) {
        return Rechthoek.newRechthoek(breedte, hoogte);
    }

    public static Figuur getRechthoek(double zijde) {
        return Rechthoek.newRechthoek(zijde, zijde);
    }

    public static Figuur getFiguur(FiguurType type, double zijde) {
        if(type == FiguurType.RECHTHOEK) {
            return Rechthoek.newRechthoek(zijde, zijde);
        }
        if(type == FiguurType.VIERKANT) {
            return Vierkant.newVierkant(zijde);
        }
        if(type == FiguurType.RUIT) {
            return Ruit.newRuit(zijde, zijde);
        }
        return null;
    }

    public static Figuur getFiguur(FiguurType type, double dimEen, double dimTwee) {
        if(type == FiguurType.RECHTHOEK) {
            return Rechthoek.newRechthoek(dimEen, dimTwee);
        }
        if(type == FiguurType.VIERKANT) {
            return Vierkant.newVierkant(dimEen);
        }
        if(type == FiguurType.RUIT) {
            return Ruit.newRuit(dimEen, dimTwee);
        }
        return null;
    }
}
