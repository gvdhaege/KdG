package factorydemo;

public class Vierkant implements Figuur {
    private double zijde;

    public double oppervlakte() {
        return zijde * zijde;
    }

    private Vierkant(double zijde) {
        this.zijde = zijde;
    }

    public static Vierkant newVierkant(double zijde){
        return new Vierkant(zijde);
    }

    public double getZijde() {
        return zijde;
    }

    public String toString() {
        return "Vierkant " + zijde ;
    }
}
