package factorydemo;


public enum FiguurType {
    RECHTHOEK,
    VIERKANT,
    RUIT;


}
