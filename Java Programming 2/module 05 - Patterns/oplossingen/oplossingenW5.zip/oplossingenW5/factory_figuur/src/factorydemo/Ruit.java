package factorydemo;

public class Ruit implements Figuur{
    private double groteDiagonaal;
    private double kleineDiagonaal;

    private Ruit(double g, double k) {
        this.groteDiagonaal = g;
        this.kleineDiagonaal = k;
    }

    public double oppervlakte() {
        return groteDiagonaal * kleineDiagonaal / 2;
    }

    public static Ruit newRuit(double g,double k) {
        return new Ruit(g, k);
    }

    public double getKleineDiagonaal() {
        return kleineDiagonaal;
    }

    public double getGroteDiagonaal() {
        return groteDiagonaal;
    }

    public String toString() {
        return "Ruit " + groteDiagonaal + " " + kleineDiagonaal ;
    }
}