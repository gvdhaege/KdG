package singleton;

public class UniekeVerzameling extends Verzameling {
    private static final UniekeVerzameling verzameling = new UniekeVerzameling();

    private UniekeVerzameling() {
    }

    public static Verzameling getInstance() {
        return verzameling;
    }

    @Override
    public Object clone() throws CloneNotSupportedException {
        throw new CloneNotSupportedException("singleton-pattern toegepast, dus clone niet toegelaten");
    }
}
