package singleton;

public class Controller {
    private Verzameling verzameling;
    private Verzameling andereVerzameling;

    public Controller() {
        verzameling = UniekeVerzameling.getInstance();  // gewijzigd

        verzameling.add(new Film("Psycho", 1998));
        verzameling.add(new Film("Taxi Driver", 1976));
        verzameling.add(new Film("Psycho", 1960));

        andereVerzameling = UniekeVerzameling.getInstance();  // gewijzigd

        andereVerzameling.add(new Film("Joyride", 1996));
        andereVerzameling.add(new Film("Vanishing Point", 1971));
        andereVerzameling.add(new Film("Joyride", 2001));
        andereVerzameling.add(new Film("Vanishing Point", 1997));
    }

    public void toonVerzameling() {
        verzameling.sorteer();
        for (Film film : verzameling.getVerzameling()) {
            System.out.println(film);
        }
    }

    public void toonAndereVerzameling() {
        andereVerzameling.sorteer();
        for (Film film : andereVerzameling.getVerzameling()) {
            System.out.println(film);
        }
    }

}
