import singleton.Controller;

public class RunDemo {
    public static void main(String[] args) {
        Controller controller = new Controller();

        System.out.println("Verzameling:");
        controller.toonVerzameling();

        System.out.println("\nAndere verzameling:");
        controller.toonAndereVerzameling();
    }
}

/*
Verzameling:
Film{titel='Joyride', jaar=1996}
Film{titel='Joyride', jaar=2001}
Film{titel='Psycho', jaar=1960}
Film{titel='Psycho', jaar=1998}
Film{titel='Taxi Driver', jaar=1976}
Film{titel='Vanishing Point', jaar=1971}
Film{titel='Vanishing Point', jaar=1997}

Andere verzameling:
Film{titel='Joyride', jaar=1996}
Film{titel='Joyride', jaar=2001}
Film{titel='Psycho', jaar=1960}
Film{titel='Psycho', jaar=1998}
Film{titel='Taxi Driver', jaar=1976}
Film{titel='Vanishing Point', jaar=1971}
Film{titel='Vanishing Point', jaar=1997}
*/