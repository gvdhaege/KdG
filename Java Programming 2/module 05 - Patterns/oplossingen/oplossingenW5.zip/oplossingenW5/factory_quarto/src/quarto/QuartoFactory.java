package quarto;

import java.util.HashSet;
import java.util.Set;

public class QuartoFactory {
    private static Set<QuartoBlock> set = new HashSet<>();

    private QuartoFactory() {
        // niet beschikbaar
    }

    public static QuartoBlock createBlock(QuartoBlock.Length lentgh, QuartoBlock.Color color, QuartoBlock.Shape shape, QuartoBlock.Volume volume) {
        QuartoBlock newBlock = new QuartoBlock(lentgh, color, shape, volume);

        for (QuartoBlock block : set) {
            if (block.equals(newBlock)) {
                return block;
            }
        }
        //Blok zit nog niet in de set
        set.add(newBlock);
        return newBlock;
    }

    public static int countBlocks() {
        return set.size();
    }

    public static String getProductionOverview() {
        String str = countBlocks()  + " Quarto blocks created:\n";
        int i = 1;

        for(QuartoBlock block : set) {
            str += i++ + ") " + block + "\n";
        }
        return str;
    }
}

