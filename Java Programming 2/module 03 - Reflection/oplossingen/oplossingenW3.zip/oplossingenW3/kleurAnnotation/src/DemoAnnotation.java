
public class DemoAnnotation {
    public static void main(String[] args) {
        ParserClass.execute(MyAnnotations.class);
    }
}

/*
VERWACHTE AFDRUK:

De wagen is BLAUW
Het huis is ROOD
 */
