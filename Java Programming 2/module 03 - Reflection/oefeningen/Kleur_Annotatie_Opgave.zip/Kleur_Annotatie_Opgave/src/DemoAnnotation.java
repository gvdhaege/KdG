
public class DemoAnnotation {
    public static void main(String[] args) {
        ParserClass.execute(MyAnnotations.class);
    }
}
