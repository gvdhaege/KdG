package reflection;

import java.lang.annotation.Annotation;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class ReflectionRunner {
    public static void reflect(Class myClass) {
        Object object = null;  // Vervang de null door het nodige.
        //  Vul hier verder aan!
    }
}

