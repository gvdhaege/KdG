package annotations;

import java.lang.annotation.Annotation;
import java.lang.reflect.Method;

public class Demo {
    public void demoMethode() {
        MijnKlasse mijnKlasse = new MijnKlasse();
        // TODO: Toon alle annotaties op de klasse MijnKlasse.
        toonClassAnnotations(mijnKlasse);
        // TODO: Toon de waarden van de Class-annotaties
        toonWaardenClassAnnotation(mijnKlasse);
        // TODO: Toon alle annotaties voor demoMethode uit MijnKlasse .
        toonMethodeAnnotations(mijnKlasse);
        //TODO:  Toon alle waarden van de Methode-annotaties uit MijnKlasse
        toonWaardenMethodeAnnotation(mijnKlasse);
    }


}