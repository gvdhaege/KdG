import annotations.Demo;

public class RunDemo {
    public static void main(String args[]) {
        Demo demo = new Demo();
        demo.demoMethode();
    }
}

/*
  Verwachte afdruk:

Alle annotaties voor MijnKlasse:
@annotations.Wat(omschrijving=Een annotatie testklasse)
@annotations.MijnAnnotatie(string=Demo, waarde=99)

Alle parameters:
Een annotatie testklasse
Demo 99

Alle annotaties voor demoMethode:
@annotations.Wat(omschrijving=Een annotation testmethode)
@annotations.MijnAnnotatie(string=Test, waarde=100)

Alle parameters:
Test 100
Een annotation testmethode
 */

