package proxy;

public interface Klant {
    String getRekeningNummer();
}
