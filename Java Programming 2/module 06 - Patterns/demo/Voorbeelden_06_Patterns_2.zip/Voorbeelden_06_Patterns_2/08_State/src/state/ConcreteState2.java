package state;

public class ConcreteState2 implements State {
    public void handle() {
        System.out.println("ConcreteState2.handle() executing");
    }
}
