package state;

public class ConcreteState1 implements State {
    public void handle() {
        System.out.println("ConcreteState1.handle() executing");
    }
}
