package state;

public enum StateEnum {
    STATE_ONE, STATE_TWO
}
