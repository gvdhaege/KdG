package patterns;

public interface Afbeelding {
    void toonAfbeelding();
}
