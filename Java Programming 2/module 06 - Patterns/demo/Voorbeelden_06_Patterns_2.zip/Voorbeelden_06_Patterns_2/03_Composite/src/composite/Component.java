package composite;

public interface Component {
    void operation();
}

