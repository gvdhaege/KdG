package state;

/**
 * Gemeenschappelijke interface voor alle Status-klassen
 */
public interface Kissable {
    String greet();
}
