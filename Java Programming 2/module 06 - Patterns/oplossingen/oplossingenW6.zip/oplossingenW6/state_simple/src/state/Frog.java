package state;

/**
 * De klasse Frog implementeert Kissable
 */
public class Frog implements Kissable {
    @Override
    public String greet() {
        return "Ribbet!";
    }
}
