package state;

/**
 * De klasse Prince implementeert Kissable
 */
public class Prince implements Kissable {
    @Override
    public String greet() {
        return "Darling!";
    }
}
