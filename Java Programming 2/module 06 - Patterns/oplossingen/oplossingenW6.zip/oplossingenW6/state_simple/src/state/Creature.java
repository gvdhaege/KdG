package state;

/**
 * Deze klasse maakt gebruik van het State-pattern.
 * Als de kiss-methode wordt opgeroepen, dan verandert de status van het Kissable-attribuut.
 */
public class Creature {
    private Kissable kissable;

    public Creature() {
        this.kissable = new Frog(); // In het begin is het nog een kikker
    }

    public String greet() {
        return kissable.greet();
    }

    public void kiss() {
        if(kissable instanceof Frog) { // Bij elke kus verandert het schepsel van toestand
            kissable = new Prince();
        }
        else {
            kissable = new Frog();
        }
    }
}
