package be.kdg.nederlands;

public interface Adres {

   String getStraat();

   int getPostCode();

   String getGemeente();

}
