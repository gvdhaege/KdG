package be.kdg.nederlands;

import be.kdg.english.Address;
//TODO: vul hier aan ...

public class AdresAdapter extends Address implements Adres{
	public AdresAdapter(String straatEnNr, int postNummer, String gemeente) {
		super(straatEnNr,Integer.toString(postNummer),gemeente,"België");
	}

	@Override
	public String toString() {
		return getStreet() + "\n" + getZip()+ " " + getCity();
	}

	@Override
	public String getStraat() {
		return getStreet();
	}

	@Override
	public int getPostCode() {
		return Integer.parseInt(getZip().replaceAll("[^0-9]",""));
	}


	@Override
	public String getGemeente() {
		return getCity();
	}
}