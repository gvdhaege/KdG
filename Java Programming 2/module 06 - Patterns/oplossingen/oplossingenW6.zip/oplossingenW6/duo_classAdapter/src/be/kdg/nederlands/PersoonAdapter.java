package be.kdg.nederlands;

import be.kdg.english.Address;
import be.kdg.english.Person;

public class PersoonAdapter extends Person implements Persoon{
	public PersoonAdapter(String s, AdresAdapter adres) {
		super(s,adres);
	}

	@Override
	public String getNaam() {
		return getName();
	}

	@Override
	public Adres getAdres() {
		// exception als de persoon geen nederlands adres heeft!!
			return (AdresAdapter) getAddress();

		}


	//TODO: vul hier aan ...

}
