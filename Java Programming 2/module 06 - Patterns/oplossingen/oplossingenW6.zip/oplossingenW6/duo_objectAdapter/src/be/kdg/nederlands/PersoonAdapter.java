package be.kdg.nederlands;

import be.kdg.english.Person;

public class PersoonAdapter implements Persoon {
    private Person person;
    private Adres adres;
	//TODO vul hier aan ...

	public PersoonAdapter(String s, AdresAdapter adres) {
		person = new Person(s,adres.getAddress());
		this.adres = adres;
	}

	@Override
	public String getNaam() {
		return person.getName();
	}

	@Override
	// gevaarlijk indien amerkaans adres verandert, zonder dat NL verandert.
	// alternatief: return new AdresAdapter(person.getAddress())
	public Adres getAdres() {
		return adres;
	}

	@Override
	public String toString() {
		return getNaam() + "\n" + getAdres();
	}
}
