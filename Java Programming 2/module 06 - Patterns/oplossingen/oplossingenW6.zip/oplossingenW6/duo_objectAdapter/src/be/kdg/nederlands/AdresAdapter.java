package be.kdg.nederlands;

import be.kdg.english.Address;

public class AdresAdapter implements Adres {
    private Address address;
	//TODO: vul hier aan ...

	public AdresAdapter(String straatNr, int postnummer, String gemeente) {
		address = new Address(straatNr, gemeente, Integer.toString(postnummer), "België");
	}

	@Override
	public String getStraat() {
		return address.getStreet();
	}

	@Override
	public int getPostCode() {
		return Integer.parseInt(address.getZip().replaceAll("[^0-9]",""));
	}

	@Override
	public String getGemeente() {
		return address.getCity();
	}

	 Address getAddress() {
		return address;
	}

	@Override
	public String toString() {
		return getStraat() + "\n" + + getPostCode() + " " +getGemeente();
	}
}
