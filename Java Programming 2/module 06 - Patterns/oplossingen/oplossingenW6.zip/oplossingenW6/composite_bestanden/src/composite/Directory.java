package composite;

import java.util.ArrayList;
import java.util.List;

public final class Directory extends Component {
    private final String name;
    private final List<Component> children;
    private Directory parent;

    public Directory(String name) {
        this.name = name;
        this.parent = null;
        children = new ArrayList<>();
    }

    /**
     * De size van een directory is de som van alle size-waarden van zijn componenten;
     * vandaar dus de lus
     */
    @Override
    public long getSize() {
        long size = 0;

        for (Component component : children) {
            size += component.getSize();
        }
        return size;
    }

    @Override
    public String getPath() {
        if (parent != null) {
            return parent.getPath() + "\\" + name;
        }
        return name;
    }

    @Override
    public void setParent(Directory parent) {
        this.parent = parent;
    }

    public void add(Component c) {
        children.add(c);
        c.setParent(this); //Wordt vaak vergeten!
    }

    @Override
    public void remove(Component c) {
        if (children.contains(c)) {
            children.remove(c);
            c.setParent(null); //Wordt vaak vergeten!
        }
    }

    @Override
    public String toString() {
        return getPath() + " (" + getSize() + "kb)";
    }
}
