package facturatie;

import artikel.Artikel;
import klant.Klant;

public interface Factureerbaar {
    Klant getKlant();
    String getDatum();
    void setDatum(String datum);
    void setKlant(Klant klant);
    int getFactuurNr();
    void voegLijnToe(Artikel artikel, int aantal);
    void verwijderLijn(Artikel artikel);
    double getTotaalExcl();
    double getBTW();
    double getTotaalIncl();
    void printFactuur();
}
