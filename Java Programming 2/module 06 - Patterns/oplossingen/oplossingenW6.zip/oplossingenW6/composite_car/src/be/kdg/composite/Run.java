package be.kdg.composite;

import javax.swing.*;

/**
 * Vul de klasse Car aan zodat je de gewenste uitvoer bekomt (composite pattern)
 * Aan deze klasse mag je niets wijzigen!
 */

public class Run {
     public static void main( String[] args ) {
         JButton b = new JButton();
      Tire frontLeftTire = new Tire();
      Tire frontRightTire = new Tire();
      Tire backLeftTire = new Tire();
      Tire backRightTire = new Tire();

      Body body = new Body();

      Door driverSideDoor = new Door();
      Door passengerDoor = new Door();

      Car car = new Car();
      car.addDrawableComponent(frontLeftTire);
      car.addDrawableComponent(frontRightTire);
      car.addDrawableComponent(backLeftTire);
      car.addDrawableComponent(backRightTire);
      car.addDrawableComponent(body);
      car.addDrawableComponent(driverSideDoor);
      car.addDrawableComponent(passengerDoor);

      paintComponent(car);
    }

    public static void paintComponent(Drawable drawable) {
      drawable.draw();
    }
}

//Gewenste uitvoer:
/*
Tire
Tire
Tire
Tire
Body
Door
Door
*/

