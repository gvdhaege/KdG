package be.kdg.composite;

import java.util.ArrayList;
import java.util.List;

/**
 * Zorg ervoor dat de klasse de interface Drawable implementeert.
 * Maak een arraylist van Drawable objecten.
 * Voorzie een methode addDrawableComponent om een "Drawable" object aan de lijst toe te voegen.
 * Voorzie een methode draw om de draw methode van elke component in de lijst
 * uit te voeren
 */
public class Car implements Drawable {
    List<Drawable> list = new ArrayList<>();

    @Override
    public void draw() {
        for(Drawable drawable : list) {
            drawable.draw();
        }
    }

    public void addDrawableComponent(Drawable nieuw) {
        list.add(nieuw);
    }
}

/*
Tire
Tire
Tire
Tire
Body
Door
Door
*/