package be.kdg.craps.model.craps;

public interface CrapsToestand {

    public CrapsToestand next(int nummer);

    public String getText();
}
