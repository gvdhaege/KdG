package be.kdg.craps.model.users;

public final class Gebruiker {
    private final String naam;
    private final String wachtwoord;

    public Gebruiker(String naam, String wachtwoord) {
        this.naam = naam;
        this.wachtwoord = wachtwoord;
    }

    public String getNaam() {
        return naam;
    }

    public String getWachtwoord() {
        return wachtwoord;
    }
}
