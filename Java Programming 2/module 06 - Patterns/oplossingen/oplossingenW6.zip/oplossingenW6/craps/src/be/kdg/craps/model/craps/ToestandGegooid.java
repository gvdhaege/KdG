package be.kdg.craps.model.craps;

public class ToestandGegooid implements CrapsToestand {
    private static int teGooienWaarde;

    public static void setTeGooienWaarde(int tgw) {
        teGooienWaarde = tgw;
    }

    public static int getTeGooienWaarde() {
            return teGooienWaarde;
        }

    public CrapsToestand next(int nummer) {
        if (nummer == 7) {
            return CrapsToestandFactory.getToestandVerloren();
        } else if (nummer == teGooienWaarde) {
            return CrapsToestandFactory.getToestandGewonnen();
        }
        return this;
    }

    public String getText() {
        return "gooi een " + teGooienWaarde + " om te winnen";
    }
}
