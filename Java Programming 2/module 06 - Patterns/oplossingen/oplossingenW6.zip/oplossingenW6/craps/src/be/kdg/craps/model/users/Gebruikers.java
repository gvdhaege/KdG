package be.kdg.craps.model.users;

import java.util.HashMap;
import java.util.Map;

public class Gebruikers {
    private static Gebruikers enigeGebruikers = new Gebruikers();
    private Map<String, Gebruiker> gebruikers;

    private Gebruikers() {
        this.gebruikers = new HashMap<String, Gebruiker>();
        gebruikers.put("bla", new Gebruiker("bla", "bla"));
    }

    public static Gebruikers getInstance() {
        return enigeGebruikers;
    }

    public boolean login(String naam, String wachtwoord) {
        Gebruiker gebruiker = gebruikers.get(naam);
        if (gebruiker == null) return false;
        return gebruiker.getWachtwoord().equals(wachtwoord);
    }
}
