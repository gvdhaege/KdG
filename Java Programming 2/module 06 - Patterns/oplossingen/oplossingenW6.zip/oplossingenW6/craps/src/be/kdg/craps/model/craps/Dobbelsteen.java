package be.kdg.craps.model.craps;

public interface Dobbelsteen {
    void gooi();

    int getWaarde();
}
