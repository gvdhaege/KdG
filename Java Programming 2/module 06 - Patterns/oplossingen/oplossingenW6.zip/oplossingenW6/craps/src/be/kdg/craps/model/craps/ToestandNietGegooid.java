package be.kdg.craps.model.craps;

/**
 * Created by IntelliJ IDEA.
 * Gebruiker: Timothy
 * Date: 29-nov-2010
 * Time: 11:25:00
 * To change this template use File | Settings | File Templates.
 */
public class ToestandNietGegooid implements CrapsToestand{

    public CrapsToestand next(int nummer) {
            if (nummer == 2 || nummer == 3 || nummer == 12) {
               return CrapsToestandFactory.getToestandVerloren();
            } else if (nummer == 7 || nummer == 11) {
                return CrapsToestandFactory.getToestandGewonnen();

            } else {
                return CrapsToestandFactory.getToestandGegooid(nummer);
            }
    }

    public String getText() {
        return "druk op gooi op te beginnen";
    }
}
