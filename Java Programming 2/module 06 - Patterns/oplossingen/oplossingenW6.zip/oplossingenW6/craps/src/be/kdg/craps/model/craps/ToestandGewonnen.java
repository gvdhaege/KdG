package be.kdg.craps.model.craps;

/**
 * Created by IntelliJ IDEA.
 * Gebruiker: Timothy
 * Date: 29-nov-2010
 * Time: 11:27:30
 * To change this template use File | Settings | File Templates.
 */
public class ToestandGewonnen implements CrapsToestand{

    public CrapsToestand next(int nummer) {
        return this;
    }

    public String getText() {
        return "u hebt dit spel gewonnen!";
    }
}
