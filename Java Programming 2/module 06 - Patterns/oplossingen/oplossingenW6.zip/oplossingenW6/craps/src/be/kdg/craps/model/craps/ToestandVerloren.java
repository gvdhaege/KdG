package be.kdg.craps.model.craps;

/**
 * Created by IntelliJ IDEA.
 * Gebruiker: Timothy
 * Date: 29-nov-2010
 * Time: 11:28:53
 * To change this template use File | Settings | File Templates.
 */
public class ToestandVerloren implements CrapsToestand{

    public CrapsToestand next(int nummer) {
        return this;
    }

    public String getText() {
        return "U hebt dit spel verloren!";
    }
}
