package be.kdg.craps.model.craps;

import be.kdg.craps.model.users.Gebruikers;


public class BeveiligdCrapsSpel implements CrapsSpel {
    private CrapsSpel crapsSpell;
    private boolean loginOK;

    public BeveiligdCrapsSpel(CrapsSpel crapsSpell, String naam, String wachtwoord) {
        this.crapsSpell = crapsSpell;
        Gebruikers gebruikers = Gebruikers.getInstance();
        loginOK = gebruikers.login(naam, wachtwoord);
    }

    public void reset() {
        if (loginOK)
            crapsSpell.reset();
        else
            throw new IllegalAccessError();
    }

    public CrapsToestand getToestand() {
        if (loginOK) {
            return crapsSpell.getToestand();
        } else {
            throw new IllegalAccessError();
        }
    }

    public void gooi() {
        if (loginOK) {
            crapsSpell.gooi();
        } else {
            throw new IllegalAccessError();
        }
    }

    public int getDobbelsteen(int nummer) {
        if (loginOK) {
            return crapsSpell.getDobbelsteen(nummer);
        } else {
            throw new IllegalAccessError();
        }

    }
}
