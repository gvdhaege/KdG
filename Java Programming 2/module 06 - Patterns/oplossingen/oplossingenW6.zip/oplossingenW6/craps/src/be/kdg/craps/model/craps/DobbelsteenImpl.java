package be.kdg.craps.model.craps;

import be.kdg.craps.model.craps.Dobbelsteen;

public class DobbelsteenImpl implements Dobbelsteen {
    private int waarde = 0;

    public void gooi() {
        this.waarde = (int)(Math.random() * 6 + 1);
    }

    public int getWaarde() {
        return waarde;
    }
}
