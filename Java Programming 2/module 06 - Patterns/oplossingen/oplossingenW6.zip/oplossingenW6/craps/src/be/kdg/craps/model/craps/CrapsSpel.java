package be.kdg.craps.model.craps;

public interface CrapsSpel {

    public void reset();

    public CrapsToestand getToestand();

    public void gooi();

    public int getDobbelsteen(int nummer);
}
