package be.kdg.craps.model.craps;

public class CrapsToestandFactory {
    private static CrapsToestand gewonnen = new ToestandGewonnen();
    private static CrapsToestand verloren = new ToestandVerloren();
    private static CrapsToestand nietgegooid = new ToestandNietGegooid();
    private static CrapsToestand gegooid = new ToestandGegooid();

    private CrapsToestandFactory() {
    }

    static public CrapsToestand getToestandNietGegooid() {
        return nietgegooid;
    }

    static public CrapsToestand getToestandGegooid(int teGooienWaarde) {
        ToestandGegooid.setTeGooienWaarde(teGooienWaarde);
        return gegooid;
    }

    static public CrapsToestand getToestandGewonnen() {
        return gewonnen;
    }

    static public CrapsToestand getToestandVerloren() {
        return verloren;
    }
}
