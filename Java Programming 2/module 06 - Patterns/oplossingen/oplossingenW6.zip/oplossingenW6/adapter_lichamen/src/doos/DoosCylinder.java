package doos;

import lichaam.Cilinder;
/**
 * Het adapter pattern kan op 2 manieren uitgewerkt: via delegatie (object-adapter)
 * of via overerving (klasse-adapter)
 * Hier werd gekozen voor delegatie, maar het kan ook op de andere manier!
 */
public class DoosCylinder implements Doos {
    private Cilinder cilinder;

    public DoosCylinder(double straal, double hoogte) {
        cilinder = new Cilinder(straal, hoogte);
    }

    public double verpakkingsOppervlakte() {
        return (cilinder.grondvlak() * 2)
                + (cilinder.getStraal() * 2 * Math.PI * cilinder.getHoogte());
    }

    public double tapeLengte() {
        return 2 * cilinder.verticaleOmtrek();
    }

    public double volume() {
        return cilinder.volume();
    }

    @Override
    public String toString() {
        return String.format("Cylindervormige doos:\n\tvolume: %.2f m3\n\tbenodigde verpakking: %.2f m2\n\ttapelengte: %.2f m",
                volume(), verpakkingsOppervlakte(), tapeLengte());
    }
}