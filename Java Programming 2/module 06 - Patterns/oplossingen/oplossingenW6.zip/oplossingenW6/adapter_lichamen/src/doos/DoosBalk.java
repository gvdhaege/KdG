package doos;

import lichaam.Balk;

/**
 * Het adapter pattern kan op 2 manieren uitgewerkt: via delegatie (object-adapter)
 * of via overerving (klasse-adapter)
 * Hier werd gekozen voor delegatie, maar het kan ook op de andere manier!
 */
public class DoosBalk implements Doos {
    private Balk balk;

    public DoosBalk(double hoogte, double lengte, double breedte) {
        balk = new Balk(hoogte, lengte, breedte);
    }

    public double verpakkingsOppervlakte() {
        return (balk.grondvlak() * 2)
                + (balk.getHoogte() * balk.getLengte() * 2)
                + (balk.getHoogte() * balk.getBreedte() * 2);
    }

    public double tapeLengte() {
        return 2 * balk.verticaleOmtrek();
    }

    public double volume() {
        return balk.volume();
    }

    @Override
    public String toString() {
        return String.format("Balkvormige doos:\n\tvolume: %.2f m3\n\tbenodigde verpakking: %.2f m2\n\ttapelengte: %.2f m",
                volume(), verpakkingsOppervlakte(), tapeLengte());
    }
}