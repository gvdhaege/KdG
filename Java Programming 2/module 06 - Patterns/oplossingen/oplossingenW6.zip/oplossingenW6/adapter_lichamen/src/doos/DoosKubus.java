package doos;

import lichaam.Kubus;
/**
 * Het adapter pattern kan op 2 manieren uitgewerkt: via delegatie (object-adapter)
 * of via overerving (klasse-adapter)
 * Hier werd gekozen voor delegatie, maar het kan ook op de andere manier!
 */
public class DoosKubus implements Doos {
    private Kubus kubus;

    public DoosKubus(double ribbe) {
        kubus = new Kubus(ribbe);
    }

    public double verpakkingsOppervlakte() {
        return kubus.grondvlak() * 6;
    }

    public double volume() {
        return kubus.volume();
    }

    public double tapeLengte() {
        return 2 * kubus.verticaleOmtrek();
    }

    @Override
    public String toString() {
        return String.format("Kubusvormige doos:\n\tvolume: %.2f m3\n\tbenodigde verpakking: %.2f m2\n\ttapelengte: %.2f m",
                volume(), verpakkingsOppervlakte(), tapeLengte());
    }

}