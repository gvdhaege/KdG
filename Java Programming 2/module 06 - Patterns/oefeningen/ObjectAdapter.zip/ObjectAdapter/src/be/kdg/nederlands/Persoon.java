package be.kdg.nederlands;

public interface Persoon {

    String getNaam();

    Adres getAdres();

}
