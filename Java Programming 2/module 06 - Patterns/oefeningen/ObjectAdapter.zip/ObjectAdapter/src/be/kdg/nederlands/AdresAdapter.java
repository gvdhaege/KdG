package be.kdg.nederlands;

import be.kdg.english.Address;

public class AdresAdapter implements Adres {
    private Address address;

    //TODO: vul hier aan ...


}
