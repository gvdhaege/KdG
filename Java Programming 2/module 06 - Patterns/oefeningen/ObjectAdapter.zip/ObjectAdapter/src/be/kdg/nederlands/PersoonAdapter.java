package be.kdg.nederlands;

import be.kdg.english.Person;

public class PersoonAdapter implements Persoon {
    private Person person;

    // vul hier aan ...

}
