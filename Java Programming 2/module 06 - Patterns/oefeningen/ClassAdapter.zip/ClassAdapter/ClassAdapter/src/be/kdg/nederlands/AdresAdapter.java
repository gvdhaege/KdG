package be.kdg.nederlands;

import be.kdg.english.Address;
//TODO: vul hier aan ...

public class AdresAdapter extends Address implements Adres{

}