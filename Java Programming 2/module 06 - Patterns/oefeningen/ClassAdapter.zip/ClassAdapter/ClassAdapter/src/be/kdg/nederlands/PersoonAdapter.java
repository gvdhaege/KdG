package be.kdg.nederlands;

import be.kdg.english.Person;

public class PersoonAdapter extends Person implements Persoon{


	//TODO: vul hier aan ...

}
