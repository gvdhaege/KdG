package be.kdg.composite;

public class Tire implements Drawable {
    public void draw() {
        System.out.println("Tire");
    }
}
