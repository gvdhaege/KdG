package be.kdg.composite;

import java.util.ArrayList;
import java.util.List;

/**
 * Zorg ervoor dat de klasse de interface Drawable implementeert.
 * Maak een arraylist van Drawable objecten.
 * Voorzie een methode addDrawableComponent om een "Drawable" object aan de lijst toe te voegen.
 * Voorzie een methode draw om de draw methode van elke component in de lijst
 * uit te voeren
 */
public class Car  {


}

/*
Tire
Tire
Tire
Tire
Body
Door
Door
*/