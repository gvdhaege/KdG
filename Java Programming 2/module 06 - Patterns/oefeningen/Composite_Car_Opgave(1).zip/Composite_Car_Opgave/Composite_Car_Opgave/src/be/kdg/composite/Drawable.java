package be.kdg.composite;

public interface Drawable {
    public void draw();
}
