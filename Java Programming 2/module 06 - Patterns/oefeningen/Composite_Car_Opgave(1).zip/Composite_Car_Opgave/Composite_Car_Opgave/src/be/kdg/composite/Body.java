package be.kdg.composite;

public class Body implements Drawable {
    public void draw() {
        System.out.println("Body");
    }
}
