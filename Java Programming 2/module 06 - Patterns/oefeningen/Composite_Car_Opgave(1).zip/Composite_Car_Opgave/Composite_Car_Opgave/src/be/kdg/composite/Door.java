package be.kdg.composite;

public class Door implements Drawable {
    public void draw() {
        System.out.println("Door");
    }
}
