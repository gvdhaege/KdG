package doos;


public class DoosCylinder {
	public DoosCylinder(double hoogte, double lengte){
// nog te implementeren
	}

}