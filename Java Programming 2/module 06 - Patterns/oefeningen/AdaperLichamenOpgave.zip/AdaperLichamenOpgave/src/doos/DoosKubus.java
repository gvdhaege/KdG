package doos;
public class DoosKubus {
	public DoosKubus(double hoogte){
// constructor is nog te implementeren
	}
}