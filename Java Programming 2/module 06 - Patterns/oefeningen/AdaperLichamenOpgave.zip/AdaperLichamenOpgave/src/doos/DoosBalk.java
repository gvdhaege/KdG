package doos;

public class DoosBalk {
	public DoosBalk(double hoogte, double lengte, double breedte){
		// nog te implementeren
	}
}