package employee;

public enum Gender { MALE, FEMALE }
