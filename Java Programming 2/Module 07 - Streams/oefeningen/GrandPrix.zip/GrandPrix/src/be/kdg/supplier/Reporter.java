package be.kdg.supplier;

import java.util.function.Supplier;


public class Reporter {
	Supplier <Piloot> onderwerp;
	String boodschap;

	public Reporter( String boodschap,Supplier<Piloot> onderwerp) {
		this.onderwerp = onderwerp;
		this.boodschap = "\t"+boodschap;
	}

    public void verslag() {
	    // TODO: print boodschap + piloot
    }


}
