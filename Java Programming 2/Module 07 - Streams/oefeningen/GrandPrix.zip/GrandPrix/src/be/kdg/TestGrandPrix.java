package be.kdg;

import be.kdg.supplier.*;

import java.util.Arrays;
import java.util.List;

public class TestGrandPrix {

	 static List<Piloot> drivers = Arrays.asList(
		new Piloot("Mercedes", "Hamilton", 44),
		 new Piloot("Mc Laren","Vandoorne", 2),
		 new Piloot("Ferrari", "Vettel", 5),
		 new Piloot("Red Bull", "Ricciarddo", 3),
		new Piloot("Mercedes", "Rosberg", 6),
		 new Piloot("Williams", "Bottas", 77),
		new Piloot("Ferrari", "Räikkönen", 7),
		new Piloot("Williams", "Massa", 19),
		new Piloot("Red Bull", "Kvyat", 26)
	);


    public static void main(String[] args) {
    	GrandPrix francorchamps = new GrandPrix(drivers);
	    int rondes = 5;
	    for (int ronde=1;ronde <=rondes;ronde++){
    		francorchamps.rijRonde();
    		//drivers.forEach(d -> System.out.print(d.getNummer() + " "));
    		//System.out.println();
	    }


    }
}

//Ronde 1
//	Aan de leiding: Hamilton   44 Mercedes
//	Laatste: Räikkönen   7 Ferrari
//Ronde 2
//	Aan de leiding: Hamilton   44 Mercedes
//	Laatste: Kvyat      26 Red Bull
//Ronde 3
//	Aan de leiding: Vettel      5 Ferrari
//	Laatste: Kvyat      26 Red Bull
//Ronde 4
//	Aan de leiding: Vettel      5 Ferrari
//	Laatste: Kvyat      26 Red Bull
//Ronde 5
//	Aan de leiding: Hamilton   44 Mercedes
//	Laatste: Kvyat      26 Red Bull