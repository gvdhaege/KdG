package be.kdg;


import be.kdg.function.MyFunction;
import be.kdg.function.Piloot;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class TestFunction {
    public static void main(String[] args) {
        List<Piloot> drivers = Arrays.asList(
                new Piloot("Mercedes", "Hamilton", 44),
                new Piloot("Mercedes", "Rosberg", 6),
                new Piloot("Ferrari", "Vettel", 5),
                new Piloot("Ferrari", "Räikkönen", 7),
                new Piloot("Williams", "Bottas", 77),
                new Piloot("Williams", "Massa", 19),
                new Piloot("Red Bull", "Ricciarddo", 3),
                new Piloot("Red Bull", "Kvyat", 26)
        );

        MyFunction function = new MyFunction();
        // TODO: Schrijf MyFunction.somNummers met als argumenten
	   // 1. drivers
	    // 2. een functie die het nummer van een piloor geeft
	    // Druk dan het resultaat af met:
        // System.out.println("Som alle nummers: " +
        // function.somNummers(…));
        // Vul op de plaats van de puntjes de juiste parameters in.

    }
}

/*
Som alle nummers: 187
*/