package be.kdg.referentie;

@FunctionalInterface
public interface StringFunctie {
    String pasFunctieToe(String s);
}
