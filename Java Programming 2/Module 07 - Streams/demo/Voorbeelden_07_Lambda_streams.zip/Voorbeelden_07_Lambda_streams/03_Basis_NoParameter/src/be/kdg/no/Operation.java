package be.kdg.no;

@FunctionalInterface
public interface Operation {
    void runOperation();
}
