package be.kdg.supplier;


import java.util.*;

/**
 * @author Jan de Rijke.
 */
public class GrandPrix {
	private List<Piloot> drivers ;
	private Random rand = new Random();
	private Reporter[] reporters = {
		// Todo: maak 2 nieuwe reporters aan in deze array
		// reporter 1 neemt boodschap "Aan de leiding: " en een supplier die de eerste piloot in drivers toont
		// reporter 2 neemt boodschap "Laatste: " en een supplier die de laatste piloot in drivers toont
	};

	public GrandPrix(List<Piloot> drivers) {
		this.drivers = drivers;

	}

	public void rijRonde(){
		// elke ronde worden er 0 tot 9 wagens voorbijgestoken
		int manouvres =rand.nextInt(10);
		for (int i = 0; i<manouvres; i++ ){
			steekVoorbij(rand.nextInt(drivers.size()-1));
		}
		// TODO: implementeer de verslag methode in Reporter
		Arrays.stream(reporters).forEach(r -> r.verslag());
	}

	/**
	 * Steek een wagen voorbij
	 * @param positie positie van de wagen die voorbijgestoken wordt
	 */
	private void steekVoorbij(int positie) {
		//System.out.print(positie + "<");
		Piloot gepasseerd = drivers.get(positie);
		drivers.set(positie,drivers.get(positie+1));
		drivers.set(positie+1,gepasseerd);
	}
}
