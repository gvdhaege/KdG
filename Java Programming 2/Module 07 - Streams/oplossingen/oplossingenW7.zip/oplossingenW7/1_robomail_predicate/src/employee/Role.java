package employee;

public enum Role { STAFF, MANAGER, EXECUTIVE }