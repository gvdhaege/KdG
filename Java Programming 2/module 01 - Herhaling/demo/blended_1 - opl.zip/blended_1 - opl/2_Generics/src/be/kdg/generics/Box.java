package be.kdg.generics;

import java.util.ArrayList;
import java.util.List;

/**
 * Generieke multiklasse
 */
public class Box<T> {
    private List<T> myList = new ArrayList<>();

    public void add(T t) {
        myList.add(t);
    }

    public T get(int i) {
        return myList.get(i);
    }

    @Override
    public String toString() {
        return myList.toString();
    }
}