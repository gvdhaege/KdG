
import be.kdg.model.Student;

import java.time.LocalDate;
import java.util.*;

public class DemoStudent {
    public static void main(String[] args) {
        List<Student> studentList = new ArrayList<>();

        studentList.add(new Student(9999, "Charlotte Vermeulen", LocalDate.of(2000, 1, 24), "Antwerpen"));
        studentList.add(new Student(666, "Donald Trump", LocalDate.of(1946, 6, 14), "Washington"));
        studentList.add(new Student(12345, "Sam Gooris", LocalDate.of(1973, 4, 10)));
        studentList.add(new Student(12345, "Koen Schram", LocalDate.of(1967, 5, 15), "Merksem"));

        System.out.println("studentList volgens studnr:");
        Collections.sort(studentList); //default sorteerwijze
        for (Student student : studentList) {
            System.out.println(student);
        }

        System.out.println("\nstudentList volgens leeftijd:");
        Collections.sort(studentList, new Comparator<Student>() {
            @Override
            public int compare(Student o1, Student o2) {
                return o1.getGeboorte().compareTo(o2.getGeboorte());
            }
        });
        studentList.forEach(System.out::println);

        //Overzetten naar HashSet:
        System.out.println("\nHashSet:");
        Set<Student> mySet = new HashSet(studentList);
        mySet.forEach(System.out::println);

        //Overzetten naar TreeSet:
        System.out.println("\nTreeSet:");
        Set<Student> myTreeSet = new TreeSet(studentList);
        myTreeSet.forEach(System.out::println);

        //Overzetten naar TreeMap:
        System.out.println("\nTreeMap:");
        Map<Student, Double> javaScoreMap = new TreeMap<>();
        Random random = new Random();
        for (Student student : studentList) {
            javaScoreMap.put(student, random.nextDouble() * 20);
        }

        for (Map.Entry<Student, Double> entry : javaScoreMap.entrySet()) {
            System.out.printf("%s behaalde %.1f/20\n", entry.getKey().getNaam(), entry.getValue());
        }

        javaScoreMap.entrySet().forEach(e -> System.out.printf("%s behaalde %.1f/20\n", e.getKey().getNaam(), e.getValue()));
    }
}
