package be.kdg.model;

import java.time.LocalDate;

/**
 * Basisklasse
 */
public class Student implements Comparable<Student>{
    private final int studNr;
    private final String naam;
    private final LocalDate geboorte;
    private String woonplaats;

    public Student(int studNr, String naam, LocalDate geboorte, String woonplaats) {
        this.studNr = studNr;
        this.naam = naam;
        this.geboorte = geboorte;
        this.woonplaats = woonplaats;
    }

    public Student(int studNr, String naam, LocalDate geboorte) {
        this(studNr, naam, geboorte, "Onbekend");
    }

    public int getStudNr() {
        return studNr;
    }

    public String getNaam() {
        return naam;
    }

    public LocalDate getGeboorte() {
        return geboorte;
    }


    @Override
    public String toString() {
        return String.format("%-6d %-20s (°%s) --> %s", studNr, naam, geboorte, woonplaats);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Student student = (Student) o;

        return studNr == student.studNr;
    }

    @Override
    public int hashCode() {
        return studNr;
    }

    @Override
    public int compareTo(Student o) {
        return this.studNr - o.studNr;
    }
}
