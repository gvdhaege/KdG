package be.kdg.generics;

import java.util.ArrayList;
import java.util.List;

/**
 * Generieke multiklasse
 */
public class Box {

}