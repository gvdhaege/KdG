package be.kdg.model;

import java.time.LocalDate;

/**
 * Basisklasse
 */
public class Student {
    private int studNr;
    private String naam;
    private LocalDate geboorte;
    private String woonplaats;

}