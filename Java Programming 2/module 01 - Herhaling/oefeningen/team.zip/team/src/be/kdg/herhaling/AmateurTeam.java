package be.kdg.herhaling;

public class AmateurTeam {
    // geen extra attributen

    // TODO 5.1 Laat de klasse van de klasse Team overerven

    //TODO 5.2 Schrijf de nodige constructor


    // TODO 5.3 Implementeer hier de methode van de interface (show	),
    // ze toont alle informatie in verband met het team (zie TestTeam voor een voorbeeld)
    public void show() {

    }
}
