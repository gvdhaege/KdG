package be.kdg.herhaling;

public class Adres {
    private String straat;
    private int postNummer;
    private String gemeente;

    // TODO 1.1 Maak de constructor + getters


    // TODO 1.2 Override de toString methode
    public String toString() {
        return null;
    }
}
