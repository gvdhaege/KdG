package be.kdg;
import be.kdg.herhaling.*;
public class TestTeam {
	//TODO 3.6 verwijder commentaar, voer main uit en vergelijk resultaat
  /*  public static void main(String[] args) {
        Speler[] spelers = {
            new Speler(13, "Goosens Erik", "Heieinde 36", 9200, "Appels"),
            new Speler(21, "Vermeersch Marcel", new Adres("Hoogstraat 25", 9000,  "Gent")),
            new Speler(2, "Cornelis Clem", "Nationalestraat 5", 2000, "Antwerpen"),
            new Speler(13, "Gils Jos", new Adres("Kouterdreef 181", 2970, "Schilde")),

        };

        Team myTeam = new Team("De Kampioenen") {
            public void show() {
            }
        };

        for (Speler speler : spelers) {
            myTeam.voegToe(speler);
        }
        myTeam.sort();

        for (Speler speler : myTeam.getSpelers()) {
            System.out.println(speler);
        }

        System.out.print("\nZoek speler nummer 13: ");
        System.out.println(myTeam.zoekSpeler(13));
        System.out.print("Zoek speler nummer 14: ");
        System.out.println(myTeam.zoekSpeler(14));
    }
    */
}

/*
 2 Cornelis Clem        Nationalestraat 5    2000 Antwerpen
13 Goosens Erik         Heieinde 36          9200 Appels
21 Vermeersch Marcel    Hoogstraat 25        9000 Gent

Zoek speler nummer 13: 13 Goosens Erik         Heieinde 36          9200 Appels
Zoek speler nummer 14: null
 */
