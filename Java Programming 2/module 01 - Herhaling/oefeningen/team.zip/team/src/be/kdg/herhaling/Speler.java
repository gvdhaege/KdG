package be.kdg.herhaling;

public class Speler {
    private int rugNummer;
    private String naam;
    private Adres adres;

    // TODO 2.1 Maak beide constructors + een getter voor het rugNummer

    //TODO  2.2 Override de toString methode (zie gewenste uitvoer - werk met kolommen)

	//TODO  2.3 Implementeer de Comparable interface, zodat spelers gesorteerd kunnen
	// worden op naam
}
