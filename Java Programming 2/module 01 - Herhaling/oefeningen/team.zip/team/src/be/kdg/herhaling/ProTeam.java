package be.kdg.herhaling;

public class ProTeam {
    private String sponsorNaam;
    private SponsorSoort sponsorSoort;

    //TODO  6.1 Laat deze klasse van de klasse Team overerven

    // TODO 6.2 Schrijf de nodige constructor + getters voor beide attributen


    //TODO  6.3 Implementeer hier de methode van de interface (show),
    // ze toont alle informatie in verband met het team (zie verder voor een voorbeeld)
    public void show() {

    }

    //TODO  6.4  Vul de methode verhaspelSponsorNaam aan.
    // De methode dient de volgorde van de letters van de sponsornaam willekeurig door elkaar te halen
    // en als String terug te geven.
    public String verhaspelSponsorNaam() {
        String shuffledString = "";

        return shuffledString;
    }
}
