/*
    TODO: De klasse Woord implementeert de interface Deelbaar
 */
public class Woord {
    private String str;

    public Woord(String str){
        this.str = str;
    }

    public String toString() {
        return str;
    }
}
