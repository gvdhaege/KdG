import java.util.Arrays;

/*
    TODO: De klasse Reeks implementeert de interface Deelbaar.
    Als je de reeks deelt geef je de eerste helft van de reeks terug
 */
public class Reeks {
    private int[] array;

    public Reeks(int[] array){
        this.array = array;
    }

    public String toString() {
        String str = "[";
        for(int i = 0; i < array.length; i++) {
            str += array[i];
            if(i < array.length - 1) str += ", ";
        }
        return str + "]";
    }
}
