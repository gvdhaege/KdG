

public interface Deelbaar {

    public Deelbaar getHelft();
    
}
