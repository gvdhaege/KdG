
public abstract class Getal {

	public abstract void increment(int step);

	public void decrement(int step) {
		increment(-step);
	}

}


