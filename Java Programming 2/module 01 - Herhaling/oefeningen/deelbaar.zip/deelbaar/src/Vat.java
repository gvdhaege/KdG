/*
    TODO: De klasse Vat implementeert de interface Deelbaar
    als je een vat deelt, haal je er de helft van de inhoud uit

 */
public class Vat {
    int capaciteit;
    int inhoud;

    public Vat(int capaciteit, int inhoud) {
        this.capaciteit = capaciteit;
        this.inhoud = inhoud;
    }

    public String toString() {
        return "capaciteit: " + capaciteit + "l"
            + " inhoud: " + inhoud + "l";
    }
}
