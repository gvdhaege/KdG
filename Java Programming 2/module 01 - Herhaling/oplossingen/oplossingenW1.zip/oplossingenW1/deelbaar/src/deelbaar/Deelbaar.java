package deelbaar;

public interface Deelbaar {

    public void halveer();

    public Deelbaar getHelft();

}
