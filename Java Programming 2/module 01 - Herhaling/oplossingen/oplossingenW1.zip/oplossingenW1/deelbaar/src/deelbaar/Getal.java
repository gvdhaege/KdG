package deelbaar;

public abstract class Getal {

    public abstract void increment(int step);

    public abstract void decrement(int step);

}
