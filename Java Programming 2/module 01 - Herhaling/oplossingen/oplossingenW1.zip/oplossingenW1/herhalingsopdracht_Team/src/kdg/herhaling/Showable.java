package kdg.herhaling;

public interface Showable {
    public void showTeam();
}
