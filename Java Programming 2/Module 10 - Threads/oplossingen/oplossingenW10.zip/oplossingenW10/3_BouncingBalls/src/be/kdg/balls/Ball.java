package be.kdg.balls;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.util.Duration;

public class Ball  { //extends Thread
    public final int RADIUS = 20;
    private Timeline animation;
    private Circle circle;
    private Pane box;
    private int x;
    private int y;
    private int dx = 5;
    private int dy = 5;

    public Ball(Pane pane, Color color, int x, int y) {
        circle = new Circle(x, y, RADIUS);
        box = pane;
        box.getChildren().add(circle);
        circle.setFill(color);
        this.x = x;
        this.y = y;
        animation = new Timeline(new KeyFrame(Duration.millis(20), new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent e) {
                Ball.this.moveBall();
            }
        }));
        animation.setCycleCount(Timeline.INDEFINITE);
    }

    public void moveBall() {
        x += dx;
        y += dy;

        // Controleer grenzen
        if (x < RADIUS || x > box.getWidth() - RADIUS) {
            dx *= -1; //Verander van richting
        }
        if (y < RADIUS || y > box.getHeight() - RADIUS) {
            dy *= -1; //Verander van richting
        }
        circle.setCenterX(x);
        circle.setCenterY(y);
    }

    public void run() {
        animation.play();
    }

    public void pause() {
        animation.pause();
        //super.interrupt();
    }
}
