package be.kdg.streams;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * @author Kristiaan Behiels
 * @version 1.0 5/12/2015 17:36
 *          <p>
 *          http://www.deadcoderising.com/2015-05-19-java-8-replace-traditional-for-loops-with-intstreams/
 */
public class NumberGenerator {
    private List<Integer> numbers =
            Stream.iterate(1, n -> n + 1)
                    .limit(20)
                    .collect(Collectors.toList());

    private List<Integer> bigNumbers =
            Stream.iterate(2000, n -> n + 101)
                    .limit(20)
                    .collect(Collectors.toList());

    public List<Integer> getNumbers() {
        return Collections.unmodifiableList(numbers);
    }

    public List<Integer> getBigNumbers() {
        return Collections.unmodifiableList(bigNumbers);
    }

 /*   public void controleAfdruk() {
        numbers.forEach(n -> System.out.print(n + " "));
        System.out.println();
        bigNumbers.forEach(n -> System.out.print(n + " "));
        System.out.println();
    } */
}

/*
1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20
2000 2101 2202 2303 2404 2505 2606 2707 2808 2909 3010 3111 3212 3313 3414 3515 3616 3717 3818 3919
 */
