package be.kdg.streams;

import java.util.List;
import java.util.Random;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

/**
 * @author Kristiaan Behiels
 * @version 1.0 5/12/2015 17:25
 *
 * http://stackoverflow.com/questions/23674624/how-do-i-convert-a-java-8-intstream-to-a-list
 * http://stackoverflow.com/questions/24010109/java-8-stream-reverse-order
 */
public class RunStreams {
    private static final Random generator = new Random();

    private static Runnable getRunnable(List<Integer> list) {
        return () -> {
            List<Integer> myList = list
                    .stream()
                    .filter(n -> n % 2 == 0) // % operator kan niet generiek
                    .sorted((x, y) -> y - x) //  y - x kan niet generiek
                    .collect(Collectors.toList());

            for (Integer element : myList) {
                System.out.print(element + " ");
                try {
                    TimeUnit.MILLISECONDS.sleep(generator.nextInt(1000));
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        };
    }

    public static void main(String[] args) {
        NumberGenerator generator = new NumberGenerator();
        List<Integer> numbers = generator.getNumbers();
        List<Integer> bigNumbers = generator.getBigNumbers();

        Runnable numbersRunnable = getRunnable(numbers);
        Runnable bigNunbersRunnable = getRunnable(bigNumbers);

        new Thread(numbersRunnable).start();
        new Thread(bigNunbersRunnable).start();
    }
}

/* 5 runs */

/*
20 3818 3616 3414 18 3212 3010 16 2808 14 12 2606 10 2404 2202 8 2000 6 4 2
3818 20 18 3616 16 3414 3212 14 3010 12 2808 10 2606 8 2404 2202 6 4 2000 2
3818 20 3616 18 3414 3212 16 3010 2808 2606 14 12 2404 10 2202 8 6 4 2000 2
20 3818 3616 18 3414 16 3212 14 3010 12 2808 2606 2404 2202 10 8 2000 6 4 2
20 3818 3616 18 3414 16 3212 3010 14 2808 2606 2404 12 2202 10 2000 8 6 4 2
 */
