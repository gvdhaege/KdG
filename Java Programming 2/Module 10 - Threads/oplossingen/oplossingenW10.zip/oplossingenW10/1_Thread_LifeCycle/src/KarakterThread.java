/**
 * @author Kristiaan Behiels
 * @version 1.0 18/11/13
 */
public class KarakterThread extends Thread {
    private static int counter = 0;

    @Override
    public void run() {
        while(true) {
            System.out.print((char)('a' + counter++) + " ");
            try {
                Thread.sleep(500);
            } catch(InterruptedException e) {
                break; // spring uit de loop
            }
        }
        System.out.println("Thread beëindigd");
    }
}
