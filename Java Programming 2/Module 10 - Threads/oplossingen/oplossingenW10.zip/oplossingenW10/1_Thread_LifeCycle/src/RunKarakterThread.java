import java.util.Scanner;

/**
 * @author Kristiaan Behiels
 * @version 1.0 18/11/13
 */
public class RunKarakterThread {
    public static void main(String[] args) {
        KarakterThread thread = new KarakterThread();
        System.out.printf("State: %s  Alive: %s\n", thread.getState(), thread.isAlive());

        thread.start();
        System.out.printf("State: %s  Alive: %s\n", thread.getState(), thread.isAlive());

        System.out.println("Druk <ENTER> om de thread te onderbreken...");
        Scanner scanner = new Scanner(System.in);
        scanner.nextLine();

        thread.interrupt();
        System.out.printf("State: %s  Alive: %s\n", thread.getState(), thread.isAlive());

        try {
            thread.join();
        } catch (InterruptedException e) {
            //...
        }
        System.out.printf("State: %s  Alive: %s\n", thread.getState(), thread.isAlive());
        System.out.println("Einde programma");
    }
}

/*
State: NEW  Alive: false
State: RUNNABLE  Alive: true
a Druk <ENTER> om de thread te onderbreken...
b c d e f g h i j k l m n o p q r s t u v w x
State: TIMED_WAITING  Alive: true
Thread beëindigd
State: TERMINATED  Alive: false
Einde programma
*/


