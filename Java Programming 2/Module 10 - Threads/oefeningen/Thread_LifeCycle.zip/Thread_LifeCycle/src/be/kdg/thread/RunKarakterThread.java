package be.kdg.thread;

public class RunKarakterThread {

    public static void main(String[] args) {
    	// TODO: test de lifecycle van een KarakterPrinter thread
    }
}
