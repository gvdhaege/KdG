package be.kdg.thread;

/**
 * @author Jan de Rijke.
 */
public class KarakterDrukker implements Runnable {
	private static int counter = 0;
	@Override
	public void run() {
		while (true) {
			System.out.print((char)('a' + counter++) + " ");
			try {
				Thread.sleep(500);
			} catch(InterruptedException e) {
				break; // spring uit de loop
			}
		}
		System.out.println("Thread beëindigd");
	}
}
