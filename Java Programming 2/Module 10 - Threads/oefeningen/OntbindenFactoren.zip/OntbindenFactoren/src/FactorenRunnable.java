import java.time.LocalTime;

public class FactorenRunnable implements Runnable{
    private  long getal;
    private static boolean gevonden = false;
    private long begin;
    private long einde;

    public FactorenRunnable(long begin, long einde, long teOnderzoekenGetal) {
	   this.begin=begin;
	   this.einde=einde;
	    getal = teOnderzoekenGetal;

    }

    public static boolean isGevonden(){
    	return gevonden;
    }

	@Override
	public void run() {
		System.out.println(LocalTime.now() + ": >>> onderzoek van " + begin + " tot "+
			einde);
		// TODO test of het getal deelbaar is voor alle getallen tussen begin en einde
		// Indien één deler gevonden is  druk dan de gevonden factor af, zet gevonden op true
		// en stop het onderzoek in deze thread

		System.out.println(LocalTime.now() + ": <<< onderzoek van " + begin + " tot "+einde);

	}


}
