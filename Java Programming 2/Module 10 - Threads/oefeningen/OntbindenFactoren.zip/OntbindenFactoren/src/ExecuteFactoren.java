import java.util.*;

public class ExecuteFactoren {
	private static final long DEMOGETAL = 214_577_422_401L;

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.print("Geef een getal: ");
		long getal = DEMOGETAL;
		try {
			getal = scanner.nextLong();
		} catch (InputMismatchException e) {
			// foutieve invoer, we nemen het demogetal
			getal = DEMOGETAL;
		}

		long minblokGrootte = 1000;
		long eindeTest = (long) Math.sqrt(getal);
		int processors = Runtime.getRuntime().availableProcessors();
		long maxBlokken = (long) eindeTest / minblokGrootte + 1;
		int aantalThreads = (int) (processors > maxBlokken ? maxBlokken : processors);
		long blokGrootte = eindeTest / aantalThreads + aantalThreads;
		List<Thread> threads = new ArrayList<>();
		System.err.println("Getal= " + getal);
		System.err.println("Hoogst mogelijke factor= " + eindeTest);
		System.err.println("#Threads= " + aantalThreads);
		System.err.println("blokgrootte= " + blokGrootte);

		// TODO Start aantalThreads threads die elk tot blokGrootte getallen onderzoeken

		// Indien geen factor gevonden is als alle getallen onderzocht zijn, druk dan deze
		// boodschap af
		if (!FactorenRunnable.isGevonden()) {
			System.out.println(getal + " is een priemgetal!");
		}


	}
}

/*
Geef een getal: 123456
Getal= 123456
Hoogst mogelijke factor= 351
#Threads= 1
blokgrootte= 352
21:28:42.829: >>> onderzoek van 2 tot 351
21:28:42.829: === 123456 is deelbaar door 2
21:28:42.829: <<< onderzoek van 2 tot 351
*/

/*
Geef een getal: 214.577.422.401
Getal= 214577422401
Hoogst mogelijke factor= 463225
#Threads= 8
blokgrootte= 57911
21:27:11.954: >>> onderzoek van 405386 tot 463225
21:27:11.954: >>> onderzoek van 347474 tot 405385
21:27:11.954: >>> onderzoek van 173738 tot 231649
21:27:11.954: >>> onderzoek van 289562 tot 347473
21:27:11.954: >>> onderzoek van 2 tot 57913
21:27:11.954: >>> onderzoek van 231650 tot 289561
21:27:11.970: === 214577422401 is deelbaar door 3
21:27:11.970: <<< onderzoek van 2 tot 57913
21:27:11.954: >>> onderzoek van 115826 tot 173737
21:27:11.954: >>> onderzoek van 57914 tot 115825
21:27:11.970: === 214577422401 is deelbaar door 150049
21:27:11.970: === 214577422401 is deelbaar door 450147
21:27:11.970: <<< onderzoek van 115826 tot 173737
21:27:11.970: <<< onderzoek van 405386 tot 463225
*/


/*
Geef een getal: 14.577.422.401
Getal= 14577422401
Hoogst mogelijke factor= 120736
#Threads= 8
blokgrootte= 15100
21:26:41.555: >>> onderzoek van 75507 tot 90607
21:26:41.555: >>> onderzoek van 45305 tot 60405
21:26:41.555: >>> onderzoek van 60406 tot 75506
21:26:41.555: >>> onderzoek van 90608 tot 105708
21:26:41.555: >>> onderzoek van 2 tot 15102
21:26:41.555: >>> onderzoek van 15103 tot 30203
21:26:41.555: >>> onderzoek van 105709 tot 120736
21:26:41.571: <<< onderzoek van 45305 tot 60405
21:26:41.555: >>> onderzoek van 30204 tot 45304
21:26:41.571: <<< onderzoek van 90608 tot 105708
21:26:41.571: <<< onderzoek van 75507 tot 90607
21:26:41.571: <<< onderzoek van 15103 tot 30203
21:26:41.571: <<< onderzoek van 2 tot 15102
21:26:41.571: <<< onderzoek van 60406 tot 75506
21:26:41.571: <<< onderzoek van 105709 tot 120736
21:26:41.571: <<< onderzoek van 30204 tot 45304
14577422401 is een priemgetal!

*/


/*
Geef een getal: 4.577.422.401
Getal= 4577422401
Hoogst mogelijke factor= 67656
#Threads= 8
blokgrootte= 8465
21:25:45.387: >>> onderzoek van 16934 tot 25399
21:25:45.387: >>> onderzoek van 59264 tot 67656
21:25:45.387: >>> onderzoek van 8468 tot 16933
21:25:45.387: >>> onderzoek van 42332 tot 50797
21:25:45.387: >>> onderzoek van 25400 tot 33865
21:25:45.387: >>> onderzoek van 33866 tot 42331
21:25:45.387: >>> onderzoek van 50798 tot 59263
21:25:45.402: <<< onderzoek van 16934 tot 25399
21:25:45.387: >>> onderzoek van 2 tot 8467
21:25:45.402: <<< onderzoek van 59264 tot 67656
21:25:45.402: === 4577422401 is deelbaar door 3
21:25:45.402: <<< onderzoek van 25400 tot 33865
21:25:45.402: <<< onderzoek van 2 tot 8467
21:25:45.402: <<< onderzoek van 33866 tot 42331
21:25:45.402: <<< onderzoek van 50798 tot 59263
21:25:45.402: <<< onderzoek van 42332 tot 50797
21:25:45.402: <<< onderzoek van 8468 tot 16933
*/
