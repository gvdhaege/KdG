package be.kdg.daemonrunnable;

import java.util.Scanner;

public class StartDaemonRacer {

    public static void main(String[] args) {
        //TODO Vul hier aan

    }
}
