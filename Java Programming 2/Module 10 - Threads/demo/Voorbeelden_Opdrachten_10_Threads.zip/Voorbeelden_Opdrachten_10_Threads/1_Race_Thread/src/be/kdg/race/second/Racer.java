package be.kdg.race.second;


public class Racer extends Thread {  // Let op de extends!
    private String naam;

    public Racer(String naam) {
       this.naam = naam;
    }

    //TODO Vul hier aan (run methode)

}
