package be.kdg.mastermind.model;

/**
 * Mogelijke kleuren voor een Hint
 *
 * @author Willy Wonka
 */
public enum HintColor {
    WHITE, BLACK
}
