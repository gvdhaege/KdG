package be.kdg.mastermind.model;

/**
 * De mogelijke kleuren voor een Combination
 *
 * @author Willy Wonka
 */
public enum CombinationColor {
    RED, GREEN, YELLOW, BLUE
}
