package be.kdg.mastermind.model;

/**
 * Created by vochtenh on 17/02/2016.
 */
public class MastermindException extends RuntimeException {
    public MastermindException(String s) {
        super(s);
    }
}
