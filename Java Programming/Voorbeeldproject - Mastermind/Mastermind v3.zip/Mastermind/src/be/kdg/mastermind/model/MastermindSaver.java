package be.kdg.mastermind.model;

import java.io.IOException;
import java.nio.file.Path;

/**
 * Created by vochtenh on 2/03/2016.
 */
public class MastermindSaver {
    private Mastermind model;

    public MastermindSaver(Mastermind model) {
        this.model = model;
    }

    public void save() throws IOException {
        throw new IOException("save() method not implemented yet!");
        //TODO!!!
    }

    public void load() throws IOException {
        throw new IOException("load() method not implemented yet!");
       //TODO!!!
    }
}
