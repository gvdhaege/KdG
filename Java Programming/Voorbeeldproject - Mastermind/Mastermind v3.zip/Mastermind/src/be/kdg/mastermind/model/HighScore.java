package be.kdg.mastermind.model;

/**
 * Created by vochtenh on 17/02/2016.
 */
public class HighScore {
    //TODO
}
