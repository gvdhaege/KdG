package be.kdg.mastermind.model;

import be.kdg.mastermind.Log;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by vochtenh on 16/02/2016.
 */
public class Mastermind {
    private int maxNumberOfGuesses = 9;
    private List<Combination> guesses;
    private List<Hint> hints;
    private Combination riddle;
    private boolean foundIt;

    public Mastermind() {
        riddle = new Combination();
        Log.debug("Opgave:" + riddle.toString());
        guesses = new ArrayList<>();
        hints = new ArrayList<>();
        foundIt = false;
    }

    public void doGuess(Combination guess) {
        Log.debug(guess.toString());
        if (guesses.size() >= maxNumberOfGuesses) {
            throw new MastermindException("Maximum number of guesses reached!");
        }
        guesses.add(guess);
        if (guess.equals(riddle)) {
            foundIt = true;
        } else {
            Hint hint = new Hint();
            for (int i = 0; i < Combination.COMBINATION_SIZE; i++) {
                if (riddle.getColor(i) == guess.getColor(i)) {
                    hint.addColor(HintColor.WHITE);
                } else if (riddle.contains(guess.getColor(i))) {
                    hint.addColor(HintColor.BLACK);
                }
            }
            hints.add(hint);
            Log.debug(hint.toString());
        }
    }

    public int getMaxNumberOfGuesses() {
        return maxNumberOfGuesses;
    }

    public int getCombinationSize(){
        return Combination.COMBINATION_SIZE;
    }

    public boolean playerWon(){
        return foundIt;
    }

    public boolean playerLost(){
        return !foundIt&&guesses.size() >= maxNumberOfGuesses;
    }

    public Combination getLatestGuess(){
        if (guesses.size()==0) return null;
        return guesses.get(guesses.size()-1);
    }

    public Hint getLatestHint(){
        if (hints.size()==0) return null;
        return hints.get(hints.size() - 1);
    }

    public int getNumberOfGuessesDone(){
        return guesses.size();
    }

    public boolean gameFinished() {
        return foundIt||(getNumberOfGuessesDone()==getMaxNumberOfGuesses());
    }

    public Combination getRiddle() {
        return riddle;
    }

    public void saveGame() throws MastermindException {
        MastermindSaver saver = new MastermindSaver(this);
        try {
            saver.save();
        } catch (IOException e) {
            Log.error(e.getMessage());//you could save to logfile
            throw new MastermindException("Error while saving to disk.");
        }
    }
}
