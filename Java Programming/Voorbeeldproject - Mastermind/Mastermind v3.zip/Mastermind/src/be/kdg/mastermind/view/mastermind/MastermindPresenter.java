package be.kdg.mastermind.view.mastermind;

import be.kdg.mastermind.Log;
import be.kdg.mastermind.model.*;
import be.kdg.mastermind.view.about.AboutPresenter;
import be.kdg.mastermind.view.about.AboutView;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ChoiceDialog;
import javafx.scene.image.ImageView;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.io.IOException;

/**
 * Created by vochtenh on 16/02/2016.
 */
public class MastermindPresenter {
    private Mastermind model;
    private MastermindView view;

    public MastermindPresenter(Mastermind model, MastermindView view) {
        this.model = model;
        this.view = view;
        updateView();
        addEventHandlers();
    }


    private void updateView() {
        if (model.gameFinished()) {
            showFinishedDialog();
        }
        int rowNrInView = model.getMaxNumberOfGuesses() - model.getNumberOfGuessesDone();
        //show latest hint
        if (model.getNumberOfGuessesDone() > 0) {
            Hint hint = model.getLatestHint();
            HintView hintView = view.getGameboardView().getHintViews()[rowNrInView];
            Circle[] circles = hintView.getCircles();
            for (int i = 0; i < hint.size(); i++) {
                if (hint.getHintColor(i) == HintColor.BLACK) {
                    circles[i].setFill(Color.BLACK);
                } else if (hint.getHintColor(i) == HintColor.WHITE) {
                    circles[i].setFill(Color.WHITE);
                }
            }
            //disable this row
            CombinationPresenter combinationPresenter = view.getGameboardView().getCombinationPresenters()[rowNrInView];
            combinationPresenter.setIsEnabled(false);
        }
        //enable next row
        CombinationPresenter combinationPresenter = view.getGameboardView().getCombinationPresenters()[rowNrInView - 1];
        combinationPresenter.setIsEnabled(true);
    }

    private void addEventHandlers() {
        addMenuEventHandlers();
        view.getBtnCheck().setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                //create new Combination object and doGuess!
                int rowNumber = model.getMaxNumberOfGuesses() - model.getNumberOfGuessesDone() - 1;
                CombinationPresenter combinationPresenter = view.getGameboardView().getCombinationPresenters()[rowNumber];
                Combination combination = combinationPresenter.getCombination();
                model.doGuess(combination);
                updateView();
            }
        });
    }

    private void addMenuEventHandlers() {
        view.getMiExit().setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                Platform.exit();
            }
        });
        view.getMiAbout().setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                AboutView aboutView = new AboutView();
                new AboutPresenter(model, aboutView);
                Stage aboutStage = new Stage();
                aboutStage.initOwner(view.getScene().getWindow());
                aboutStage.initModality(Modality.APPLICATION_MODAL);
                aboutStage.setScene(new Scene(aboutView));
                aboutStage.setX(view.getScene().getWindow().getX());
                aboutStage.setY(view.getScene().getWindow().getY() + 100);
                aboutStage.showAndWait();
            }
        });
        view.getMiSave().setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                try {
                    model.saveGame();
                } catch (MastermindException e) {
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Unable to save:");
                    alert.setContentText(e.getMessage());
                    alert.showAndWait();
                }
            }
        });
        //TODO: other menu's!
    }

    private void showFinishedDialog() {
        Log.debug("showing finished");
        if (!model.gameFinished()) return;
        ChoiceDialog<String> again = new ChoiceDialog<String>("Ok", "Ok", "Nope");
        if (model.playerLost()) {
            again.setTitle("You Lost!");
            again.setHeaderText("The correct combination was:");
            CombinationView combinationView = new CombinationView();
            new CombinationPresenter(model.getRiddle(),combinationView);
            again.setGraphic(combinationView);
        } else {
            again.setTitle("You Won!");
            again.setGraphic(new ImageView("resources/images/duim.png"));
            again.setHeaderText("You found it in " + model.getNumberOfGuessesDone() + " moves...");
        }
        again.setContentText("You wanna play again?");
        again.showAndWait();
        String result = again.getResult();
        if (result == null || result.equals("Nope")) {
            Platform.exit();
        } else {
            this.model = new Mastermind();
            MastermindView newView = new MastermindView(model.getCombinationSize(),model.getMaxNumberOfGuesses());
            view.getScene().setRoot(newView);
            new MastermindPresenter(model,newView);
        }
    }
}
