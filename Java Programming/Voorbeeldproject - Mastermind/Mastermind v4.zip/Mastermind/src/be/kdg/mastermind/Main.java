package be.kdg.mastermind;

import be.kdg.mastermind.model.Mastermind;
import be.kdg.mastermind.model.MastermindException;
import be.kdg.mastermind.view.mastermind.MastermindPresenter;
import be.kdg.mastermind.view.mastermind.MastermindView;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.stage.Stage;

/**
 * Created by vochtenh on 29/12/2015.
 */
public class Main extends Application {
    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        /*Thread.currentThread().setUncaughtExceptionHandler((thread, throwable) -> {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            Log.error(throwable.getMessage());
            alert.setContentText(throwable.getMessage());
            alert.showAndWait();
            Platform.exit();
        });*/

        Mastermind model = new Mastermind();
        MastermindView view = new MastermindView(model.getCombinationSize(), model.getMaxNumberOfGuesses());
        MastermindPresenter presenter = new MastermindPresenter(model, view);
        Scene scene = new Scene(view);
        primaryStage.setScene(scene);
        presenter.addWindowEventHandlers();
        primaryStage.setTitle("Mastermind");
        primaryStage.show();

    }
}
