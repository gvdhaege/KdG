package be.kdg.mastermind.model;

import be.kdg.mastermind.Log;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

/**
 * Created by vochtenh on 14/03/2016.
 */
public class Rules {
    public static final String RULES_FILE = "rules.txt";

    private String rules = "";

    public Rules() {
        try (BufferedReader reader = new BufferedReader(new FileReader(RULES_FILE))){
            String line = "";
            while ((line=reader.readLine())!=null){
                rules += line + "\n";
            }
        } catch (IOException e) {
            e.printStackTrace();
            Log.debug("Unable to load game rules: " + e.getMessage());
            throw new MastermindException("Unable to load the game rules...");
        }
    }

    public String getRules(){
        return rules;
    }
}
