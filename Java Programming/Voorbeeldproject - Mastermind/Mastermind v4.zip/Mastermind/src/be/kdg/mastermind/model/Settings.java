package be.kdg.mastermind.model;

/**
 * Created by vochtenh on 17/02/2016.
 */
public class Settings {
    private boolean duplicateColorsAllowed = true;
    private int numberOfGuesses = 9;

    //making constructor package private, so presenters cant access it
    Settings() {
    }

    public void setDuplicateColorsAllowed(boolean duplicateColorsAllowed) {
        this.duplicateColorsAllowed = duplicateColorsAllowed;
    }

    public void setNumberOfGuesses(int numberOfGuesses) {
        this.numberOfGuesses = numberOfGuesses;
    }

    public boolean isDuplicateColorsAllowed() {
        return duplicateColorsAllowed;
    }

    public int getNumberOfGuesses() {
        return numberOfGuesses;
    }
}
