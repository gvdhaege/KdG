package be.kdg.mastermind.model;

import be.kdg.mastermind.Log;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by vochtenh on 16/02/2016.
 */
public class Mastermind {
    private List<Combination> guesses;
    private List<Hint> hints;
    private Combination riddle;
    private boolean foundIt;

    private Settings settings;

    public Mastermind() {
        settings = new Settings();
        restart();
    }

    public void restart() {
        riddle = new Combination(settings.isDuplicateColorsAllowed());
        Log.debug("Opgave:" + riddle.toString());
        guesses = new ArrayList<>();
        hints = new ArrayList<>();
        foundIt = false;
    }

    public void doGuess(Combination guess) {
        if (guess==null) throw new IllegalArgumentException("guess should not be null");
        if (guesses.size() >= settings.getNumberOfGuesses()) {
            throw new MastermindException("Maximum number of guesses reached!");
        }
        guesses.add(guess);
        if (guess.equals(riddle)) {
            foundIt = true;
        } else {
            createHint(guess);
        }
    }

    private void createHint(Combination guess) {
        Hint hint = new Hint();
        for (int i = 0; i < Combination.COMBINATION_SIZE; i++) {
            if (riddle.getColor(i) == guess.getColor(i)) {
                hint.addColor(HintColor.WHITE);
            } else if (riddle.contains(guess.getColor(i))) {
                hint.addColor(HintColor.BLACK);
            }
        }
        hints.add(hint);
        Log.debug(hint.toString());
    }

    public int getMaxNumberOfGuesses() {
        return settings.getNumberOfGuesses();
    }

    public int getCombinationSize(){
        return Combination.COMBINATION_SIZE;
    }

    public boolean playerLost(){
        return !foundIt&&guesses.size() >= settings.getNumberOfGuesses();
    }

    public int getNumberOfGuessesDone(){
        return guesses.size();
    }

    public boolean gameFinished() {
        return foundIt||(getNumberOfGuessesDone()==getMaxNumberOfGuesses());
    }

    public Combination getRiddle() {
        return riddle;
    }

    public void saveGame() throws MastermindException {
        MastermindSaver saver = new MastermindSaver(this);
        try {
            saver.save();
        } catch (IOException e) {
            Log.error(e.getMessage());//you could save to logfile
            throw new MastermindException(e);
        }
    }

    public Settings getSettings() {
        return settings;
    }

    public void loadGame() {
        MastermindSaver saver = new MastermindSaver(this);
        try {
            saver.load();
        } catch (IOException e) {
            Log.error(e.getMessage());//you could save to logfile
            throw new MastermindException(e);
        }
    }

    public List<Combination> getGuesses() {
        return guesses;
    }

    public List<Hint> getHints() {
        return hints;
    }

    void load(List<Combination> guesses, Combination riddle, Settings settings) {
        this.guesses = guesses;
        this.riddle = riddle;
        this.foundIt = false;
        this.settings = settings;
        this.hints.clear();
        for (Combination guess: guesses) {
            createHint(guess);
        }
    }
}
