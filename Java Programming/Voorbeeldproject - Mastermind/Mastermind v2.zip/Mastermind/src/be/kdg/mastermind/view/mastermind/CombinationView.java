package be.kdg.mastermind.view.mastermind;

import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;

/**
 * Created by vochtenh on 24/02/2016.
 */
public class CombinationView extends GridPane {
    private Circle[] circles;
    public CombinationView(int combinationSize) {
        circles = new Circle[combinationSize];
        for (int kolom = 0;kolom < combinationSize; kolom++){
            circles[kolom] = new Circle(20, Color.LIGHTGRAY);
            add(circles[kolom],kolom,0);
        }
        setHgap(10);
    }

    Circle[] getCircles() {
        return circles;
    }
}
