package be.kdg.mastermind.view.mastermind;

import javafx.geometry.Pos;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;

/**
 * Created by vochtenh on 24/02/2016.
 */
public class GameboardView extends GridPane {
    private CombinationView[] combinationViews;
    private HintView[] hintViews;

    public GameboardView(int combinationSize, int numberOfGuesses) {
        combinationViews = new CombinationView[numberOfGuesses];
        hintViews = new HintView[numberOfGuesses];
        for (int i=0;i<numberOfGuesses;i++){
            combinationViews[i] = new CombinationView(combinationSize);
            hintViews[i] = new HintView(combinationSize);
            HBox oneRow = new HBox(combinationViews[i], hintViews[i]);
            oneRow.setSpacing(10);
            add(oneRow,0,i);
        }
        setVgap(10);
        combinationViews[numberOfGuesses-1].getCircles()[0].setFill(Color.RED);
        combinationViews[numberOfGuesses-1].getCircles()[1].setFill(Color.GREEN);
        combinationViews[numberOfGuesses-1].getCircles()[2].setFill(Color.BLUE);
        combinationViews[numberOfGuesses-1].getCircles()[3].setFill(Color.YELLOW);
    }

    CombinationView[] getCombinationViews() {
        return combinationViews;
    }

    HintView[] getHintViews() {
        return hintViews;
    }
}
