package be.kdg.mastermind.view.mastermind;

import be.kdg.mastermind.model.Combination;
import be.kdg.mastermind.model.CombinationColor;
import be.kdg.mastermind.model.Mastermind;
import be.kdg.mastermind.view.about.AboutPresenter;
import be.kdg.mastermind.view.about.AboutView;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.stage.Modality;
import javafx.stage.Stage;

/**
 * Created by vochtenh on 16/02/2016.
 */
public class MastermindPresenter {
    private Mastermind model;
    private MastermindView view;
    public MastermindPresenter(Mastermind model, MastermindView view) {
        this.model = model;
        this.view = view;
        updateView();
        addEventHandlers();
    }

    private void updateView() {

    }

    private void addEventHandlers() {
        addMenuEventHandlers();
        view.getBtnCheck().setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                CombinationColor[] colors = new CombinationColor[model.getCombinationSize()];
                CombinationView currentCombinationView = view.getGameboardView().getCombinationViews()[(model.getMaxNumberOfGuesses()-1)-model.getNumberOfGuessesDone()];
                for (int i=0;i<colors.length;i++){
                    if (currentCombinationView.getCircles()[i].getFill().equals(Color.RED)){
                        colors[i] = CombinationColor.RED;
                    }
                    if (currentCombinationView.getCircles()[i].getFill().equals(Color.BLUE)){
                        colors[i] = CombinationColor.BLUE;
                    }
                    if (currentCombinationView.getCircles()[i].getFill().equals(Color.YELLOW)){
                        colors[i] = CombinationColor.YELLOW;
                    }
                    if (currentCombinationView.getCircles()[i].getFill().equals(Color.GREEN)){
                        colors[i] = CombinationColor.GREEN;
                    }
                }
                Combination combination = new Combination(colors);
                model.doGuess(combination);
                updateView();
            }
        });
    }

    private void addMenuEventHandlers() {
        view.getMiExit().setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                Platform.exit();
            }
        });
        view.getMiAbout().setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                AboutView aboutView = new AboutView();
                new AboutPresenter(model,aboutView);
                Stage aboutStage = new Stage();
                aboutStage.initOwner(view.getScene().getWindow());
                aboutStage.initModality(Modality.APPLICATION_MODAL);
                aboutStage.setScene(new Scene(aboutView));
                aboutStage.setX(view.getScene().getWindow().getX());
                aboutStage.setY(view.getScene().getWindow().getY() + 100);
                aboutStage.showAndWait();
            }
        });
        //TODO: other menu's!
    }
}
