package be.kdg.acteur;

public class Acteur implements Comparable<Acteur> {
    private final String naam;
    private final int geboorteJaar;

    public Acteur(String naam, int geboorteJaar) {
        this.naam = naam;
        this.geboorteJaar = geboorteJaar;
    }

    public String getNaam() {
        return naam;
    }

    public int getGeboorteJaar() {
        return geboorteJaar;
    }

    @Override
    public boolean equals(Object object) {
        if (this == object) return true;
        if (object == null || getClass() != object.getClass()) return false;

        Acteur acteur = (Acteur) object;

        return geboorteJaar == acteur.geboorteJaar && naam.equals(acteur.naam);
    }

    @Override
    public int hashCode() {
        int result = naam.hashCode();
        return 31 * result + geboorteJaar;
    }

    public int compareTo(Acteur andereActeur) {
        int jaarVerschil = geboorteJaar - andereActeur.geboorteJaar;
        if (jaarVerschil != 0) return jaarVerschil;
        return naam.compareTo(andereActeur.naam);
    }

    @Override
    public String toString() {
        return geboorteJaar + "  " + naam;
    }
}

