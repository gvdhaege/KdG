import java.util.*;

/**
 * Mark Goovaerts
 * Datum: 12-12-13
 */
public class SpeedTest {
    private List<Integer> Alist = new ArrayList<>();
    private List<Integer> Llist = new LinkedList<>();
    private Random random = new Random();

    public void maakLists(int aantal) {
        Alist.clear();
        Llist.clear();
        for (int i = 0; i < aantal; i++) {
            int getal = random.nextInt(1000);
            Alist.add(getal);
            Llist.add(getal);
        }
    }

    public String testInsertFirst(int aantal) {
        Alist.clear();
        long startTime = System.nanoTime();
        for (int i = 0; i < aantal; i++) {
            Alist.add(0, random.nextInt(1000));
        }
        long ALtime = System.nanoTime() - startTime;

        Llist.clear();
        startTime = System.nanoTime();
        for (int i = 0; i < aantal; i++) {
            Llist.add(0, random.nextInt(1000));
        }
        long LLtime = System.nanoTime() - startTime;

        return String.format("AL: %9.3f ms LL: %9.3f ms --> %s wint!",
                ALtime / 1000000000.0, LLtime / 1000000000.0, ALtime > LLtime ? "LinkedList" : "ArrayList");
    }

    public String testInsertLast(int aantal) {
        Alist.clear();
        long startTime = System.nanoTime();
        for (int i = 0; i < aantal; i++) {
            Alist.add(random.nextInt(1000));
        }
        long ALtime = System.nanoTime() - startTime;

        Llist.clear();
        startTime = System.currentTimeMillis();
        for (int i = 0; i < aantal; i++) {
            Llist.add(random.nextInt(1000));
        }
        long LLtime = System.nanoTime() - startTime;

        return String.format("AL: %9.3f ms LL: %9.3f ms --> %s wint!",
                ALtime / 1000000000.0, LLtime / 1000000000.0, ALtime > LLtime ? "LinkedList" : "ArrayList");
    }

    public String testDeleteFirst(int aantal) {
        maakLists(aantal);
        long startTime = System.nanoTime();
        for (int i = 0; i < aantal; i++) {
            Alist.remove(0);
        }
        long ALtime = System.nanoTime() - startTime;

        startTime = System.nanoTime();
        for (int i = 0; i < aantal; i++) {
            Llist.remove(0);
        }
        long LLtime = System.nanoTime() - startTime;

        return String.format("AL: %9.3f ms LL: %9.3f ms --> %s wint!",
                ALtime / 1000000000.0, LLtime / 1000000000.0, ALtime > LLtime ? "LinkedList" : "ArrayList");
    }

    public String testGet(int aantal) {
        maakLists(aantal);
        long startTime = System.nanoTime();
        for (int i = 0; i < aantal; i++) {
            Alist.get(random.nextInt(aantal));
        }
        long ALtime = System.nanoTime() - startTime;

        startTime = System.nanoTime();
        for (int i = 0; i < aantal; i++) {
            Llist.get(random.nextInt(aantal));
        }
        long LLtime = System.nanoTime() - startTime;

        return String.format("AL: %9.3f ms LL: %9.3f ms --> %s wint!",
                ALtime / 1000000000.0, LLtime / 1000000000.0, ALtime > LLtime ? "LinkedList" : "ArrayList");
    }

    public String testSorteren(int aantal) {
        maakLists(aantal);
        long startTime = System.nanoTime();
        Collections.sort(Alist);
        long ALtime = System.nanoTime() - startTime;

        startTime = System.nanoTime();
        Collections.sort(Llist);
        long LLtime = System.nanoTime() - startTime;

        return String.format("AL: %9.3f ms LL: %9.3f ms --> %s wint!",
                ALtime / 1000000000.0, LLtime / 1000000000.0, ALtime > LLtime ? "LinkedList" : "ArrayList");
    }
}

/*  JDK 7
Test vooraan toevoegen van 50000 elementen:
AL:     0,294 ms LL:     0,009 ms --> LinkedList wint!

Test achteraan toevoegen van 50000 elementen:
AL:     0,006 ms LL:  4227,028 ms --> ArrayList wint!

Test vooraan verwijderen van 50000 elementen:
AL:     0,463 ms LL:     0,006 ms --> LinkedList wint!

Test opzoeken van 50000 elementen:
AL:     0,005 ms LL:     2,083 ms --> ArrayList wint!

Test sorteren van 50000 elementen:
AL:     0,053 ms LL:     0,022 ms --> LinkedList wint!
 */

/* JDK 8
Test vooraan toevoegen van 50000 elementen:
AL:     0,259 ms LL:     0,007 ms --> LinkedList wint!

Test achteraan toevoegen van 50000 elementen:
AL:     0,005 ms LL:  4530,535 ms --> ArrayList wint!

Test vooraan verwijderen van 50000 elementen:
AL:     0,286 ms LL:     0,004 ms --> LinkedList wint!

Test opzoeken van 50000 elementen:
AL:     0,004 ms LL:     2,031 ms --> ArrayList wint!

Test sorteren van 50000 elementen:
AL:     0,038 ms LL:     0,027 ms --> LinkedList wint!
*/
