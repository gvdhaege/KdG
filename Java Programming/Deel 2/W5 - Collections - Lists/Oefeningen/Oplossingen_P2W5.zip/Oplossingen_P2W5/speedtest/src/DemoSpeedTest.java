/**
 * Mark Goovaerts
 * Datum: 12-12-13
 */
public class DemoSpeedTest {
    private final static int AANTAL = 50000;

    public static void main(String[] args) {
        SpeedTest speedTest = new SpeedTest();
        System.out.printf("\nTest vooraan toevoegen van %d elementen:\n", AANTAL);
        System.out.println(speedTest.testInsertFirst(AANTAL));

        System.out.printf("\nTest achteraan toevoegen van %d elementen:\n", AANTAL);
        System.out.println(speedTest.testInsertLast(AANTAL));

        System.out.printf("\nTest vooraan verwijderen van %d elementen:\n", AANTAL);
        System.out.println(speedTest.testDeleteFirst(AANTAL));

        System.out.printf("\nTest opzoeken van %d elementen:\n", AANTAL);
        System.out.println(speedTest.testGet(AANTAL));

        System.out.printf("\nTest sorteren van %d elementen:\n", AANTAL);
        System.out.println(speedTest.testSorteren(AANTAL));
    }


}
