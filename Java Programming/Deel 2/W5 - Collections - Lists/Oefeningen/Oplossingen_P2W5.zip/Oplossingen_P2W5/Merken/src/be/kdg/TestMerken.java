package be.kdg;

import be.kdg.merken.Merken;

/*
Gebruik deze klasse om je programma te testen.
 */
public class TestMerken {
    public static void main(String[] args) {
        Merken merken = new Merken();
        System.out.println(merken);

        merken.sorteer();
        System.out.println(merken);
        merken.keerOm();
        System.out.println(merken);
    }
}

/*
BMW Audi VW Ford Opel Renault Peugeot Citroen Mercedes Fiat
Audi BMW Citroen Fiat Ford Mercedes Opel Peugeot Renault VW
VW Renault Peugeot Opel Mercedes Ford Fiat Citroen BMW Audi 
*/