
public class AppStart {
    public static void main(String[] args) {
        new WereldUI();
        //new WorkingWereldUI();
    }
}
