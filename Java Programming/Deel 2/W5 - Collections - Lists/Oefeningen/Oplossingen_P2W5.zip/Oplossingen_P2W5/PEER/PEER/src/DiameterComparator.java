
import java.util.Comparator;

/**
 *
 * @author Jochen Oste
 */

public class DiameterComparator implements Comparator<Bal> {

    @Override
    public int compare(Bal o1, Bal o2) {
        return (int)(o1.getDiameter() - o2.getDiameter());
    }
}
