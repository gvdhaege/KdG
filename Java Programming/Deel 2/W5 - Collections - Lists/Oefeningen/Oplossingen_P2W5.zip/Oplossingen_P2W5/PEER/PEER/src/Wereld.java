
import java.awt.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

public class Wereld {

    public static final int BREEDTE = 500;
    public static final int HOOGTE = 400;
    private List<Bal> ballen;
    private DiameterComparator diameterComparator;

    private static Random random;

    public Wereld() {
        ballen = new ArrayList<>();

        random = new Random();
        
        diameterComparator = new DiameterComparator();
    }

    public void voegBalToe(double x, double y) {
        Bal bal = new Bal(x, y, random.nextDouble() * 40 - 20, random.nextDouble() * 40 - 20, random.nextDouble() * 20 + 20);
        ballen.add(bal);
        
        maakSnelsteRoodEnTraagsteZwart();
        
        Collections.sort(ballen, diameterComparator);
    }

    public void maakLeeg() {
        ballen.clear();
    }

    public int getAantalBallen() {
        return ballen.size();
    }

    public void beweegBallen() {
        Iterator<Bal> iterator = ballen.iterator();
        while(iterator.hasNext()) {
            iterator.next().beweeg();
        }
    }

    public void maakSnelsteRoodEnTraagsteZwart() {
        for (int i = 0; i < ballen.size(); i++) {
            ballen.get(i).setKleur(Bal.DEFAULT_BALL_COLOR);
        }
        
        Collections.min(ballen).setKleur(Color.BLACK);
        Collections.max(ballen).setKleur(Color.RED);
    }

    public void tekenBallen(Graphics g) {
        for (Bal bal : ballen) {
            g.setColor(bal.getKleur());
            g.fillOval((int) bal.getX(), (int) bal.getY(), (int) bal.getDiameter(), (int) bal.getDiameter());
        }
    }

}
