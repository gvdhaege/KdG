
public class TestBal {

    public static void main(String[] args) {
        Bal b = new Bal(10, 20, 10, 20, 10);
        Bal b2 = new Bal(13, 21, 15, 25, 10);
        System.out.println(b);
        System.out.println(b2);
        if (b.compareTo(b2) < 0) {
            System.out.println(b + " is trager dan " + b2);
        }
    }
}
