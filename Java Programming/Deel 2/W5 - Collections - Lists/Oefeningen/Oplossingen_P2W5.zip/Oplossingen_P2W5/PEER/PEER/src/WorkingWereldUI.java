
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.logging.Level;
import java.util.logging.Logger;

//HIER NIETS AANPASSEN
public class WorkingWereldUI extends JFrame {

    private Wereld wereld;
    
    public WorkingWereldUI() throws HeadlessException {
        super("balletjes...");
        wereld = new Wereld();
        wereld.voegBalToe(50, 50);
        this.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (SwingUtilities.isLeftMouseButton(e)) {
                    wereld.voegBalToe(e.getX(), e.getY());
                } else {
                    wereld.maakLeeg();
                }
            }
            
        });
        this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        this.setSize(Wereld.BREEDTE, Wereld.HOOGTE);
        this.setResizable(false);
        this.setVisible(true);
        Timer timer = new Timer(100, new ActionListener() {
         @Override
         public void actionPerformed(ActionEvent e) {
         wereld.beweegBallen();
         repaint();
         }
         });
         timer.start();
        
//         Thread thread = new Thread(new Runnable() {
//            
//            @Override
//            public void run() {
//                wereld.beweegBallen();
//                repaint();
//            }
//        });
//        
//        thread.start();
    }
    
    @Override
    public void paint(Graphics g) {
        super.paint(g);
        wereld.tekenBallen(g);
        g.setColor(Color.BLACK);
        g.drawString("Aantal ballen:" + wereld.getAantalBallen(), Wereld.BREEDTE / 2 - 10, Wereld.HOOGTE - 10);
    }
}
