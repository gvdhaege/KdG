import java.awt.*;

public class Bal implements Comparable<Bal> {
    public static final Color DEFAULT_BALL_COLOR = Color.blue;

    private double x;
    private double y;
    private Color kleur;
    private double snelheidx;
    private double snelheidy;
    private double diameter;

    public Bal(double x, double y, double snelheidx, double snelheidy, double diameter) {
        this.x = x;
        this.y = y;
        this.snelheidx = snelheidx;
        this.snelheidy = snelheidy;
        this.diameter = diameter;
        
        this.kleur = DEFAULT_BALL_COLOR;
    }

    public void beweeg() {
        x += snelheidx;
        y += snelheidy;
        if (x> Wereld.BREEDTE||x<0) snelheidx = -snelheidx;
        if (y> Wereld.HOOGTE||y<0) snelheidy = -snelheidy;
    }

    public void setKleur(Color kleur) {
        this.kleur = kleur;
    }

    public double getX() {
        return x;
    }

    public double getY() {
        return y;
    }

    public Color getKleur() {
        return kleur;
    }

    public double getSnelheid() {
        return Math.sqrt(Math.pow(snelheidx, 2) + Math.pow(snelheidy, 2));
    }

    public double getDiameter() {
        return diameter;
    }

    @Override
    public int compareTo(Bal o) {
        return (int)getSnelheid() - (int)o.getSnelheid();
    }

    @Override
    public String toString() {
        return String.format("Bal op (%4.1f-%4.1f) met snelheid %6.3f", x, y, getSnelheid());
    }

}
