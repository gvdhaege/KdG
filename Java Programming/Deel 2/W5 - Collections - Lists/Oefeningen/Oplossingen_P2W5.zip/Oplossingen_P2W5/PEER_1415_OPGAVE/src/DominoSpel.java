import Domino.DominoSteen;
import Domino.Spelbord;
import Domino.Speler;

import java.util.Scanner;

/**
 * Created by venj on 6/12/2014.
 */
public class DominoSpel {
    private static int MAXIMUM_AANTAL_SPELERS = 4;

    public static void main(String[] args) {
             //testSpel();
            //volledigSpel();
    }

    /*
    private static void testSpel() throws Exception {
        Speler s1 = new Speler("Jos");

        s1.neemNieuweSteen(new DominoSteen(1, 1)); //2
        s1.neemNieuweSteen(new DominoSteen(2, 1)); //3
        s1.neemNieuweSteen(new DominoSteen(3, 5)); //8
        s1.neemNieuweSteen(new DominoSteen(4, 6)); //10
        s1.neemNieuweSteen(new DominoSteen(1, 4)); //5
        s1.neemNieuweSteen(new DominoSteen(6, 1)); //7

        System.out.printf("Speler %s\n", s1.getNaam());
        System.out.println("Aantal punten: " + s1.getAantalPunten());
        System.out.println("Aantal stenen: " + s1.getAantalStenen());
        DominoSteen steenMetMeestePunten = s1.zoekSteen();
        if (steenMetMeestePunten == null)
            throw new Exception("Steen met hoogst aantal punten is NIET gevonden, maar is er wel...");

        System.out.println("Steen met meeste aantal punten: " + steenMetMeestePunten.toString());
        System.out.printf("Getal 1 - Getal 2: %d - %d\n", steenMetMeestePunten.getGetal1(), steenMetMeestePunten.getGetal2());
        steenMetMeestePunten.verwisselGetallen();
        System.out.println("Verwissel deze steen:" + steenMetMeestePunten.toString());
        System.out.println("Aantal stenen: " + s1.getAantalStenen());

        DominoSteen steenMetEen3 = s1.zoekSteen(3);
        if (steenMetEen3 == null)
            throw new Exception("Steen met getal 3 niet gevonden, maar zou er wel moeten inzitten");
    }
    */

    /*
    private static void volledigSpel() {
        System.out.println("Welkom bij het coolste dominospel ter wereld!!!");
        System.out.println("☺☺☺☺☺☺☺☺☺☺☺☺☺☺☺☺☺☺☺☺☺☺☺☺☺☺☺☺☺☺");

        boolean geldigeInvoer = false;

        while (!geldigeInvoer) {
            System.out.print("Hoeveel spelers doen er mee (max. " + MAXIMUM_AANTAL_SPELERS + ")? ");
            Scanner ky = new Scanner(System.in);
            int ingegevenAantal = ky.nextInt();
            if (ingegevenAantal < 1)
                System.out.println("!!Gelieve min. 1 speler op te geven!!");
            else if (ingegevenAantal > MAXIMUM_AANTAL_SPELERS)
                System.out.println("!!Maxmium " + MAXIMUM_AANTAL_SPELERS + " spelers toegestaan!!");
            else {
                geldigeInvoer = true;
                Speler[] spelers = new Speler[ingegevenAantal];
                for (int i = 0; i < ingegevenAantal; i++) {
                    System.out.printf("Geef een naam voor speler %d: ", (i + 1));
                    String ingegevenNaam = ky.next();
                    spelers[i] = new Speler(ingegevenNaam);
                }
                speelSpel(spelers);
            }
        }
    }

    private static void speelSpel(Speler[] spelers) {
        Spelbord spel = new Spelbord(spelers);
        System.out.println("==> Status na het verdelen van de stenen");
        System.out.println(spel.getStatus());

        Speler gewonnenSpeler = null;
        int ronde = 1;
        do {
            System.out.println("** RONDE " + ronde + " **");
            gewonnenSpeler = spel.speelRonde();
            System.out.println(spel.getStatus());
            ronde++;
        } while (gewonnenSpeler == null);
        System.out.println("************ GEDAAN ************");
        System.out.println("Speler " + gewonnenSpeler.getNaam() + " is gewonnen!!");
        System.out.println(spel.getAfgelegdeStenen());

    }
    */
}
