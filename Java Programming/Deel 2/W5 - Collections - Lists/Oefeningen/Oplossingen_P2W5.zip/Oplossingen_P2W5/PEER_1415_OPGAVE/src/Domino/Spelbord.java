package Domino;

import java.util.Collection;
import java.util.Random;

/**
 * Created by venj on 2/12/2014.
 */
public class Spelbord {

  /* HAAL DEZE LIJNEN CODE UIT COMMENTAAR ALS JE KLAAR BENT MET STAP 1

   public Speler speelRonde() {
        for (Speler spelerAanDeBeurt : spelers) {

            //Indien de allereerste beurt, leg de steen met de hoogste puntwaarde van de eerste speler
            if (afgelegdeStenen.size() == 0) {
                DominoSteen afTeLeggenSteen =spelerAanDeBeurt.zoekSteen();
                afgelegdeStenen.add(afTeLeggenSteen);
            } else {
                //Het is NIET de eerste beurt, dus moet de speler kijken of één van zijn
                //stenen vanvoor of vanachter toegevoegd kan worden

                boolean toevoegenVooraan = false;
                //Kan de speler een staan vanvoor toevoegen?
                DominoSteen eersteSteen = afgelegdeStenen.getFirst();
                int teMatchenGetalVanEersteSteen = eersteSteen.getGetal1();
                DominoSteen afTeLeggenSteen = spelerAanDeBeurt.zoekSteen(teMatchenGetalVanEersteSteen);

                //Neen? Kan de speler een steen vanachter toevoegen?
                if (afTeLeggenSteen != null)
                    toevoegenVooraan = true;
                else {
                    DominoSteen laatsteSteen = afgelegdeStenen.getLast();
                    int teMatchenGetalVanLaatsteSteen = laatsteSteen.getGetal2();
                    afTeLeggenSteen = spelerAanDeBeurt.zoekSteen(teMatchenGetalVanLaatsteSteen);
                }

                //Indien er een steen gevonden is, gaan we deze afleggen
                //Indien er géén steen gevonden is, moet de speler een steen uit de
                // beschikbare stapel trekken
                if(afTeLeggenSteen != null) {
                    legSteen(afTeLeggenSteen, toevoegenVooraan);
                    //Indien deze speler géén stenen meer heeft, is hij gewonnen!
                    if(spelerAanDeBeurt.getAantalStenen() == 0)
                        return spelerAanDeBeurt;
                }
                else{
                    spelerAanDeBeurt.neemNieuweSteen(neemSteenUitPot());
                    //Indien alle stenen zijn opgeraapt,
                    // dan wint de speler met het laagste aantal punten
                    if(beschikbareStenen.size() == 0){
                        return bepaalSpelerMetMinstePunten();
                    }
                }
            }
        }
        //Er is nog niemand uit deze ronde!
        return null;
    }

    private Speler bepaalSpelerMetMinstePunten(){
        return null;
    }

    private void legSteen(DominoSteen afTeLeggenSteen, boolean vooraanToevoegen){

    }

    private DominoSteen neemSteenUitPot(){
        return null;
    }

    */
}
