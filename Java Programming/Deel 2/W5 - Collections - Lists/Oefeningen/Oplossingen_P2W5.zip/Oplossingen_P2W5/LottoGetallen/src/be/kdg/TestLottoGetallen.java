package be.kdg;

import be.kdg.lottogetallen.LottoGetallen;

/**
 * De klasse TestLottoGetallen maakt via de constructor een nieuw LottoGetallen-object.
 * Voer 40 keer na mekaar de methode genereerLottoGetallen uit en
 * toon de getallen telkens op één regel door gebruik te maken van de methode toonLottoGetallen.
 */
public class TestLottoGetallen {
    public static void main(String[] args) {
        LottoGetallen getallen = new LottoGetallen();

        for (int i = 0; i < 40; i++) {
            getallen.genereerLottoGetallen();
            System.out.println(getallen.toonLottoGetallen());
        }
    }
}

// Een mogelijke uitvoer:
/*
  3  19  24  33  37  41
 23  24  35  37  42  44
  8   9  14  29  33  40
  7  24  31  38  42  45
 11  12  14  21  25  45
  1  13  19  22  31  38
  4   5  21  23  31  37
  4   8  19  32  38  44
 10  15  17  29  31  40
  3  14  20  40  41  45
  6  12  18  21  26  42
  2  13  23  25  26  31
  2  13  15  20  26  36
  4  13  21  32  34  40
  2   5  13  16  28  31
  4   5  16  18  22  37
 11  12  15  19  27  36
  7  27  29  37  38  44
  5   7   9  11  23  40
  5  16  29  33  42  44
  4   5  11  32  39  42
  4   7  13  19  28  41
 23  27  33  34  40  45
 12  24  28  33  37  38
  3  12  23  29  35  42
  4  12  13  31  33  42
  1  23  25  29  41  44
  5  18  29  39  40  42
  4   5   6  37  39  45
  1  14  21  25  27  36
 11  14  16  27  33  34
 23  25  29  30  36  45
 10  13  28  33  36  43
  6  14  20  23  30  39
 20  21  24  31  35  45
 19  23  28  31  38  44
 11  12  21  25  33  38
  2  10  15  28  30  44
  5   9  23  30  31  33
 18  21  24  26  28  32
*/