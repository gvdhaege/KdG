package personen;

/**
 * @author Kristiaan Behiels
 * @version 1.0 28/11/13
 */
public class Persoon implements Comparable<Persoon> {
    private String naam;
    private int leeftijd;
    private double gewicht;

    public Persoon() {
    }

    public Persoon(String naam, int leeftijd, double gewicht) {
        this.naam = naam;
        this.leeftijd = leeftijd;
        this.gewicht = gewicht;
    }

    public String getNaam() {
        return naam;
    }

    public int getLeeftijd() {
        return leeftijd;
    }

    public double getGewicht() {
        return gewicht;
    }

    @Override
    public boolean equals(Object object) {
        if (this == object) return true;
        if (object == null || getClass() != object.getClass()) return false;

        Persoon persoon = (Persoon) object;

        return Double.compare(persoon.gewicht, gewicht) == 0 && leeftijd == persoon.leeftijd && naam.equals(persoon.naam);
    }

    @Override
    public int hashCode() {
        int result = 31 * naam.hashCode() + leeftijd;
        long temp = Double.doubleToLongBits(gewicht);
        return 31 * result + (int) (temp ^ (temp >>> 32));
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("Persoon [naam: ");
        builder.append(naam);
        builder.append(", leeftijd: ");
        builder.append(leeftijd);
        builder.append(", gewicht: ");
        builder.append(gewicht);
        builder.append("]");
        return builder.toString();
    }

    @Override
    public int compareTo(Persoon anderePersoon) {
        return naam.compareTo(anderePersoon.naam);
    }
}
