package personen;

import java.util.*;

/**
 * @author Kristiaan Behiels          (zie p213 Opdracht 6: Eenmalig sorteren)
 * @version 1.0 28/11/13
 */
public class ListApplication {
    public static void main(String[] args) {
        List<Persoon> personen = new LinkedList<>();

        Persoon person1 = new Persoon("Homer Simpson", 43, 110);
        Persoon person2 = new Persoon("Marge Simpson", 38, 65);
        Persoon person3 = new Persoon("Bart Simpson", 10, 30);
        Persoon person4 = new Persoon("Lisa Simpson", 8, 25);
        Persoon person5 = new Persoon("Maggy Simpson", 3, 15);
        Persoon person6 = new Persoon("Mr. Burns", 65, 60);

        personen.add(person1);
        personen.add(person2);
        personen.add(person3);
        personen.add(person4);
        personen.add(person5);
        personen.add(person6);

        printPersonen(personen);

        // Volgens naam
        Collections.sort(personen);
        printPersonen(personen);

        // Volgens leeftijd
        Collections.sort(personen, new Comparator<Persoon>() {
          @Override
            public int compare(Persoon p1, Persoon p2) {
                return p1.getLeeftijd() - p2.getLeeftijd() ;
            }
        } );
        printPersonen(personen);

        // Volgens gewicht, zwaarste eerst
        Collections.sort(personen, new GewichtComparator());
        printPersonen(personen);
    }

    private static void printPersonen(List<Persoon> personen) {
        for(Persoon persoon: personen) {
            System.out.println(persoon);
        }
        System.out.println();
    }

    private static class GewichtComparator implements Comparator<Persoon> {
        @Override
        public int compare(Persoon p1, Persoon p2) {
            return Double.compare(p2.getGewicht(), p1.getGewicht());
        }
    }
}

/*
Persoon [naam: Homer Simpson, leeftijd: 43, gewicht: 110.0]
Persoon [naam: Marge Simpson, leeftijd: 38, gewicht: 65.0]
Persoon [naam: Bart Simpson, leeftijd: 10, gewicht: 30.0]
Persoon [naam: Lisa Simpson, leeftijd: 8, gewicht: 25.0]
Persoon [naam: Maggy Simpson, leeftijd: 3, gewicht: 15.0]
Persoon [naam: Mr. Burns, leeftijd: 65, gewicht: 60.0]

Persoon [naam: Bart Simpson, leeftijd: 10, gewicht: 30.0]
Persoon [naam: Homer Simpson, leeftijd: 43, gewicht: 110.0]
Persoon [naam: Lisa Simpson, leeftijd: 8, gewicht: 25.0]
Persoon [naam: Maggy Simpson, leeftijd: 3, gewicht: 15.0]
Persoon [naam: Marge Simpson, leeftijd: 38, gewicht: 65.0]
Persoon [naam: Mr. Burns, leeftijd: 65, gewicht: 60.0]

Persoon [naam: Maggy Simpson, leeftijd: 3, gewicht: 15.0]
Persoon [naam: Lisa Simpson, leeftijd: 8, gewicht: 25.0]
Persoon [naam: Bart Simpson, leeftijd: 10, gewicht: 30.0]
Persoon [naam: Marge Simpson, leeftijd: 38, gewicht: 65.0]
Persoon [naam: Homer Simpson, leeftijd: 43, gewicht: 110.0]
Persoon [naam: Mr. Burns, leeftijd: 65, gewicht: 60.0]

Persoon [naam: Homer Simpson, leeftijd: 43, gewicht: 110.0]
Persoon [naam: Marge Simpson, leeftijd: 38, gewicht: 65.0]
Persoon [naam: Mr. Burns, leeftijd: 65, gewicht: 60.0]
Persoon [naam: Bart Simpson, leeftijd: 10, gewicht: 30.0]
Persoon [naam: Lisa Simpson, leeftijd: 8, gewicht: 25.0]
Persoon [naam: Maggy Simpson, leeftijd: 3, gewicht: 15.0]
*/