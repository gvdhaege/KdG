package Domino;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.ListIterator;
import java.util.Random;

/**
 * Created by venj on 1/12/2014.
 */
public class Spelbord {
    private Speler[] spelers;
    private ArrayList<DominoSteen> beschikbareStenen;
    private LinkedList<DominoSteen> afgelegdeStenen;
    private Random randomSteenIndex;

    private final int STARTAANTAL_STENEN_PER_SPELER = 7;

    public Spelbord(Speler[] spelers) {
        this.spelers = spelers;
        beschikbareStenen = new ArrayList<DominoSteen>();
        afgelegdeStenen = new LinkedList<DominoSteen>();
        randomSteenIndex = new Random();
        genereerStenen();
        verdeelDominoStenen();
    }

    private void genereerStenen() {
        /*
        //Basis
        for (int i = 0; i < 6; i++) {
            for (int j = 0; j < 6; j++) {
                beschikbareStenen.add(new DominoSteen(i + 1, j + 1));
            }
        }
        */

        //Uitbreiding 2
        for (int i = 0; i <= 6; i++) {
            for (int j = 0; j <= i; j++) {
                beschikbareStenen.add(new DominoSteen(i, j));
            }
        }
    }

    private void verdeelDominoStenen() {
        //Uitbreiding 1
        int aantalStenenPerSpelerBijAanvang;
        if (this.spelers.length > 2)
            aantalStenenPerSpelerBijAanvang = 5;
        else
            aantalStenenPerSpelerBijAanvang = STARTAANTAL_STENEN_PER_SPELER;

        //Basis
        for (Speler speler : spelers) {
            for (int i = 0; i < aantalStenenPerSpelerBijAanvang; i++) {
                int ixSteen = randomSteenIndex.nextInt(beschikbareStenen.size());
                DominoSteen gekozenSteen = beschikbareStenen.get(ixSteen);
                speler.neemNieuweSteen(gekozenSteen);
                beschikbareStenen.remove(gekozenSteen);
            }
        }
    }


    public String getBeschikbareStenen() {
        StringBuilder sb = new StringBuilder();
        int laatsteGetal1 = 0;
        for (DominoSteen beschikbareSteen : beschikbareStenen) {
            if (laatsteGetal1 != beschikbareSteen.getGetal1()) {
                sb.append("\n");
                laatsteGetal1 = beschikbareSteen.getGetal1();
            }
            sb.append(beschikbareSteen.toString() + " ");
        }
        return sb.toString();
    }


    public String getAfgelegdeStenen() {
        StringBuilder sb = new StringBuilder();
        ListIterator<DominoSteen> iterator = afgelegdeStenen.listIterator();
        while (iterator.hasNext()) {
            sb.append(iterator.next().toString() + " ");
        }
        return sb.toString();
    }

    public String getStatus() {
        StringBuilder sb = new StringBuilder();
        for (Speler speler : spelers) {
            sb.append(String.format("Speler %s heeft %d stenen met een waarde van %d\n"
                    , speler.getNaam()
                    , speler.getAantalStenen()
                    , speler.getAantalPunten()));
        }
        sb.append("Er zijn nog " + beschikbareStenen.size() + " stenen over in de pot");
        return sb.toString();
    }

    public Speler speelRonde() {
        for (Speler spelerAanDeBeurt : spelers) {

            //Indien de allereerste beurt, leg de steen met de hoogste puntwaarde van de eerste speler
            if (afgelegdeStenen.size() == 0) {
                DominoSteen afTeLeggenSteen = spelerAanDeBeurt.zoekSteen();
                afgelegdeStenen.add(afTeLeggenSteen);
            } else {
                //Het is NIET de eerste beurt, dus moet de speler kijken of één van zijn
                //stenen vanvoor of vanachter toegevoegd kan worden

                boolean toevoegenVooraan = false;
                //Kan de speler een staan vanvoor toevoegen?
                DominoSteen eersteSteen = afgelegdeStenen.getFirst();
                int teMatchenGetalVanEersteSteen = eersteSteen.getGetal1();
                DominoSteen afTeLeggenSteen = spelerAanDeBeurt.zoekSteen(teMatchenGetalVanEersteSteen);

                //Neen? Kan de speler een steen vanachter toevoegen?
                if (afTeLeggenSteen != null)
                    toevoegenVooraan = true;
                else {
                    DominoSteen laatsteSteen = afgelegdeStenen.getLast();
                    int teMatchenGetalVanLaatsteSteen = laatsteSteen.getGetal2();
                    afTeLeggenSteen = spelerAanDeBeurt.zoekSteen(teMatchenGetalVanLaatsteSteen);
                }

                //Indien er een steen gevonden is, gaan we deze afleggen
                //Indien er géén steen gevonden is, moet de speler een steen uit de
                // beschikbare stapel trekken
                if (afTeLeggenSteen != null) {
                    legSteen(afTeLeggenSteen, toevoegenVooraan);
                    //Indien deze speler géén stenen meer heeft, is hij gewonnen!
                    if (spelerAanDeBeurt.getAantalStenen() == 0)
                        return spelerAanDeBeurt;
                } else {
                    spelerAanDeBeurt.neemNieuweSteen(neemSteenUitPot());
                    //Indien alle stenen zijn opgeraapt,
                    // dan wint de speler met het laagste aantal punten
                    if (beschikbareStenen.size() == 0) {
                        return bepaalSpelerMetMinstePunten();
                    }
                }
            }
        }
        //Er is nog niemand uit deze ronde!
        return null;
    }

    private Speler bepaalSpelerMetMinstePunten() {
        Speler spelerMetMinstePunten = spelers[0];
        for (Speler speler : spelers) {
            if (spelerMetMinstePunten.getAantalPunten() > speler.getAantalPunten())
                spelerMetMinstePunten = speler;
        }
        return spelerMetMinstePunten;
    }

    private void legSteen(DominoSteen afTeLeggenSteen, boolean vooraanToevoegen) {
        if (vooraanToevoegen) {
            int teMatchenGetalVanEersteSteen = this.afgelegdeStenen.getFirst().getGetal1();
            if (teMatchenGetalVanEersteSteen != afTeLeggenSteen.getGetal2())
                afTeLeggenSteen.verwisselGetallen();
            this.afgelegdeStenen.addFirst(afTeLeggenSteen);
        } else {
            int teMatchenGetalVanLaatsteSteen = this.afgelegdeStenen.getLast().getGetal2();
            if (teMatchenGetalVanLaatsteSteen != afTeLeggenSteen.getGetal1())
                afTeLeggenSteen.verwisselGetallen();
            this.afgelegdeStenen.addLast(afTeLeggenSteen);
        }
    }

    private DominoSteen neemSteenUitPot() {
        int ixSteen = randomSteenIndex.nextInt(beschikbareStenen.size());
        DominoSteen opgepakteSteen = beschikbareStenen.get(ixSteen);
        beschikbareStenen.remove(opgepakteSteen);
        return opgepakteSteen;
    }

}
