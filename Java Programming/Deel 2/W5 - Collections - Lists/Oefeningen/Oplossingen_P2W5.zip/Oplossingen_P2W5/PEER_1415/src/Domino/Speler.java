package Domino;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.ListIterator;

/**
 * Created by venj on 1/12/2014.
 */
public class Speler {
    private String naam;
    private ArrayList<DominoSteen> stenen;

    public Speler(String naam) {
        this.naam = naam;
        stenen = new ArrayList<DominoSteen>();
    }

    public String getNaam() {
        return naam;
    }

    public int getAantalStenen(){
        return stenen.size();
    }

    public int getAantalPunten(){
        int aantalPunten = 0;

        ListIterator<DominoSteen> iterator = stenen.listIterator();
        //Navigeer naar het laatste element
        while(iterator.hasNext())
            iterator.next();

        //Van achter naar voor navigeren
        while(iterator.hasPrevious()){
            DominoSteen huidigeSteen = iterator.previous();
            aantalPunten += huidigeSteen.getAantalPunten();
        }

        return aantalPunten;
    }

    public void neemNieuweSteen(DominoSteen nieuweSteen){
        stenen.add(nieuweSteen);
        Collections.sort(stenen);
    }

    public DominoSteen zoekSteen(int getal){
        DominoSteen gevraagdeSteen = null;
        for (DominoSteen dominoSteen : stenen) {
            if (dominoSteen.getGetal1() == getal || dominoSteen.getGetal2() == getal) {
                gevraagdeSteen = dominoSteen;
                break;
            }
        }
        if(gevraagdeSteen != null)
            stenen.remove(gevraagdeSteen);
        return gevraagdeSteen;
    }

    //Geeft de steen terug met het meeste aantal punten
    public DominoSteen zoekSteen(){
        DominoSteen steenMetHoogstAantalPunten = null;
        Iterator<DominoSteen> iterator = stenen.iterator();
        while(iterator.hasNext()){
            DominoSteen huidigeSteen = iterator.next();
            if(steenMetHoogstAantalPunten == null || steenMetHoogstAantalPunten.getAantalPunten() < huidigeSteen.getAantalPunten())
                steenMetHoogstAantalPunten = huidigeSteen;
        }

        if(steenMetHoogstAantalPunten != null)
            stenen.remove(steenMetHoogstAantalPunten);

        return steenMetHoogstAantalPunten;
    }


    @Override
    public String toString(){
        StringBuilder alleStenen = new StringBuilder();
        for (DominoSteen dominoSteen : stenen) {
            alleStenen.append(dominoSteen);
        }

        return String.format("Speler %s heeft nog volgende stenen: %s", naam, alleStenen.toString());
    }

}
