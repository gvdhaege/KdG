package be.kdg.verjaardagbis;

import java.time.LocalDate;
import java.time.Month;
import java.util.*;

/**
 * @author Kristiaan Behiels
 * @version 1.0 28/11/2014 19:54
 */
public class RunVerjaardag {
    public static void main(String[] args) {
        Persoon[] data = {
                new Persoon("Jos", LocalDate.of(0, Month.MAY, 16 )),
                new Persoon("Bas", LocalDate.of(0, Month.DECEMBER, 9)),
                new Persoon("Evy", LocalDate.of(0, Month.AUGUST, 15)),
                new Persoon("Jos", LocalDate.of(0, Month.AUGUST, 23)),
                new Persoon("Els", LocalDate.of(0, Month.APRIL, 25)),
                new Persoon("Ann", LocalDate.of(0, Month.AUGUST, 15)),
                new Persoon("Jos", LocalDate.of(0, Month.AUGUST, 3)),
                new Persoon("Els", LocalDate.of(0, Month.APRIL, 10))
        };

        List<Persoon> personen = new ArrayList<>(Arrays.asList(data));
        System.out.println("Originele lijst:");
        toonPersonen(personen);

        // Sorteer personen in volgorde van de kalender zonder gebruik te maken van de klasse Collections!
        // Kijk of je de juiste methode in de List interface kunt vinden.
        // Vergeet niet om de klasse Persoon comparable te maken.
        // De standaard sorteervolgorde is eerst op verjaardag en dan op naam.
        personen.sort(null);  // = alternatief voor Collections.sort(personen);

        System.out.println("\nGesorteerd op verjaardag:");
        toonPersonen(personen);


        // Sorteer personen alfabetisch
        personen.sort(new Comparator<Persoon>() {  // alternatief voor Collections.sort(personen, new Comparator<Persoon>() {
            @Override
            public int compare(Persoon persoon, Persoon anderePersoon) {
                String naamPersoon = persoon.getNaam();
                String naamAnderePersoon = anderePersoon.getNaam();
                LocalDate datumPersoon = persoon.getVerjaardag();
                LocalDate datumAnderePersoon = anderePersoon.getVerjaardag();

                int verschil = naamPersoon.compareTo(naamAnderePersoon);
                if (verschil != 0) {
                    return verschil;
                }
                return datumPersoon.compareTo(datumAnderePersoon);
            }
        });

        System.out.println("\nGesorteerd op naam:");
        toonPersonen(personen);
    }

    private static void toonPersonen(List<Persoon> personen) {
        for (Persoon persoon: personen) {
            System.out.println(persoon);
        }
    }
}

/*
Jos  -> 16 mei
Bas  -> 09 december
Evy  -> 15 augustus
Jos  -> 23 augustus
Els  -> 25 april
Ann  -> 15 augustus
Jos  -> 03 augustus
Els  -> 10 april

Gesorteerd op verjaardag:
Els  -> 10 april
Els  -> 25 april
Jos  -> 16 mei
Jos  -> 03 augustus
Ann  -> 15 augustus
Evy  -> 15 augustus
Jos  -> 23 augustus
Bas  -> 09 december

Gesorteerd op naam:
Ann  -> 15 augustus
Bas  -> 09 december
Els  -> 10 april
Els  -> 25 april
Evy  -> 15 augustus
Jos  -> 16 mei
Jos  -> 03 augustus
Jos  -> 23 augustus
*/

