package be.kdg.verjaardag;

public class Persoon implements Comparable<Persoon> {
    private String naam;
    private Datum verjaardag;

    public Persoon(String naam, Datum verjaardag) {
        this.naam = naam;
        this.verjaardag = verjaardag;
    }

    public Persoon(String naam, int dag, Datum.Maand maand) {
        this(naam, new Datum(dag, maand));
    }

    public String getNaam() {
        return naam;
    }

    public Datum getVerjaardag() {
        return verjaardag;
    }

    @Override
    public String toString() {
        return String.format("%-10s -> %s", naam, verjaardag);
    }

    public int compareTo(Persoon anderePersoon) {
        int verschil = verjaardag.compareTo(anderePersoon.verjaardag);
        if (verschil != 0) {
            return verschil;
        }
        return naam.compareTo(anderePersoon.naam);
    }

}
