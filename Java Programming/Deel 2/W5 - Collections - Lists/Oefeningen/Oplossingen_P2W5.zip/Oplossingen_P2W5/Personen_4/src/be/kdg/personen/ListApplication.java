package be.kdg.personen;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

/**
 * @author Kristiaan Behiels          (zie p210 Opdracht 4: List)
 * @version 1.0 28/11/13
 */
public class ListApplication {
    public static void main(String[] args) {
        List<Persoon> personen = new LinkedList<>();

        Persoon person1 = new Persoon("Homer Simpson", 43, 110);
        Persoon person2 = new Persoon("Marge Simpson", 38, 65);
        Persoon person3 = new Persoon("Bart Simpson", 10, 30);
        Persoon person4 = new Persoon("Lisa Simpson", 8, 25);
        Persoon person5 = new Persoon("Maggy Simpson", 3, 15);
        Persoon person6 = new Persoon("Maggy Simpson", 3, 15);
        Persoon person7 = new Persoon("Mr. Burns", 65, 60);

        personen.add(person1);
        personen.add(person2);
        personen.add(person3);
        personen.add(person4);
        personen.add(person5);
        personen.add(person6); // Duplicate
        personen.add(3,person7); // Index
        personen.set(3,person7); // Index

        // met for each
        for(Persoon persoon: personen) {
            System.out.println(persoon);
        }
        System.out.println();

        // met iterator
        Iterator iterator = personen.iterator();
        while (iterator.hasNext()) {
            System.out.println(iterator.next());
        }
        System.out.println();

        // omgekeerd
        for(int i = personen.size() - 1; i >= 0; i--) {
            System.out.println(personen.get(i));
        }
    }
}

/*
Persoon [naam: Homer Simpson, leeftijd: 43, gewicht: 110.0]
Persoon [naam: Marge Simpson, leeftijd: 38, gewicht: 65.0]
Persoon [naam: Bart Simpson, leeftijd: 10, gewicht: 30.0]
Persoon [naam: Mr. Burns, leeftijd: 65, gewicht: 60.0]    // tussengevoegd
Persoon [naam: Lisa Simpson, leeftijd: 8, gewicht: 25.0]
Persoon [naam: Maggy Simpson, leeftijd: 3, gewicht: 15.0]
Persoon [naam: Maggy Simpson, leeftijd: 3, gewicht: 15.0]

Persoon [naam: Homer Simpson, leeftijd: 43, gewicht: 110.0]
Persoon [naam: Marge Simpson, leeftijd: 38, gewicht: 65.0]
Persoon [naam: Bart Simpson, leeftijd: 10, gewicht: 30.0]
Persoon [naam: Mr. Burns, leeftijd: 65, gewicht: 60.0]
Persoon [naam: Lisa Simpson, leeftijd: 8, gewicht: 25.0]
Persoon [naam: Maggy Simpson, leeftijd: 3, gewicht: 15.0]
Persoon [naam: Maggy Simpson, leeftijd: 3, gewicht: 15.0]

Persoon [naam: Maggy Simpson, leeftijd: 3, gewicht: 15.0]
Persoon [naam: Maggy Simpson, leeftijd: 3, gewicht: 15.0]
Persoon [naam: Lisa Simpson, leeftijd: 8, gewicht: 25.0]
Persoon [naam: Mr. Burns, leeftijd: 65, gewicht: 60.0]
Persoon [naam: Bart Simpson, leeftijd: 10, gewicht: 30.0]
Persoon [naam: Marge Simpson, leeftijd: 38, gewicht: 65.0]
Persoon [naam: Homer Simpson, leeftijd: 43, gewicht: 110.0]

*/