package be.kdg.formule;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Piloten {
    private List<Piloot> piloten;

    public Piloten() {
        piloten = new ArrayList<>(new Data().getPiloten());
    }

    public Piloot pilootMetSnelsteTijd() {
        return Collections.min(piloten);
    }

    public Piloot pilootMetTraagsteTijd() {
        return Collections.max(piloten);
    }

    public String toonPiloten() {
        StringBuilder builder = new StringBuilder();
        for (Piloot piloot : piloten) {
            builder.append(piloot).append('\n');
        }
        return builder.toString();
    }

    public String toonGesorteerdVolgensTijd() {
        Collections.sort(piloten);
        // return toonPiloten();

        int plaats = 1;
        StringBuilder builder = new StringBuilder();
        for (Piloot piloot : piloten) {
            builder.append(String.format("%2d", plaats++)).append(' ').append(piloot).append('\n');
        }
        return builder.toString();
    }
}



