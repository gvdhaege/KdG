package be.kdg;

import be.kdg.formule.Piloten;

public class TestPiloten {
    public static void main(String[] args) {
        Piloten piloten = new Piloten();
        System.out.println(piloten.toonPiloten());

        System.out.println("\nPiloot met snelste tijd:");
        System.out.println(piloten.pilootMetSnelsteTijd());

        System.out.println("\nPiloot met traagste tijd:");
        System.out.println(piloten.pilootMetTraagsteTijd());

        System.out.println("\nKlassement:");
        System.out.println(piloten.toonGesorteerdVolgensTijd());
    }
}

/*
Mark Webber          Red Bull             1:12.810
Sebastian Vettel     Red Bull             1:12.328
Fernando Alonso      Ferrari              1:12.845
Felippe Massa        Ferrari              1:13.516
Kimi Räikkönen       Lotus                1:13.370
Lewis Hamilton       Mercedes             1:13.267
Romain Grosjean      Lotus                1:13.458
Nico Rosberg         Mercedes             1:13.424
Nico Hulkenberg      Sauber-Ferrari       1:13.911
Jenson Button        McLaren-Mercedes     1:13.871

Piloot met snelste tijd:
Sebastian Vettel     Red Bull             1:12.328

Piloot met traagste tijd:
Nico Hulkenberg      Sauber-Ferrari       1:13.911

Klassement:
Sebastian Vettel     Red Bull             1:12.328
Mark Webber          Red Bull             1:12.810
Fernando Alonso      Ferrari              1:12.845
Lewis Hamilton       Mercedes             1:13.267
Kimi Räikkönen       Lotus                1:13.370
Nico Rosberg         Mercedes             1:13.424
Romain Grosjean      Lotus                1:13.458
Felippe Massa        Ferrari              1:13.516
Jenson Button        McLaren-Mercedes     1:13.871
Nico Hulkenberg      Sauber-Ferrari       1:13.911
*/

