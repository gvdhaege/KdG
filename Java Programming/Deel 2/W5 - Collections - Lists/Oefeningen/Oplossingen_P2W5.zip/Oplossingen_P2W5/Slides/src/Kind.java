/**
 * Created by venj on 2/11/2014.
 */
public class Kind implements Comparable<Kind> {
    private String naam;
    private int leeftijd;
    private int lengte;

    public Kind (String naam, int leeftijd, int lengte){
        this.naam = naam;
        this.leeftijd = leeftijd;
        this.lengte = lengte;
    }

    public String getNaam() {
        return naam;
    }

    public int getLeeftijd() {
        return leeftijd;
    }

    public int getLengte() {
        return lengte;
    }

    @Override
    public int compareTo(Kind otherKind) {
        return naam.compareTo(otherKind.getNaam());
    }

    @Override
    public String toString() {
        return String.format("%s (%dj) is %dcm groot\n", naam, leeftijd, lengte);
    }
}