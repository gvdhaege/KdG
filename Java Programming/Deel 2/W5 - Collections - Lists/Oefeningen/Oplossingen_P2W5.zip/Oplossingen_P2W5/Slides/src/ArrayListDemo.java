import java.util.ArrayList;
import java.util.Iterator;

/**
 * Created by venj on 31/10/2014.
 */
public class ArrayListDemo {
    public static void main(String[] args) {
        ArrayList myList = new ArrayList();
        //Vul de arraylist met elementen
        myList.add("Eerste element");
        myList.add(2);
        myList.add("Derde element");

        System.out.printf("Size: %d\n", myList.size()); //3

        System.out.println(myList.get(0)); //Eerste element
        myList.set(3, "Vierde element"); //ERROR!

        System.out.println(myList.get(myList.size() - 1));
    }
}
