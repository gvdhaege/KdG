import javax.swing.text.html.HTMLDocument;
import java.util.ArrayList;
import java.util.Iterator;

/**
 * Created by venj on 31/10/2014.
 */
public class Opdracht1 {
    public static void main(String[] args) {
        ArrayList namen = new ArrayList();
        namen.add("Albert");
        namen.add("Hendrik");
        namen.add("Jozefien");
        namen.add("Annabel");
        namen.add("Adelbert");

        System.out.printf("Eerste naam: %s\n",namen.get(0));
        System.out.printf("Laatst naam: %s\n", namen.get(namen.size() - 1));
        System.out.println("Namen via for-each lus:");
        drukLijstAf(namen);
        System.out.printf("Joske in lijst? %b\n", namen.contains("Joske"));
        System.out.printf("Jozefien in lijst %b\n", namen.contains("Jozefien"));

        Iterator myIterator = namen.iterator();
        while(myIterator.hasNext()){
            String elementOfList =  (String)myIterator.next();
            if(elementOfList.startsWith("A"))
                myIterator.remove();
        }
        System.out.println("Afdruk na verwijderen van alle namen startende met \"A\"");
        drukLijstAf(namen);
    }

    private static void drukLijstAf(ArrayList lijstOmAfTeDrukken) {
        for (Object elementUitVanArrayList : lijstOmAfTeDrukken) {
            System.out.println(elementUitVanArrayList);
        }
    }
}
/*
Verwijder alle namen die met een 'A' beginnen; gebruik een iterator!
Druk opnieuw de namen af met een for-next lus.
EXTRA: Gebruik een methode en zet daarin deze code. Dan kan je die methode ook gebruiken voor stap 3
 */