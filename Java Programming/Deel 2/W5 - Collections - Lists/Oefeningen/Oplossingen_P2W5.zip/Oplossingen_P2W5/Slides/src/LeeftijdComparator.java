import java.util.Comparator;

/**
 * Created by venj on 2/11/2014.
 */
public class LeeftijdComparator implements Comparator<Kind> {
    @Override
    public int compare(Kind kind1, Kind kind2) {
        return kind1.getLeeftijd() - kind2.getLeeftijd();
    }
}
