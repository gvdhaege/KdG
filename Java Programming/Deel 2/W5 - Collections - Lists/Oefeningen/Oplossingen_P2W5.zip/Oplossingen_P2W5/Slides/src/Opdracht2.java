import java.util.ArrayList;
import java.util.Iterator;

/**
 * Created by venj on 31/10/2014.
 */
public class Opdracht2 {
    public static void main(String[] args) {
        ArrayList<String> namen = new ArrayList<String>();
        namen.add("Albert");
        namen.add("Hendrik");
        namen.add("Jozefien");
        namen.add("Annabel");
        namen.add("Adelbert");

        System.out.printf("Eerste naam: %s\n",namen.get(0));
        System.out.printf("Laatst naam: %s\n", namen.get(namen.size() - 1));
        System.out.println("Namen via for-each lus:");
        drukLijstAf(namen);
        System.out.printf("Joske in lijst? %b\n", namen.contains("Joske"));
        System.out.printf("Jozefien in lijst %b\n", namen.contains("Jozefien"));

        Iterator myIterator = namen.iterator();
        while(myIterator.hasNext()){
            String elementOfList =  (String)myIterator.next();
            if(elementOfList.startsWith("A"))
                myIterator.remove();
        }
        System.out.println("Afdruk na verwijderen van alle namen startende met \"A\"");
        drukLijstAf(namen);
    }

    private static void drukLijstAf(ArrayList<String> lijstOmAfTeDrukken) {
        for (String elementUitVanArrayList : lijstOmAfTeDrukken) {
            System.out.println(elementUitVanArrayList);
        }
    }
}
