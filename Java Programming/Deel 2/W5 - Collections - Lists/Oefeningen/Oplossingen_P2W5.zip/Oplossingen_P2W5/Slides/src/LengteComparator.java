import java.util.Comparator;

/**
 * Created by venj on 2/11/2014.
 */
public class LengteComparator implements Comparator<Kind> {
    @Override
    public int compare(Kind o1, Kind o2) {
        return o1.getLengte() - o2.getLengte();
    }
}
