import java.util.*;

/**
 * Created by venj on 31/10/2014.
 */
public class CollectionsClassDemo {
    public static void main(String[] args) {
        ArrayList<String> namen1 = new ArrayList<String>();
        namen1.add("Jos");
        namen1.add("Albertine");
        namen1.add("Maria");

        ArrayList<String> namen2 = new ArrayList<String>();
        namen2.add("Jos");
        namen2.add("Jules");
        namen2.add("Francine");

        ArrayList<String> namen3 = new ArrayList<String>();
        namen3.add("Robert");
        namen3.add("Andrea");

        System.out.printf("\n%-13s: %s", "Origineel", namen1);
        //binarySearch
        int indexOfSearchedElement = Collections.binarySearch(namen1, "Albertine");
        System.out.printf("\n%-13s: %s (index van element \"Albertine\")", "BinarySearch", indexOfSearchedElement);

        //reverse
        Collections.reverse(namen1);
        System.out.printf("\n%-13s: %s", "Reverse", namen1);
        //shuffle
        Collections.shuffle(namen1);
        System.out.printf("\n%-13s: %s", "Shuffle", namen1);
        //copy
        Collections.copy(namen2, namen1);
        System.out.printf("\n%-13s: %s (inhoud namen2)", "Copy", namen2);
        //Min & Max
        System.out.printf("\n%-13s: %s", "Min", Collections.min(namen1));
        System.out.printf("\n%-13s: %s", "Max", Collections.max(namen1));
        //Fill
        Collections.fill(namen1, "Julia");
        System.out.printf("\n%-13s: %s", "Fill", namen1);
        //addAll
        Collections.addAll(namen1, "Robert", "Magda");
        System.out.printf("\n%-13s: %s", "AddAll", namen1);
        //frequency
        int aantalOccurences = Collections.frequency(namen1, "Julia");
        System.out.printf("\n%-13s: %s (aantal keer \"Julia\" in de lijst namen1)", "Frequency", aantalOccurences);

        //disJoint
        System.out.printf("\n%-13s: %s", "Namen1", namen1);
        System.out.printf("\n%-13s: %s", "Namen2", namen2);
        System.out.printf("\n%-13s: %s", "Namen3", namen3);
        boolean namen1En2VolledigVerschillend = Collections.disjoint(namen1, namen2);
        boolean namen2En3VolledigVerschillend = Collections.disjoint(namen2, namen3);
        boolean namen1En3VolledigVerschillend = Collections.disjoint(namen1, namen3);
        System.out.printf("\n    Namen1 en Namen2 volledig verschillend? %b", namen1En2VolledigVerschillend);
        System.out.printf("\n    Namen2 en Namen3 volledig verschillend? %b", namen2En3VolledigVerschillend);
        System.out.printf("\n    Namen1 en Namen3 volledig verschillend? %b", namen1En3VolledigVerschillend);

        //sort
        Collections.sort(namen1);
        System.out.printf("\n%-13s: %s", "Sort", namen1);
    }
}
