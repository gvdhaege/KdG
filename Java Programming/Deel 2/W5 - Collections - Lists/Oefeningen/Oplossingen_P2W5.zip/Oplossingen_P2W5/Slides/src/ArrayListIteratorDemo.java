import java.lang.reflect.Array;
import java.util.*;

/**
 * Created by venj on 31/10/2014.
 */
public class ArrayListIteratorDemo {
public static void main(String[] args) {
    String[] kleurenStrings = {"rood", "magenta", "groen","geel"};
    List<String> kleurenList = new ArrayList<String>();
    kleurenList.addAll(Arrays.asList(kleurenStrings));

    String[] teVerwijderenKleuren = {"magenta","geel"};
    List<String> teVerwijderenKleurenList = Arrays.asList(teVerwijderenKleuren);

    verwijderKleuren(kleurenList, teVerwijderenKleurenList);

    System.out.println("\n\nArraylist na verwijderen: ");
    for (String overgeblevenKleur : kleurenList) {
        System.out.print(overgeblevenKleur + " ");
    }
}

private static void verwijderKleuren(Collection<String> teOverlopenKleuren,
                                     Collection<String> teVerwijderenKleuren){
    Iterator<String> iterator = teOverlopenKleuren.iterator();
    while (iterator.hasNext()) {
        if (teVerwijderenKleuren.contains(iterator.next())) {
            iterator.remove();
        }
    }
}


}
