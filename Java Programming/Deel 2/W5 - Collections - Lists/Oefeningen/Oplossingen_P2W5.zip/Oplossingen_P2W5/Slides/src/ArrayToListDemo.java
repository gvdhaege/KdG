import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

/**
 * Created by venj on 31/10/2014.
 */
public class ArrayToListDemo {
    public static void main(String[] args) {
        String[] myNames = new String[]{"Jos", "Andrea", "Albertine"};
        ArrayList<String> namesList = arrayToArrayList(myNames);
        List<String> namesList2 = Arrays.asList(myNames);
        namesList2.set(2, "Jef");
        System.out.println("=== For");
        for (int i = 0; i < namesList2.size(); i++) {
            System.out.println(namesList2.get(i));
        }
        System.out.println("=== Foreach");
        for (String s : namesList2) {
            System.out.println(s);
        }
        System.out.println("=== Iterator");
        Iterator<String> looper = namesList2.iterator();
        while (looper.hasNext()) {
            System.out.println(looper.next());
        }
    }

    private static ArrayList<String> arrayToArrayList(String[] stringArray) {
        //Maak nieuwe ArrayList aan
        ArrayList<String> stringList = new ArrayList<String>();
        //Ga over elk element uit de array m.b.v. for-each lus
        for (String elementOfArray : stringArray) {
            // Voeg elk element één voor één toe aan de nieuwe ArrayList
            stringList.add(elementOfArray);
        }
        return stringList;
    }

}
