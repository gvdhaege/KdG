import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

/**
 * Created by venj on 31/10/2014.
 */
public class Opdracht3 {
    public static void main(String[] args) {
        ArrayList getallenList = new ArrayList();
        Random generator = new Random();
        for (int i = 0; i < 15; i++) {
            getallenList.add(generator.nextInt(50));
        }

        System.out.println("Afdruk uit GetallenList");
        System.out.println(getallenList.toString());

        System.out.println("Afdruk uit GetallenArray");
        Object[] getallenArray = getallenList.toArray();
        for (Object getalUitArray : getallenArray) {
            System.out.printf("%d ", getalUitArray);
        }
        System.out.println();

        List<Object> objectenList = Arrays.asList(getallenArray);
        System.out.println("Afdruk uit objectenList");
        System.out.println(objectenList.toString());

        getallenArray[0] = 99;
        System.out.println("Afdruk uit GetallenList (na wijziging)");
        System.out.println(getallenList.toString());
        System.out.println("Afdruk uit GetallenArray (na wijziging)");
        for (Object getalUitArray : getallenArray) {
            System.out.printf("%d ", getalUitArray);
        }
        System.out.println();
        System.out.println("Afdruk uit objectenList (na wijziging)");
        System.out.println(objectenList.toString());
    }
}
