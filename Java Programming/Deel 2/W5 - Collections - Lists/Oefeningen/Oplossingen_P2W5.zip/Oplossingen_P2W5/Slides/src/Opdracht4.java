import java.util.*;

/**
 * Created by venj on 2/11/2014.
 */
public class Opdracht4 {
    public static void main(String[] args) {
        /*
toon de grootste
zet alle getallen op 99
Druk de frequentie van 99 af

         */
        Random generator = new Random();
        int[] getallenArray = new int[20];
        for (int i = 0; i < getallenArray.length; i++) {
            getallenArray[i] = generator.nextInt(50);
        }

        LinkedList getallenLL = new LinkedList();
        for (int i : getallenArray) {
            getallenLL.add(i);
        }

        Collections.sort(getallenLL);
        System.out.println("Gesorteerd kl => gr: " + getallenLL);
        Collections.reverse(getallenLL);
        System.out.println("Gesorteerd gr => kl: " + getallenLL);
        Collections.shuffle(getallenLL);
        System.out.println("Geschud: " + getallenLL);
        System.out.println("Grootste: " + Collections.max(getallenLL));
        System.out.println("Aantal keer 49: " + Collections.frequency(getallenLL, 49));
        Collections.fill(getallenLL, 49);
        System.out.println("Aantal keer 49: " + Collections.frequency(getallenLL, 49));
    }
}
