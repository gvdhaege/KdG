import java.util.*;

/**
 * Created by venj on 2/11/2014.
 */
public class LinkedListDemo {
    public static void main(String[] args) {
        String[] kleurenStrings = {"zwart", "groen", "paars", "zilver"};
        String[] andereKleurenStrings = {"goud", "bruin", "grijs", "zilver"};

        List<String> kleuren = new LinkedList<String>();
        List<String> andereKleuren = new LinkedList<String>();

        //LinkedList ‘andereKleuren' bevat enkel de kleuren uit array 'kleurenString'
        andereKleuren.addAll(Arrays.asList(andereKleurenStrings));
        //LinkedList ‘kleuren' bevat de kleuren uit beide arrays
        kleuren.addAll(Arrays.asList(kleurenStrings));
        kleuren.addAll(andereKleuren);

        toon(kleuren);
        System.out.print("\nVerwijder elementen met index 4 tot en met 6...\n");
        verwijderElementen(kleuren, 4, 7);
        toon(kleuren);
        toonOmgekeerd(kleuren);
    }

    private static void toon(List<String> teTonenKleuren) {
        System.out.printf("\nKleuren (%d):\n", teTonenKleuren.size());
        for (String kleur : teTonenKleuren) {
            System.out.printf("%s ", kleur);
        }
        System.out.println();
    }


    private static void verwijderElementen(List<String> kleuren,
                                           int begin, int einde) {
        List<String> teVerwijderenKleuren = kleuren.subList(begin, einde);
        teVerwijderenKleuren.set(0, "oranje");
        System.out.printf("  Volgende kleuren worden verwijderd: %s\n"
                , teVerwijderenKleuren.toString());
        teVerwijderenKleuren.clear();
    }

    private static void toonOmgekeerd(List<String> teTonenKleuren) {
        ListIterator<String> iterator
                = teTonenKleuren.listIterator(teTonenKleuren.size());
        System.out.printf("\nOmgekeerde kleuren (%d):\n", teTonenKleuren.size());
        while (iterator.hasPrevious()) {
            System.out.printf("%s ", iterator.previous());

        }
    }


}
