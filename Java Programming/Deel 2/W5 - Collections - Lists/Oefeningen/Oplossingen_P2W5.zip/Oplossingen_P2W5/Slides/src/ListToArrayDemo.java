import java.util.ArrayList;
import java.util.List;

/**
 * Created by venj on 31/10/2014.
 */
public class ListToArrayDemo {
    public static void main(String[] args) {
List<String> gemeenteList = new ArrayList<>();
gemeenteList.add("Antwerpen");
gemeenteList.add("Gent");
Object[] gemeenteArray = gemeenteList.toArray();
String[] gemeenteArray2 = gemeenteList.toArray(new String[0]);
    }
}
