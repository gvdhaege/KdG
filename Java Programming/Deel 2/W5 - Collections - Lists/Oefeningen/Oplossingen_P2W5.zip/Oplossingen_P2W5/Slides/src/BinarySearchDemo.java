import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 * Created by venj on 2/11/2014.
 */
public class BinarySearchDemo {
    public static void main(String[] args) {
        String[] kleurStrings = {"rood", "blauw", "geel", "oranje", "bruin", "zwart"};
        List<String> kleuren = new ArrayList<String>(Arrays.asList(kleurStrings));

        Collections.sort(kleuren);
        System.out.println("Kleuren: " + kleuren);
        toonZoekResultaat(kleuren, kleurStrings[0]);
        toonZoekResultaat(kleuren, "oranje");
        toonZoekResultaat(kleuren, "magenta");
    }

    private static void toonZoekResultaat(List<String> lijst, String zoekwaarde) {
        int resultaat = 0;
        System.out.println("\nZoeken naar " + zoekwaarde);
        resultaat = Collections.binarySearch(lijst, zoekwaarde);

        if (resultaat >= 0) {
            System.out.println("Gevonden op index " + resultaat);
        } else {
            System.out.println("Niet gevonden (" + resultaat + ")");
        }
    }
}
