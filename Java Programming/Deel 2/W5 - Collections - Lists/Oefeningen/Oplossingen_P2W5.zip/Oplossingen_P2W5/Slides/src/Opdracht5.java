import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;

/**
 * Created by venj on 2/11/2014.
 */
public class Opdracht5 {
    public static void main(String[] args) {
        ArrayList<Kind> kindLijst = new ArrayList<Kind>();
        kindLijst.add(new Kind("Steven", 25, 175));
        kindLijst.add(new Kind("An", 22, 180));
        kindLijst.add(new Kind("Wouter", 19, 185));

        Collections.sort(kindLijst);

        for (Kind kind : kindLijst) {
            System.out.println(kind);
        }

    }
}
