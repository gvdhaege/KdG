package be.kdg;

import be.kdg.Todo.TodoList;

/**
 * Created by venj on 6/12/2014.
 */
public class TestTodo {
    public static void main(String[] args) {
        TodoList ourList = new TodoList();
        ourList.addTodoItem("Java OO Technieken leren", 5, "8/1/2015");
        ourList.addTodoItem("Java Geavenceerde OO Technieken leren", 10, "16/3/2015");
        ourList.addTodoItem("Java game binnenleveren", 8, "10/3/2015");
        ourList.addTodoItem("Uitblazen na examens P2", 1, "19/1/2015");

        System.out.println("===== Alle todo-item van hoogste prioriteit naar laagste");
        System.out.println(ourList.getAllTodoItems(TodoList.TodoItemOrder.HIGH_TO_LOW));
        System.out.println("===== Alle todo-item van laagste prioriteit naar hoogstse");
        System.out.println(ourList.getAllTodoItems(TodoList.TodoItemOrder.LOW_TO_HIGH));
        System.out.println("===== Alle todo-item gesorteerd volgens deadline");
        System.out.println(ourList.getAllTodoItems(TodoList.TodoItemOrder.DEADLINE));
        System.out.println("===== Alle todo-item van laagste prioriteit naar hoogstse");
        System.out.println(ourList.getAllTodoItems(TodoList.TodoItemOrder.LOW_TO_HIGH));

        ourList.addTodoItem("Blokken voor Java Basisbegrippen", 1, "7/11/2014");

    }
}
