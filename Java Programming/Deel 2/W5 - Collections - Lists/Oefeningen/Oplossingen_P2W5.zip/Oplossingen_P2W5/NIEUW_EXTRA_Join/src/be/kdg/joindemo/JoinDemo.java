package be.kdg.joindemo;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * @author Kristiaan Behiels
 * @version 1.0 28/11/2014 20:34
 */
public class JoinDemo {
    public static void main(String[] args) {
        List<TelefoonNummer> nummerLijst = new ArrayList<>();

        nummerLijst.add(new TelefoonNummer("011", "102487"));
        nummerLijst.add(new TelefoonNummer("03", "6891745"));
        nummerLijst.add(new TelefoonNummer("0497", "421505"));

        // Toon de lijst, één nummer per regel
        for (TelefoonNummer nummer : nummerLijst) {
            System.out.println(nummer);
        }

        // Voeg de afzonderlijke telefoonnummers als strings samen tot één string
        // waarbij de afzonderlijke nummer gescheiden worden door
        // een spatie gevolgd door een tilde gevolgd door een spatie (zie gewenste uitvoer)

        // Zet de arraylist van Telefoon objecten om naar een array van strings.
        String[] nummers = new String[nummerLijst.size()];
        for (int i = 0; i < nummerLijst.size(); i++) {
            nummers[i] = nummerLijst.get(i).toString();
        }

        // Zoek in de klasse String naar de enige nieuwe methode in Java 8.
        String joined = String.join(" ~ ", nummers);
        System.out.println(joined);
    }
}

/*
011/10.24.87
03/689.17.45
0497/42.15.05
011/10.24.87 ~ 03/689.17.45 ~ 0497/42.15.05
*/