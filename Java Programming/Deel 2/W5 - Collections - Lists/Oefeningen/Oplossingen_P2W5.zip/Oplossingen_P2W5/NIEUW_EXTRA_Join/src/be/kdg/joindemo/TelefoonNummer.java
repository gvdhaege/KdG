package be.kdg.joindemo;

/**
 * @author Kristiaan Behiels
 * @version 1.0 28/11/2014 20:36
 */
public class TelefoonNummer {
    String zoneGetal;
    String nummer;

    public TelefoonNummer(String zoneGetal, String nummer) {
        this.zoneGetal = zoneGetal;
        this.nummer = nummer;
    }

    private String formatteerNummer() {
        if (zoneGetal.length() > 2) {
            return nummer.substring(0,2) + "." + nummer.substring(2,4) + "." + nummer.substring(4,6);
        } else {
            return nummer.substring(0,3) + "." + nummer.substring(3,5) + "." + nummer.substring(5,7);
        }
    }

    @Override
    public String toString() {
        return zoneGetal + "/" + formatteerNummer();
    }
}
