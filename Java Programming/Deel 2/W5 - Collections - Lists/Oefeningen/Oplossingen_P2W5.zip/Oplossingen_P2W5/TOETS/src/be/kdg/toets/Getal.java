package be.kdg.toets;

/**
 * @author Kristiaan Behiels
 * @version 1.0 30/11/13
 */
public class Getal implements Comparable<Getal> {
    private double waarde;

    public Getal(double waarde) {
        this.waarde = waarde;
    }

    public double getWaarde() {
        return waarde;
    }

    @Override
    public String toString() {
        return Double.toString(waarde);
    }

    @Override
    public int compareTo(Getal getal) {
        return Double.compare(waarde, getal.waarde);
    }
}
