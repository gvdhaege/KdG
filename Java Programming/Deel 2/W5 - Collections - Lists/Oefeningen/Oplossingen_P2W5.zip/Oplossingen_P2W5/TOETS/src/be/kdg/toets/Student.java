package be.kdg.toets;

/**
 * @author Kristiaan Behiels
 * @version 1.0 30/11/13
 */
public class Student {
    private String naam;

    public Student(String naam) {
        this.naam = naam;
    }

    @Override
    public String toString() {
        return naam;
    }
}
