package be.kdg.toets;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

/**
 * @author Kristiaan Behiels
 * @version 1.0 30/11/13
 */
public class RunStudent {
    public static void main(String[] args) {
        List<Student> lijst = Arrays.asList(new Student("Jos"), new Student("Jos"));
        List<Student> studenten = new LinkedList<>(lijst);
        System.out.println(studenten);
    }
}

/*
[Jos, Jos]
*/