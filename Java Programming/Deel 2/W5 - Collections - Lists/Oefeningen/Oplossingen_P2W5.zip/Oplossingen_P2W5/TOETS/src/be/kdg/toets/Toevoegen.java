package be.kdg.toets;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Kristiaan Behiels
 * @version 1.0 30/11/13
 */
public class Toevoegen {
    public static void main(String[] args) {
        List<String> namen = new ArrayList<>();
        namen.add("one");
        namen.add(0, "two");
        namen.add(2, "three");
        namen.set(1, "four");
        System.out.println(namen);
    }
}

/*
[two, four, three]
*/