package be.kdg.namen;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/*
De klasse VerwerkData bevat als enig attribuut een List met Naam objecten (lijst).
In de constructor wordt een nieuw Data-object gemaakt en via de methode getData() wordt de lijst ingevuld.
Voorzie een methode sorteerVolgensNaam waarbij je gebruikt maakt van Collections.sort(lijst).
Voorzie een methode sorteerVolgensVoornaam waarbij je gebruik maakt van een in de klasse op te nemen
VoornaamComparator klasse (deze doet een implements Comparator<Naam>).
Voorzie een methode toon waarin je gebruik maakt van een for-each om alle namen van de lijst af te drukken.
 */
public class VerwerkData {
    private List<Naam> lijst;

    public VerwerkData() {
        Data data = new Data();
        lijst = data.getData();
    }

    public void sorteerVolgensNaam() {
        Collections.sort(lijst);
    }

    public void sorteerVolgensVoornaam() {
        Collections.sort(lijst, new VoornaamComparator());
    }

    public void toon() {
        for (Naam naam : lijst) {
            System.out.println(naam);
        }
    }

    private class VoornaamComparator implements Comparator<Naam> {
        public int compare(Naam naam, Naam andereNaam) {
            String voornaam = naam.getVoornaam();
            String andereVoornaam = andereNaam.getVoornaam();
            return voornaam.compareTo(andereVoornaam);
        }
    }
}
