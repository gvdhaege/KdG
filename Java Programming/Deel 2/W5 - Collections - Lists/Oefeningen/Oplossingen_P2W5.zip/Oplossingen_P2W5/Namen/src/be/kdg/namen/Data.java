package be.kdg.namen;

import java.util.Arrays;
import java.util.List;

/*
Aan deze klasse hoef je niets te wijzigen.
 */
public class Data {
    static Naam[] namen = {
            new Naam("Tobback", "Louis"),
            new Naam("Martens", "Wilfried"),
            new Naam("Smet", "Miet"),
            new Naam("De Decker", "Jean-Pierre"),
    };

    List<Naam> getData() {
        return Arrays.asList(namen);
    }
}
