package be.kdg;

import be.kdg.namen.VerwerkData;

/*
Werk de klassen Naam en VerwerkData uit zodanig dat je de onderstaande afdruk kunt bekomen.
 */
public class Demo {
    public static void main(String[] args) {
        VerwerkData verwerkData = new VerwerkData();

        verwerkData.sorteerVolgensNaam();
        System.out.println("Volgens naam:");
        verwerkData.toon();

        verwerkData.sorteerVolgensVoornaam();
        System.out.println("\nVolgens voornaam:");
        verwerkData.toon();
    }
}

/*
Volgens naam:
Jean-Pierre De Decker
Wilfried Martens
Miet Smet
Louis Tobback

Volgens voornaam:
Jean-Pierre De Decker
Louis Tobback
Miet Smet
Wilfried Martens
*/