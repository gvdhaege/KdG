package be.kdg.namen;

/*
De klasse naam bevat twee final attributen van het type String,
met name naam en voornaam.
Zorg voor een constructor die beide attributen een waarde geeft.
Voorzie getters voor beide attributen.
Voorzie een toString methode die een string teruggeeft in de vorm voornaam naam.
Voorzie indien nodig extra methoden. 
 */
public class Naam implements Comparable<Naam> {
    private final String naam;
    private final String voornaam;

    public Naam(String naam, String voornaam) {
        this.naam = naam;
        this.voornaam = voornaam;
    }

    public String getNaam() {
        return naam;
    }

    public String getVoornaam() {
        return voornaam;
    }

    @Override
    public String toString() {
        return voornaam + " " + naam;
    }

    public int compareTo(Naam andereNaam) {
        return naam.compareTo(andereNaam.naam);
    }
}
