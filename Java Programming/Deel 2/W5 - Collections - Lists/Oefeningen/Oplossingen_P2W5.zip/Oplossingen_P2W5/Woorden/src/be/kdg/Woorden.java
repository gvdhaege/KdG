package be.kdg;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

public class Woorden {
    public static void main(String[] args) {
        System.out.println("Geef een zin:");
        final Scanner keyboard = new Scanner(System.in);
        final String zin = keyboard.nextLine().toLowerCase();

        final String[] woorden = zin.split("[ ,.!?]");

        final List<String> lijst1 = new ArrayList<String>();
        for (final String w : woorden) {
            if (!w.isEmpty()) {
                lijst1.add(w);
            }
        }

        Random random = new Random();
        final List<String> lijst2 = new ArrayList<String>();
        while (lijst1.size() > 0) {
            int index = random.nextInt(lijst1.size());
            String randomWoord = lijst1.remove(index);
            lijst2.add(randomWoord);
        }

        for (int i = 0; i < lijst2.size(); i++) {
            String w = lijst2.get(i);

            if (i == 0) {
                w = w.substring(0, 1).toUpperCase() + w.substring(1);
            }

            System.out.print(w);

            if (i != lijst2.size() - 1) {
                System.out.print(" ");
            }
            else {
                System.out.print(".");
            }
        }
    }
}
