package be.kdg;

import be.kdg.verjaardag.Datum;
import be.kdg.verjaardag.Persoon;

import java.util.*;

public class RunVerjaardag {
    public static void main(String[] args) {
        Persoon[] data = {
                new Persoon("Jos", new Datum(16, Datum.Maand.MEI)),
                new Persoon("Bas", 9, Datum.Maand.DECEMBER),
                new Persoon("Evy", 15, Datum.Maand.AUGUSTUS),
                new Persoon("Jos", 23, Datum.Maand.AUGUSTUS),
                new Persoon("Els", new Datum(25, Datum.Maand.APRIL)),
                new Persoon("Ann", 15, Datum.Maand.AUGUSTUS),
                new Persoon("Jos", 3, Datum.Maand.AUGUSTUS),
                new Persoon("Els", 10, Datum.Maand.APRIL)
        };

        List<Persoon> personen = new ArrayList<>(Arrays.asList(data));

        toonPersonen(personen);

        // Sorteer personen in volgorde van de kalender
        Collections.sort(personen);

        System.out.println("\nGesorteerd op verjaardag:");
        toonPersonen(personen);

        // Sorteer personen alfabetisch
        Collections.sort(personen, new Comparator<Persoon>() {
            public int compare(Persoon persoon, Persoon anderePersoon) {
                String naamPersoon = persoon.getNaam();
                String naamAnderePersoon = anderePersoon.getNaam();
                Datum datumPersoon = persoon.getVerjaardag();
                Datum datumAnderePersoon = anderePersoon.getVerjaardag();

                int verschil = naamPersoon.compareTo(naamAnderePersoon);
                if (verschil != 0) {
                    return verschil;
                }
                return datumPersoon.compareTo(datumAnderePersoon);
            }
        });

        System.out.println("\nGesorteerd op naam:");
        toonPersonen(personen);
    }

    private static void toonPersonen(List<Persoon> personen) {
        for (Persoon persoon: personen) {
            System.out.println(persoon);
        }
    }
}

/*
Jos        -> 16 mei
Bas        ->  9 december
Evy        -> 15 augustus
Jos        -> 23 augustus
Els        -> 25 april
Ann        -> 15 augustus
Jos        ->  3 augustus
Els        -> 10 april

Gesorteerd op verjaardag:
Els        -> 10 april
Els        -> 25 april
Jos        -> 16 mei
Jos        ->  3 augustus
Ann        -> 15 augustus
Evy        -> 15 augustus
Jos        -> 23 augustus
Bas        ->  9 december

Gesorteerd op naam:
Ann        -> 15 augustus
Bas        ->  9 december
Els        -> 10 april
Els        -> 25 april
Evy        -> 15 augustus
Jos        -> 16 mei
Jos        ->  3 augustus
Jos        -> 23 augustus
*/