package be.kdg.woordanalyse;

import java.io.IOException;

/**
 * Created by vochtenh on 18/12/2015.
 */
public class TestWoordenlijst {
    public static void main(String[] args) {
        try {
            System.out.println(Woordenlijst.getWoordenlijst().get(2000));
        } catch (IOException e) {
            System.out.println("Probleem:" + e.getMessage());
        }
    }
}
