package be.kdg.woordanalyse;

import java.io.IOException;
import java.nio.file.FileSystems;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Woordenlijst {
    public static List<String> getWoordenlijst() throws IOException {
        List<String> woorden = new ArrayList<>();
        Scanner s = new Scanner(FileSystems.getDefault().getPath("woordenlijst.txt"));
        while (s.hasNext()) {
            woorden.add(s.nextLine());
        }
        return woorden;
    }
}
