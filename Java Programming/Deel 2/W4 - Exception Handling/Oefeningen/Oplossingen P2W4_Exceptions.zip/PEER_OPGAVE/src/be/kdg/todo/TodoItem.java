package be.kdg.todo;

/**
 * Created by venj on 29/11/2014.
 */
public class TodoItem {
    //WERK DEZE KLASSE VOLLEDIG UIT
}
