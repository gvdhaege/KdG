package be.kdg.todo;


public class TodoLijstException {
    //WERK DEZE KLASSE VOLLEDIG UIT
}
