package classes;

public class SubClass extends SuperClass
{
    public static int objectCounterSub;

    public SubClass()
    {
        objectCounterSub++;
        System.out.println("In constructor van SubClass : objectCounterSub = " + objectCounterSub);
    }
}
