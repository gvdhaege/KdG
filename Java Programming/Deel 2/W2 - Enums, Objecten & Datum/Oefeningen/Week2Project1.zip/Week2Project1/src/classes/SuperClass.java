package classes;

public class SuperClass
{
    public static int objectCounterSuper;

    public SuperClass()
    {
        objectCounterSuper++;
        System.out.println("In constructor van SuperClass : objectCounterSuper = " + objectCounterSuper);
    }
}
