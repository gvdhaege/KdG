package main;

import classes.SubClass;
import classes.SuperClass;

// Voorbeeld van gedrag van een static variable.
//
// Alles wat static wordt gedeclareerd bestaat enkel op class niveau.

public class MainProgram
{
    public static void main(String[] args)
    {
        /*
        System.out.println("\nWe maken 2 objecten aan van SuperClass :\n");
        SuperClass superClass_1 = new SuperClass();
        SuperClass superClass_2 = new SuperClass();
        */

        /*
        System.out.println("\nWe maken 1 object aan van SubClass :\n");
        SubClass subClass_1 = new SubClass();
        */

        /*
        // Voor de volledigheid, bad programming practice.
        // Soms kan je in Java heel slechte code schrijven.
        System.out.println("\nWe maken 1 object aan van SuperClass :\n");
        SuperClass superClass_1 = new SuperClass();
        System.out.println("\nWe maken 1 object aan van SubClass :\n");
        SubClass subClass_1 = new SubClass();
        */

        /*
        System.out.println("\nWe maken 1 object aan van SuperClass :\n");
        SuperClass superClass_1 = new SuperClass();

        // Let op : toegang tot de static variable via de class name + dot notation.
        System.out.println("\nEn printen de static variable vanuit MainProgram :\n");
        System.out.println("objectCounterSuper = " + SuperClass.objectCounterSuper);
        */
    }
}
