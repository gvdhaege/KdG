package wijnen;

/**
 * PEER opdracht
 * P2W2
 */
public enum Smaak {
    //Opdracht 3.1

    //Opdracht 3.2
}
