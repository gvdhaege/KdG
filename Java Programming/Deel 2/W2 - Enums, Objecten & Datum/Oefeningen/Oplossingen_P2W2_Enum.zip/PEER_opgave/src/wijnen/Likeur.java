package wijnen;

/**
 * PEER opdracht
 * P2W2
 */
public class Likeur  {
    private double alcoholGehalte; //in procent

    //Opdracht 2.1

    //Opdracht 2.2

    //Opdracht 2.3

}
