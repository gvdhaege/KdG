package wijnen;

/**
 * PEER opdracht
 * P2W2
 */
public class Champagne {
    private Smaak smaak;

    //Opdracht 4.1

    //Opdracht 4.2

    //Opdracht 4.3

}
