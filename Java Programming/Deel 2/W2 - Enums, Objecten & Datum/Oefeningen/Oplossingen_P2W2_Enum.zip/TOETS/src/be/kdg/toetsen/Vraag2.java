package be.kdg.toetsen;

/**
 * @author Kristiaan Behiels
 * @version 1.0 29/10/13
 */
public class Vraag2 {
    public static void main(String[] args) {
        Kleur kleur = Kleur.RUITEN;
        System.out.println(kleur + " " + kleur.name());

    }
}
