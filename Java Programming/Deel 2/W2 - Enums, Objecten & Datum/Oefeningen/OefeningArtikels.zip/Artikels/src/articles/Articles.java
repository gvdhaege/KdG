package articles;

public class Articles
{
    public final static int NUMBER_OF_ARTICLES = 6;

    private Article[] articles;

    public Articles(Article[] newArticles)
    {
        articles = new Article[NUMBER_OF_ARTICLES];
        for (int i=0; i < articles.length; i++)
        {
            articles[i] = newArticles[i];
        }
    }

    public Article[] getArticles() { return articles; }
}
