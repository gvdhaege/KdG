package articles;

import java.time.LocalDate;

public class Article
{
    private String name;
    private int number;
    private LocalDate dateOfProduction;

    public Article(String name, int number, LocalDate dateOfProduction)
    {
        this.name = name;
        this.number = number;
        this.dateOfProduction = dateOfProduction;
    }

    @Override
    public String toString()
    {
        return String.format("%-12s\t%04d %s", name, number, dateOfProduction);
    }

    public LocalDate getDateOfProduction() { return dateOfProduction; }
}
