package main;

import articles.Article;
import articles.Articles;
import utilities.Logger;

import java.time.LocalDate;
import java.time.Month;

public class MainProgram
{
    private static final Article[] data =
    {
        new Article("Kitkat", 13, LocalDate.of(2014, Month.NOVEMBER, 12)),
        new Article("Lolli", 147, LocalDate.of(2014, 12, 12)),
        new Article("Jelly ", 23, LocalDate.of(2014, 11, 12)),
        new Article("Froyo", 56, LocalDate.of(2013, 11, 12)),
        new Article("Donut", 123, LocalDate.of(2014, 11, 13)),
        new Article("Cupcake", 77, LocalDate.of(2014, 11, 11))
    };

    public static void main(String[] args)
    {
        Articles articles = new Articles(data);

        // Log alle artikels.
        Logger.sendToConsole("Alle artikels:");
        for (Article article : articles.getArticles())
        {
            Logger.sendToConsole(article.toString());
        }

        // Log de artikels met productiedatum 12 november 2014.
        Logger.sendToConsole("");
        Logger.sendToConsole("Alle artikels met productiedatum 12 november 2014:");
        LocalDate date = LocalDate.of(2014, 11, 12);
        for (Article article : articles.getArticles())
        {
            if (article.getDateOfProduction().equals(date))
                Logger.sendToConsole(article.toString());
        }

    }
}
