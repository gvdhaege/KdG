package utilities;

public class Logger
{
    // Static wil zeggen : 1 per class.
    // Wordt gebruikt wanneer je iets wil uitvoeren zonder object.
    public static void sendToConsole(String message)
    {
        System.out.println(message);
    }
}
