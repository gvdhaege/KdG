package main;

import enumeration.BasicColor;
import enumeration.UserStatus;

// MainProgram voor het werken met enums : enumerations of opsommingen.

public class MainProgram
{
    public static void main(String[] args)
    {
        /*
        // Werken met enum.
        BasicColor colorRed = BasicColor.RED;
        BasicColor colorGreen = BasicColor.GREEN;
        BasicColor colorBlue = BasicColor.BLUE;

        System.out.println("colorRed.name : " + colorRed.name());
        System.out.println("colorRed.ordinal : " + colorRed.ordinal());         // Starting from 0.
        System.out.println("colorGreen.name : " + colorGreen.name());
        System.out.println("colorGreen.ordinal : " + colorGreen.ordinal());
        System.out.println("colorBlue.name : " + colorBlue.name());
        System.out.println("colorBlue.ordinal : " + colorBlue.ordinal());
        */

        /*
        // Zo loop je met een for each door een enum.
        //
        for (BasicColor basicColor: BasicColor.values())    // Variant op static notation.
        {
            System.out.println("basicColor : " + basicColor.name() + ",\tOrdinal : " + basicColor.ordinal());
        }
        */

        /*
        // Gebruik van enumwaarden in een switch : veel beter dan met int codes.
        // Eerst met WHITE, dan met RED.
        BasicColor basicColor = BasicColor.RED;
        switch (basicColor)
        {
            case BLACK:
                System.out.println("In switch : BLACK.");
                break;
            case WHITE:
                System.out.println("In switch : WHITE.");
                break;
            default:
                System.out.println("In switch : Unknown color.");
                break;
        }
        */

        /*
        // Gebruik van een enum met getter.
        System.out.println("Status van ACTIVE : " + UserStatus.ACTIVE.getStatusCode());
        */

        /*
        // Demo debugging
        //
        int i = 25;
        i += 30;
        System.out.println("i = " + i);

        // Conditional debugging.
        int k = 0;
        for (int j=0 ; j < 50; j++)
        {
            k = j * j;
        }
        */
    }
}
