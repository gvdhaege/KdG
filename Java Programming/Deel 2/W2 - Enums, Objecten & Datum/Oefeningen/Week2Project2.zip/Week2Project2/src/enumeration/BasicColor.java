package enumeration;

//
// Het enum type is een soort van class.
// Wordt gebruikt om met opsommingen te kunnen werken.
//
// Oude manier : voor elk item een code (meestal een int). 2 Nadelen:
//      1. Niet duidelijk waar elke code voor staat.
//      2. Wat gebeurt er bij een niet-bestaande code ? Crash at run time.
//         Wordt nu opgevangen at compile time.
//
// Enums zorgen ook voor beter leesbare code -> zeer belangrijk voor je collega's.
//
// Elke waarde heeft een volgnummer, een ordinal.
// Begin te tellen vanaf 0.
//

public enum BasicColor
{
    BLACK, WHITE, RED, GREEN, BLUE;
}

