package enumeration;

//
// Omdat een enum een class is, kan je er ook een constructor en getters voor schrijven.
// Zo kan je voor elke waarde een gerelateerd attribuut opgeven.

// Wordt weinig gebruikt.
//
// "Enums are constants and are IMMUTABLE as such : no setters."
//

public enum UserStatus
{
    // De opsomming van de constanten komt nu eigenlijk overeen met het aanroepen van de constructor.
    //
    PENDING("P"), ACTIVE("A"), INACTIVE("I"), DELETED("D");

    // 1 attribuut.
    private String statusCode;

    // Constructor
    private UserStatus(String s)
    {
        statusCode = s;
    }

    // Getter
    public String getStatusCode()
    {
        return statusCode;
    }
}
