package examples;

import java.time.*;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;
import java.time.format.TextStyle;
import java.util.Locale;

//
// Class DateDemonstrator om het gebruik van de nieuwe time en date functionaliteiten in JDK 1.8 te leren kennen.
//

public class DateDemonstrator
{
    // 1 Attribuut
    LocalDate today;        // LocalDate is de nieuwe class om met dates te werken op een uniforme manier.

    // Constructor
    public DateDemonstrator()
    {
        today = LocalDate.now();
    }

    // Getter
    public LocalDate getToday()     { return today; }

    // Rekenen met datums is veel vereenvoudigd.
    public void compareDates()
    {
        LocalDate date1 = LocalDate.of(2014, 11, 12);   // Declaratie en initialisatie van een object van class LocalDate.
        LocalDate date2 = LocalDate.of(2015, 2, 12);

        System.out.println("\ndate1 = " + date1.toString());
        System.out.println("date2 = " + date2.toString());
        System.out.println("date1 is before date2 : " + date1.isBefore(date2));
        System.out.println("date1 is after date2 : " + date1.isAfter(date2));
    }

    public void periodBetweenDates()
    {
        LocalDate date1 = LocalDate.of(2013, 11, 10);
        LocalDate date2 = LocalDate.of(2014, 11, 12);

        long years = Period.between(date1, date2).getYears();
        long months = Period.between(date1, date2).getMonths();
        long days = Period.between(date1, date2).getDays();

        System.out.println("\nyears = " + years + " months = " + months + " days = " + days);
    }

    // Printen van datums en tijden is ook vereenvoudigd.
    public void prettyPrint()
    {
        LocalDate date = LocalDate.now();

        System.out.println("\nToday is a " + date.getDayOfWeek());

        DayOfWeek today = date.getDayOfWeek();
        System.out.println("Today in English : " + today.getDisplayName(TextStyle.FULL, Locale.ENGLISH));
        System.out.println("Today in System Locale : " + today.getDisplayName(TextStyle.FULL, Locale.getDefault()));
        System.out.println("Today in Chinese : " + today.getDisplayName(TextStyle.FULL, Locale.CHINESE));

        DateTimeFormatter fullFormatter = DateTimeFormatter.ofLocalizedDate(FormatStyle.FULL);
        System.out.println("\nToday in fullFormatter format : " + fullFormatter.format(date));
        DateTimeFormatter longFormatter = DateTimeFormatter.ofLocalizedDate(FormatStyle.LONG);
        System.out.println("Today in longFormatter format : " + longFormatter.format(date));
        DateTimeFormatter mediumFormatter = DateTimeFormatter.ofLocalizedDate(FormatStyle.MEDIUM);
        System.out.println("Today in mediumFormatter format : " + mediumFormatter.format(date));
        DateTimeFormatter shortFormatter = DateTimeFormatter.ofLocalizedDate(FormatStyle.SHORT);
        System.out.println("Today in shortFormatter format : " + shortFormatter.format(date));

        // Datum en tijd in eigen format.
        LocalDateTime longDate = LocalDateTime.of(2015, Month.NOVEMBER, 23, 9, 15);
        DateTimeFormatter ownFormatter = DateTimeFormatter.ofPattern("EEEE dd MMMM yyyy - HH:mm:ss");
        System.out.println("\nToday in ownFormatter format : " + ownFormatter.format(longDate));
    }

    public void testLeapYears ()
    {
        LocalDate testDate = LocalDate.of(2000, 1, 1);
        System.out.println("\nWas 2000 een schikkeljaar ? " + testDate.isLeapYear());
        testDate = LocalDate.of(2017, 1, 1);
        System.out.println("Is 2017 een schikkeljaar ? " + testDate.isLeapYear());
    }
}
