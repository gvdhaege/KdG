package main;

import examples.DateDemonstrator;

public class MainProgram
{
    public static void main(String[] args)
    {
        System.out.println("MAINPROGRAM : Start of mainprogram.");

        //
        DateDemonstrator dateDemonstrator = new DateDemonstrator();
        System.out.println("Today = " + dateDemonstrator.getToday());

        // Zelf datums aanmaken en vergelijken
        dateDemonstrator.compareDates();

        // Periode tussen datums
        dateDemonstrator.periodBetweenDates();

        // PrettyPrinting
        dateDemonstrator.prettyPrint();

        // Schrikkeljaar
        dateDemonstrator.testLeapYears();
        //

        System.out.println("\nMAINPROGRAM : Start of mainprogram.");
    }
}
