package main;

import classes.Person;

// Vergelijken van objecten.
//
// == vergelijkt enkel de plaats in het geheugen.
// equals vergelijk de state.

public class MainProgram
{

    public static void main(String[] args)
    {
        Person person1 = new Person("Casper");
        Person person2 = new Person("Rafael");
        Person person3 = new Person("Casper");

        // De == operator wordt gebruikt om 2 objecten met mekaar te vergelijken.
        // Vergelijken wil hier zeggen : zitten de objecten op dezelfde plaats in het geheugen ?
        // Los van de inhoud of de state van de objecten dus.

        System.out.println("person1 == person1 : " + (person1 == person1));
        System.out.println("person1 == person2 : " + (person1 == person2));
        System.out.println("person1 == person3 : " + (person1 == person3));

        // Dus, hoewel person1 en person3 dezelfde state hebben, geeft == false.

        // De equals method wordt door elk object overgeërfd van de class Object.

        System.out.println("person1.equals(person1) : " + (person1.equals(person1)));
        System.out.println("person1.equals(person2) : " + (person1.equals(person2)));
        System.out.println("person1.equals(person3) : " + (person1.equals(person3)));

        // Dus, vergelijkbaar gedrag, want dezelfde test.

        // Het is de bedoeling dat je bij elke class die je maakt, de equals method override.
        // Zo bepaal je zelf op welke attributen er word vergeleken.
        // Zet de overridden equals method van class Person uit commentaar en run main nog eens.

        // Nu wordt er niet allen op de plaats in het geheugen, maar ook op de state vergeleken.
        // Bij complexere classes, met meerdere attributen, bepaal je zelf welke attributen
        // je zal gebruiken om 2 objecten te vergelijken.

    }
}
