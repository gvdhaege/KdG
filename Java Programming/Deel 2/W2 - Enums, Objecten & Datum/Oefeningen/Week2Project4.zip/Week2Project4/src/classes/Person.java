package classes;

public class Person
{
    private String name;

    public Person(String theName)
    {
        name = theName;
    }

    //
    @Override
    public boolean equals(Object object)
    {
        // De method equalsIgnoreCase vergelijkt 2 Strings.
        if (this.name.equalsIgnoreCase(((Person) object).getName()))
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    //

    public String getName()             { return name;}
    public void setName(String name)    { this.name = name; }

}
