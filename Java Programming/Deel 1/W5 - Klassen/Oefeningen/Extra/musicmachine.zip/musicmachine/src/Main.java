/**
 * User: vochtenh
 * Date: 18-10-13 10:05
 */
public class Main {
    public static void main(String[] args) {
        //Opdracht 1: Maak een MusicMachine object aan
        //Toon de array INSTRUMENTEN in een menu:
        //Kies je instrument:
        //1:Piano
        //2:Guitar
        //3:Violin
        //4:Trumpet
        //5:Voice_oohs
        //6:Tuba
        //7:Acoustic_bass
        //Je keuze:
        //Stel vervolgens het gekozen instrument in op het musicMachine object
        //en speel 10 akkoorden af met de playMusic methode.
        //Ga nu naar de klasse MusicMachine en maak ze werkend!
    }
}
