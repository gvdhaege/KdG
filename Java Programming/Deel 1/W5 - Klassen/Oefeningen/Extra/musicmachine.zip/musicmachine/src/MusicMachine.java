import org.jfugue.Player;

import java.util.Random;

/**
 * User: vochtenh
 * Date: 18-10-13 9:32
 */
public class MusicMachine {
    //DE EIGENSCHAPPEN ZIJN GEGEVEN
    public final String[] INSTRUMENTEN = {"Piano",
            "Guitar","Violin","Trumpet","Voice_oohs","Tuba","Acoustic_bass"};
    private Player player;
    private Random randomGenerator;
    private int selectedInstrument;

    //CONSTRUCTOR IS GEGEVEN
    public MusicMachine(){
        player = new Player();
        randomGenerator = new Random();
        this.selectedInstrument = 0;
    }

    //Opdracht 3: Voeg een controle toe zodat het selectedInstrument
    //in de range van de array INSTRUMENTS ligt.
    public void setInstrument(int number){
        //if ...
        this.selectedInstrument = number;
    }

    //Opdracht 2:We schrijven een lus die aantalAkkoorden keer loopt
    //Maak hierin telkens een random muziekString aan
    //Voorbeelden van muziekStrings:
    //  "I[Trumpet] Dmajw","I[Violin] Cminh","I[Tuba] Aq"
    // - eerst een I
    // - dan tussen [] het geselecteerde instrument (uit de array INSTRUMENTS)
    // - dan een spatie
    // - dan een willekeurige noot (A,B,C,D,E,F,G)
    // - dan niets, maj of min voor gewone noot, majeur of mineur akkoord
    // - dan w,h,q,i voor de duur (whole, half, quarter, eight)
    //We spelen het akkoord dan af met de play methode van player.
    public void playMusic(int aantalAkkoorden){
        for (int i=0;i<aantalAkkoorden;i++) {
            //VUL HIER AAN....
        }
    }


}
