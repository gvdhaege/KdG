/**
 * User: vochtenh
 * Date: 11-10-13 15:06
 */
public class VierOpEenRijTekenen {
    public static void main(String[] args) {
        //Maak een schilderij
        //zet achtergrond zwart
        //teken er 10 witte lijnen op van links naar rechts (gebruik lus!)
        //teken er een wit rooster (10x10) op
        //teken een wit rooster (10x10) met in elk vakje een schijf
        //schijven zijn rood of wit (willekeurig)
    }
}
