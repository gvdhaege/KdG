public class HemelTekenen {
    public static void main(String[] args) {
        //maak een schilderij
        //kleur het schilderij blauw
        //teken er een zon op (gele schijf)
        //teken er 10 witte schijven op op random locaties (wolken)
    }
}
