package be.kdg.klassen;

/**
 * @author Kristiaan Behiels
 * @version 1.0 20/10/14
 */
public class Dobbelstenen {
    private Dobbelsteen steenEen;
    private Dobbelsteen steenTwee;
    private Dobbelsteen steenDrie;

    public Dobbelstenen() {
        steenEen = new Dobbelsteen();
        steenTwee = new Dobbelsteen();
        steenDrie = new Dobbelsteen();
    }

    public int werpDobbelsteen() {
        return steenEen.werpDobbelsteen();
    }

    public int werpTweeDobbelstenen() {
        return steenEen.werpDobbelsteen() + steenTwee.werpDobbelsteen();
    }

    public int werpDrieDobbelstenen() {
        return steenEen.werpDobbelsteen() + steenTwee.werpDobbelsteen() + steenDrie.werpDobbelsteen();
    }
}
