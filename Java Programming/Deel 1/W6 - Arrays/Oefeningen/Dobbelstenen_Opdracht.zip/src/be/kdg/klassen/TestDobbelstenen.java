package be.kdg.klassen;

/**
 * @author Kristiaan Behiels
 * @version 1.0 20/10/14
 */
public class TestDobbelstenen {
    private static final int AANTAL_WORPEN = 100;
    private static final int AANTAL_PER_REGEL = 10;

    public static void main(String[] args) {
        Dobbelstenen stenen = new Dobbelstenen();

        System.out.println(AANTAL_WORPEN + " worpen met 1 dobbelsteen:\n");
        int som = 0;
        for (int i = 0; i < AANTAL_WORPEN; i++) {
            int waarde =  stenen.werpDobbelsteen();
            som += waarde;
            System.out.printf("%2d ", waarde);
            if ((i + 1)  % AANTAL_PER_REGEL == 0) {
                System.out.println();
            }
        }
        System.out.printf("\nHet gemiddelde is %.2f\n", som * 1.0 / AANTAL_WORPEN);

        System.out.println("\n" + AANTAL_WORPEN + " worpen met 2 dobbelstenen:\n");
        som = 0;
        for (int i = 0; i < AANTAL_WORPEN; i++) {
            int waarde =  stenen.werpTweeDobbelstenen();
            som += waarde;
            System.out.printf("%2d ", waarde);
            if ((i + 1)  % AANTAL_PER_REGEL == 0) {
                System.out.println();
            }
        }
        System.out.printf("\nHet gemiddelde is %.2f", som * 1.0 / AANTAL_WORPEN);

        System.out.println("\n" + AANTAL_WORPEN + " worpen met 3 dobbelstenen:\n");
        som = 0;
        for (int i = 0; i < AANTAL_WORPEN; i++) {
            int waarde =  stenen.werpDrieDobbelstenen();
            som += waarde;
            System.out.printf("%2d ", waarde);
            if ((i + 1)  % AANTAL_PER_REGEL == 0) {
                System.out.println();
            }
        }
        System.out.printf("\nHet gemiddelde is %.2f", som * 1.0 / AANTAL_WORPEN);
    }
}

/*
100 worpen met 1 dobbelsteen:

 2  6  4  5  3  6  4  6  5  1
 6  4  2  3  4  4  4  1  2  4
 4  5  6  3  4  5  5  1  3  2
 6  6  2  5  3  3  4  6  6  3
 3  5  3  1  1  4  6  1  3  6
 2  3  1  5  2  3  1  6  4  5
 6  3  3  1  1  2  4  5  4  2
 4  4  3  4  6  6  5  5  4  3
 1  5  1  3  5  6  4  2  6  1
 4  2  2  6  5  2  2  2  5  5

Het gemiddelde is 3,67

100 worpen met 2 dobbelstenen:

11  9  6  8  8  5  2  9  4  7
10  3  6  7  3  8  5  9 11  8
10  6  5  8  7 10  9 12 11  4
 9  8  6  4  7  6 10  8  7 10
10 11  8 10  8  8  2  9 11  3
 2  4 12  3  7  5  7  8  7  6
 8  7 11  9  5  5  4  6  8  3
10  3  3  6  8  6  4  3  8  3
 4  3  7  8  9  7  3  6 11  3
 8  2  3  7  8  8  5  6  9  9

Het gemiddelde is 6,83

100 worpen met 3 dobbelstenen:

13 12 14 13  9 10 14 12 10 11
11  6 13 10 10 10 10  8 11  7
 9 15 10 13 11  5 15  8  8 14
 9 13 11  5  6 13 10 12  8 11
 9 10  9 12 12 10 10 11 17 15
 8  7 16 12 10 12 11 11 13 13
13 11  9 15 12 13 10  8  9 10
11 12  8 10 11 12  9 10 11  9
 7  5 13 12 10  8 14  6  8  7
11 11 13 12 10 10 15 10 15 12

Het gemiddelde is 10,70
*/