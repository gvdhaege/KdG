package PersonDemo.Model;

public class Person {
    public enum Gender { MALE, FEMALE};

    private int id;
    private String name;
    private Gender gender;
    private boolean coder;

    public Person(int id, String name, Gender gender, boolean canCode) {
        this.id = id;
        this.name = name;
        this.gender = gender;
        this.coder = canCode;
    }


    public Gender getGender() {
        return gender;
    }

    public int getId() {
        return id;
    }
    public String getName() {
        return name;
    }

    public boolean isCoder() {
        return coder;
    }

    @Override
    public String toString() {
        return String.format("%s (%d) %s (%b)", this.name, this.id, this.gender.toString(), this.coder);
    }
}
