package PersonDemo.View;

import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;

public class PersonView extends GridPane {
    //Vul aan met de nodige controls en hun getters
    private Label lblName;
    private ComboBox cbxNames;
    private Button btnPersonSelector;
    private RadioButton rbnMale;
    private RadioButton rbnFemale;
    private CheckBox chkCanCode;

    Button getBtnPersonSelector() {
        return btnPersonSelector;
    }

    Label getLblName() {
        return lblName;
    }

    ComboBox getCbxNames() {
        return cbxNames;
    }

    RadioButton getRbnMale() {
        return rbnMale;
    }

    RadioButton getRbnFemale() {
        return rbnFemale;
    }

    CheckBox getChkCanCode() {
        return chkCanCode;
    }


    public PersonView() {
        initializeNodes();
        layoutNodes();
    }

    private void initializeNodes(){
        lblName = new Label("Naam: ");
        cbxNames = new ComboBox();
        btnPersonSelector = new Button("Selecteer deze persoon");

        //Creatie van de radiobuttons. Deze moeten gegroepeerd worden
        // in een ToggleGroup zodanig dat er binnen deze groep slechts 1
        // tegelijkertijd geselecteerd kan worden!
        rbnMale = new RadioButton("Man");
        rbnFemale = new RadioButton("Vrouw");
        ToggleGroup genderGroup = new ToggleGroup();
        rbnMale.setToggleGroup(genderGroup);
        rbnFemale.setToggleGroup(genderGroup);

        //Checkbox aanmaken (aan of uit...)
        chkCanCode = new CheckBox("Kan programmeren");

    }

    private void layoutNodes(){
        add(lblName,0, 0);
        add(cbxNames, 1, 0);
        add(btnPersonSelector, 0, 1, 2, 1);
        add(rbnMale, 0, 2);
        add(rbnFemale, 1, 2);
        add(chkCanCode, 0, 3, 2, 1);

        setPadding(new Insets(15));
        //Voor elke control dezelfde marge instellen. Om de code te vereenvoudigen
        // maak ik die marge maar ��n keer aan.
        Insets margins = new Insets(0, 0, 10, 10);
        GridPane.setMargin(lblName, margins);
        GridPane.setMargin(cbxNames, margins);
        GridPane.setMargin(btnPersonSelector, margins);
        GridPane.setMargin(rbnMale, margins);
        GridPane.setMargin(rbnFemale, margins);
        GridPane.setMargin(chkCanCode, margins);

    }
}
