package PersonDemo.View;

import PersonDemo.Model.PersonModel;
import PersonDemo.Model.Person;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Alert;
import javafx.scene.control.SingleSelectionModel;
import javafx.scene.input.MouseEvent;

public class PersonPresenter {
    private PersonView view;
    private PersonModel model;

    public PersonPresenter(PersonModel model, PersonView view) {
        this.view = view;
        this.model = model;
        updateView();
        addEventHandlers();
    }

    private void updateView() {
        //Als er g��n persoon selecteert is, gaan we de combobox opnieuw inladen
        // en de andere controls disablen.
        if (model.getSelectedPerson() == null) {
            //Om een lijst van objecten te koppelen aan een combobox, moeten we een
            // observable list maken. Dit kan eenvoudig dankzij de klasse "FXCollections" uit
            // het JavaFX framework. Via de methode observableArrayList gaan we op basis
            // van een klassieke ArrayList een ObserverableList aanmaken en die koppelen aan
            // onze combobox
            ObservableList<Person> allPersons = FXCollections.observableArrayList(model.getNames());
            view.getCbxNames().setItems(allPersons);
            //De overige controls worden leeg gemaakt en gedisabled
            view.getChkCanCode().setSelected(false);
            view.getRbnMale().setSelected(false);
            view.getRbnFemale().setSelected(false);
            view.getChkCanCode().setDisable(true);
            view.getRbnFemale().setDisable(true);
            view.getRbnMale().setDisable(true);
        } else {
            //We gaan de overige controls nu enablen
            view.getChkCanCode().setDisable(false);
            view.getRbnFemale().setDisable(false);
            view.getRbnMale().setDisable(false);
            //Op basis van de waarde "isCoder" uit de geselecteerde persoon gaan we de
            // checkbox al dan niet aanvinken.
            view.getChkCanCode().setSelected(model.getSelectedPerson().isCoder());
            //Op basis van het geslacht van de geselecteerde persson gaan we de juiste
            // radiobutton aanvinken
            view.getRbnFemale().setSelected(model.getSelectedPerson().getGender() == Person.Gender.FEMALE);
            view.getRbnMale().setSelected(model.getSelectedPerson().getGender() == Person.Gender.MALE);
        }
    }
    private void addEventHandlers() {
        view.getBtnPersonSelector().setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                SingleSelectionModel selectedObject = view.getCbxNames().getSelectionModel();
                Alert a;
                if(selectedObject == null || selectedObject.getSelectedItem() == null){
                    a = new Alert(Alert.AlertType.ERROR, "No person selected");
                    model.setSelectedPerson(null);
                }else{
                    Person selectedPerson = (Person)selectedObject.getSelectedItem();
                    model.setSelectedPerson(selectedPerson);
                    a = new Alert(Alert.AlertType.INFORMATION, selectedPerson.toString());
                }
                a.showAndWait();
                updateView();
            }
        });

        view.getBtnPersonSelector().setOnMouseEntered(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                System.out.printf("(%f, %f)%n", event.getX(), event.getY());
            }
        });
    }
}
