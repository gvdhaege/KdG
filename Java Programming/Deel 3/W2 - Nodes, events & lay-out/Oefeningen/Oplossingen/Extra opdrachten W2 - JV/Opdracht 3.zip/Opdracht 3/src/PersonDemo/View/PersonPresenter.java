package PersonDemo.View;

import PersonDemo.Model.PersonModel;
import PersonDemo.Model.Person;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Alert;
import javafx.scene.control.SingleSelectionModel;

public class PersonPresenter {
    private PersonView view;
    private PersonModel model;

    public PersonPresenter(PersonModel model, PersonView view) {
        this.view = view;
        this.model = model;
        updateView();
        addEventHandlers();
    }

    private void updateView() {
        //vul aan
    }

    private void addEventHandlers() {
        //vul aan
    }
}
