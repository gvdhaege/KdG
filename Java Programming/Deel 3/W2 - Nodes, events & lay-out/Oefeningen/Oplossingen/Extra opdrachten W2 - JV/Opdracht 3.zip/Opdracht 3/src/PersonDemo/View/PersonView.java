package PersonDemo.View;

import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;

public class PersonView extends GridPane {
    //Vul aan met de nodige controls en hun getters


    public PersonView() {
        initializeNodes();
        layoutNodes();
    }

    private void initializeNodes(){
        //Vul aan
    }

    private void layoutNodes(){
        //Vul aan
    }
}
