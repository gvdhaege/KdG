package PersonDemo.Model;

import java.util.ArrayList;
import java.util.List;

public class PersonModel {
    private List<Person> names;
    private int highestNameId;
    private Person selectedPerson;

    public PersonModel() {
        highestNameId = 0;
        this.names = new ArrayList<Person>();
        addName("Jef", Person.Gender.MALE, false);
        addName("Maria", Person.Gender.FEMALE, true);
        addName("Charles", Person.Gender.MALE, false);
        addName("Louis", Person.Gender.MALE, false);
    }

    public void addName(String newName, Person.Gender gender, boolean coder){
        Person newPerson = new Person(++highestNameId, newName, gender, coder);
        names.add(newPerson);
    }

    public List<Person> getNames() {
        return names;
    }

    public Person getSelectedPerson() {
        return selectedPerson;
    }

    public void setSelectedPerson(Person selectedPerson) {
        this.selectedPerson = selectedPerson;
    }

}
