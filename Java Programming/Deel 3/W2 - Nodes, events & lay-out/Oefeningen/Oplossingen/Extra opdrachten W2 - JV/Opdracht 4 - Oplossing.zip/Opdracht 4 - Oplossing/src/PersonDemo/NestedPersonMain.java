package PersonDemo;

import PersonDemo.Model.PersonModel;
import PersonDemo.View.PersonPresenter;
import PersonDemo.View.PersonView;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 * Created by venj on 12/02/2016.
 */
public class NestedPersonMain extends Application {
    @Override
    public void start(Stage primaryStage) throws Exception {
        PersonModel model = new PersonModel();
        PersonView view = new PersonView();
        PersonPresenter p = new PersonPresenter(model, view);

        primaryStage.setScene(new Scene(view));
        primaryStage.setTitle("Combo en andere boxen");
        primaryStage.show();
    }

    public static void main(String[] args) {
        Application.launch(args);
    }
}
