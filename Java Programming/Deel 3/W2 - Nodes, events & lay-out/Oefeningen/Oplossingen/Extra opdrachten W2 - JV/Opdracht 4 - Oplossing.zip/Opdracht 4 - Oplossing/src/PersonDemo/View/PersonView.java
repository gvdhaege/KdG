package PersonDemo.View;

import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;

public class PersonView extends BorderPane {
    private GridPane grdCenter;
    private VBox vBoxLeft;
    private Label lblName;
    private TextField txtName;
    private ComboBox cbxNames;
    private RadioButton rbnMale;
    private RadioButton rbnFemale;
    private CheckBox chkCanCode;
    private MenuBar mbrTop;
    private Menu mnuBestand;
    private MenuItem mnuExit;

    Label getLblName() {
        return lblName;
    }

    ComboBox getCbxNames() {
        return cbxNames;
    }

    RadioButton getRbnMale() {
        return rbnMale;
    }

    RadioButton getRbnFemale() {
        return rbnFemale;
    }

    CheckBox getChkCanCode() {
        return chkCanCode;
    }

    MenuItem getmnuExit(){ return mnuExit; }

    TextField getTxtName() { return txtName; }

    public PersonView() {
        initializeControls();
        layoutControls();
    }

    private void initializeControls(){
        grdCenter = new GridPane();
        vBoxLeft = new VBox();
        lblName = new Label("Naam: ");
        cbxNames = new ComboBox();
        txtName = new TextField();

        //Creatie van de radiobuttons. Deze moeten gegroepeerd worden
        // in een ToggleGroup zodanig dat er binnen deze groep slechts 1
        // tegelijkertijd geselecteerd kan worden!
        rbnMale = new RadioButton("Man");
        rbnFemale = new RadioButton("Vrouw");
        ToggleGroup genderGroup = new ToggleGroup();
        rbnMale.setToggleGroup(genderGroup);
        rbnFemale.setToggleGroup(genderGroup);

        //Checkbox aanmaken (aan of uit...)
        chkCanCode = new CheckBox("Kan programmeren");

        //Menu aanmaken
        this.mnuExit = new MenuItem("Afsluiten");
        this.mnuBestand = new Menu("Bestand", null, mnuExit);
        this.mbrTop = new MenuBar(mnuBestand);
    }

    private void layoutControls(){
        vBoxLeft.getChildren().add(lblName);
        vBoxLeft.getChildren().add(cbxNames);
        grdCenter.add(txtName, 0, 0, 2, 1);
        grdCenter.add(rbnMale, 0, 1);
        grdCenter.add(rbnFemale, 1, 1);
        grdCenter.add(chkCanCode, 0, 2, 2, 1);
        txtName.setDisable(true);

        grdCenter.setPadding(new Insets(15));
        //Voor elke control dezelfde marge instellen. Om de code te vereenvoudigen
        // maak ik die marge maar ��n keer aan.
        Insets margins = new Insets(0, 0, 10, 10);
        GridPane.setMargin(txtName, margins);
        GridPane.setMargin(lblName, margins);
        GridPane.setMargin(cbxNames, margins);
        GridPane.setMargin(rbnMale, margins);
        GridPane.setMargin(rbnFemale, margins);
        GridPane.setMargin(chkCanCode, margins);
        setLeft(vBoxLeft);
        setCenter(grdCenter);
        setTop(mbrTop);

    }
}
