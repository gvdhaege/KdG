package be.kdg.batman.model;

public enum GamePhase {
    POW, WHAM, ZAP;
}
