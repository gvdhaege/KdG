package be.kdg.tijd.view;

import be.kdg.tijd.model.TimeModel;

import java.time.LocalTime;

public class Presenter {
    public Presenter(TimeModel model, TimeView view) {

    }
}
