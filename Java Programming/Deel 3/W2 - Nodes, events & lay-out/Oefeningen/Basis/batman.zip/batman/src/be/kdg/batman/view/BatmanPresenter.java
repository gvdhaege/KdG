package be.kdg.batman.view;

import be.kdg.batman.model.Game;
import be.kdg.batman.view.pow.PowPane;
import be.kdg.batman.view.wham.WhamPane;
import be.kdg.batman.view.zap.ZapPane;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;

public class BatmanPresenter {
    public BatmanPresenter(Game model, PowPane view1, WhamPane view2, ZapPane view3) {

    }
}
