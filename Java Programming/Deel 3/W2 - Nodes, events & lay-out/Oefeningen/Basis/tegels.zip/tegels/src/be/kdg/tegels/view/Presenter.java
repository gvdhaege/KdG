package be.kdg.tegels.view;

import be.kdg.tegels.model.TileModel;

public class Presenter {
    public Presenter(TileModel model, TileView view) {

    }
}
