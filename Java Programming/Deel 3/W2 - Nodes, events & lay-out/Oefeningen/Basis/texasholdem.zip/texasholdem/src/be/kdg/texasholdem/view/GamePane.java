package be.kdg.texasholdem.view;

import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;

public class GamePane extends VBox {
    public GamePane() {
    }

    Button getNextPhase() {
        // Aan te vullen!
        // ...
        return null;
    }

    Button getRestart() {
        // Aan te vullen!
        // ...
        return null;
    }

    Label getBrValueLabel() {
        // Aan te vullen!
        // ...
        return null;
    }

    void setBoardImage(int index, Image cardImage) {
        // Aan te vullen!
        // ...
    }

    void setPocketImage(int index, Image cardImage) {
        // Aan te vullen!
        // ...
    }
}
