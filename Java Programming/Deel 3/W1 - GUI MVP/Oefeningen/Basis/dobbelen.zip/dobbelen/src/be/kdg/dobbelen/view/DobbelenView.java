package be.kdg.dobbelen.view;

import javafx.scene.layout.GridPane;


public class DobbelenView extends GridPane {
    //TODO
}
