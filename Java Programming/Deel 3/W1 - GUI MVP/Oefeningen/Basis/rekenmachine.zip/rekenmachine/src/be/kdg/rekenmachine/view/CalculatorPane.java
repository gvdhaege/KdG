package be.kdg.rekenmachine.view;

import javafx.scene.layout.GridPane;

public class CalculatorPane extends GridPane {
}
