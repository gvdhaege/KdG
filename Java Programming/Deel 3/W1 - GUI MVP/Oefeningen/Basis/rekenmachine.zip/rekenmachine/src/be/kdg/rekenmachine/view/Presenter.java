package be.kdg.rekenmachine.view;

public class Presenter {
}
