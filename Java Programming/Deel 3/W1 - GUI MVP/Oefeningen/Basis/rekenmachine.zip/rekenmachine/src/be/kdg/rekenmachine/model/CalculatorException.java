package be.kdg.rekenmachine.model;

public class CalculatorException extends RuntimeException {
    CalculatorException(String msg) {
        super(msg);
    }
}
