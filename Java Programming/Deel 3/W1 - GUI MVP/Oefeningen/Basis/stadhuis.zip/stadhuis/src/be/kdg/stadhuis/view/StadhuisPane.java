package be.kdg.stadhuis.view;

import javafx.scene.layout.VBox;

public class StadhuisPane extends VBox {

}
