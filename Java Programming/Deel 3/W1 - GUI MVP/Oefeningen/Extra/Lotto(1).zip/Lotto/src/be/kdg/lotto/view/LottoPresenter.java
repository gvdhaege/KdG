package be.kdg.lotto.view;

import be.kdg.lotto.model.GetallenGenerator;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;

public class LottoPresenter {
    private GetallenGenerator generator;
    private LottoView view;

    public LottoPresenter(GetallenGenerator generator, LottoView view) {
        this.generator = generator;
        this.view = view;
        updateView();
        addEventHandlers();
    }

    private void updateView() {
        // TODO
    }

    private void addEventHandlers() {
        // TODO
    }

    public LottoView getView() {
        return view;
    }
}
