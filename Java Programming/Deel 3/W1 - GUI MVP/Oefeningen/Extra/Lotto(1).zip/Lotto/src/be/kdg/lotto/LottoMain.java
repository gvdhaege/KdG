package be.kdg.lotto;

import be.kdg.lotto.model.GetallenGenerator;
import be.kdg.lotto.view.LottoPresenter;
import be.kdg.lotto.view.LottoView;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 * @author Kristiaan Behiels
 * @version 1.0 29/01/2016 21:02
 */
public class LottoMain extends Application {
    @Override
    public void start(Stage primaryStage) throws Exception {
        GetallenGenerator generator = new GetallenGenerator();
        LottoView view = new LottoView();
        LottoPresenter presenter = new LottoPresenter(generator, view);

        // TODO


    }
}
