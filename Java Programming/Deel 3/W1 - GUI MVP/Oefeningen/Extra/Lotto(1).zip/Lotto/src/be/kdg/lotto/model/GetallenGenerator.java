package be.kdg.lotto.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

/* HIER MAG JE NIETS AAN WIJZIGEN! */
/* LEERSTOF 2de jaar! */
public class GetallenGenerator {
    private static final int MAX = 45;
    private List<Integer> getallen = new ArrayList<>();

    // Deze methode zorgt voor de creatie van een ArrayList van de
    // getallen van 1 tot en met 45 en plaatst ze dan in een willekeurige
    // volgorde (= leerstof 2de jaar)
    public void generate() {
        getallen = IntStream.range(1, MAX)
                .boxed()
                .collect(Collectors.toList());
        Collections.shuffle(getallen);
    }

    // Deze methode zorgt voor de creatie van 6 Lottogetallen
    // in de vorm van een string (je hoeft ze pas in het 2de jaar te begrijpen)
    public String getLottoGetallen() {
        generate();
        return String.join(", ", getallen.stream()
                .limit(6)
                .sorted()
                .map(Object::toString)
                .collect(Collectors.toList()));
    }
}
