package be.kdg.lotto.view;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;

public class LottoView extends BorderPane {
    private Label lottoLabel;
    private TextField lottoField;
    private Button lottoButton;

    // TODO

}
