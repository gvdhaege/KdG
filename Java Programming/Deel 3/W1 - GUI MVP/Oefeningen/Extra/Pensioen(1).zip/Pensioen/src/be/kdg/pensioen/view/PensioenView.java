package be.kdg.pensioen.view;

import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;

/**
 * LEFT: geboorteJaar
 * CENTER: berekenButton
 * RIGHT: pensioenJaar
 *
 * Insets: TRouBLe
 */
public class PensioenView extends BorderPane {
    private TextField geboorteJaarField;
    private TextField pensioenJaarField;
    private Button berekenButton;

    // TODO

}
