package be.kdg.mainmenu.view;

import javafx.scene.control.Button;

public class MainMenuButton extends Button {
    public MainMenuButton(String text) {
        super(text);

        // Hier aanvullen...
    }
}
