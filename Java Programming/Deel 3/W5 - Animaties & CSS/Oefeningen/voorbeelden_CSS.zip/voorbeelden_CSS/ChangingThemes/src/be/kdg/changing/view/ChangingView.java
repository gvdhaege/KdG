package be.kdg.changing.view;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.RadioButton;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;

public class ChangingView extends BorderPane
{
    private ComboBox<String> themeSettings = new ComboBox<>();
    private final String[] classNames = {"light", "dark", "high-contrast"};
    private final String[] items = {"Light Theme", "Dark Theme", "High Contrast Theme"};

    private Button testButton;
    private RadioButton testRadioButton;
    private VBox testBox;

    public ChangingView()
    {
        initialiseNodes();
        layoutNodes();
    }

    private void initialiseNodes()
    {
        ObservableList<String> settingsList = FXCollections.observableArrayList(items);
        themeSettings.setItems(settingsList);
        themeSettings.setValue(items[0]);

        testButton = new Button("Test Button");
        testButton.getStyleClass().add("light");

        testRadioButton = new RadioButton("Test RadioButton");
        testRadioButton.getStyleClass().add("light");

        testBox = new VBox(10);
        testBox.getStyleClass().add("light");
    }

    private void layoutNodes()
    {
        testBox.getChildren().addAll(testButton, testRadioButton);
        testBox.setSpacing(20);
        testBox.setPadding(new Insets(10));
        testBox.setAlignment(Pos.CENTER);
        BorderPane.setMargin(testBox, new Insets(0, 10, 10, 10));

        setTop(testBox);
        setCenter(themeSettings);
    }

    ComboBox<String> getThemeSettings() {
        return themeSettings;
    }

    String[] getClassNames() {
        return classNames;
    }

    Button getTestButton() {
        return testButton;
    }

    public RadioButton getTestRadioButton() {
        return testRadioButton;
    }

    public VBox getTestBox() {
        return testBox;
    }
}
