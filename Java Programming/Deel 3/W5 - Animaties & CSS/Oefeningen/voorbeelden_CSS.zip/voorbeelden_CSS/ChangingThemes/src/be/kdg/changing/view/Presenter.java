package be.kdg.changing.view;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;

public class Presenter
{
    private ChangingView view;
    private String oldClass = "light";

    public Presenter(ChangingView view)
    {
        this.view = view;
        handleEvents();
    }

    private void handleEvents()
    {
        view.getThemeSettings().setOnAction(new EventHandler<ActionEvent>()
        {
            @Override
            public void handle(ActionEvent event)
            {
                // Hier wordt het kiezen van een nieuwe stijl verwerkt.
                // Wat is de gekozen stijl in de combobox ?
                int newCssClass = view.getThemeSettings().getSelectionModel().getSelectedIndex();

                view.getTestBox().getStyleClass().remove(oldClass);
                view.getTestBox().getStyleClass().add(view.getClassNames()[newCssClass]);

                view.getTestButton().getStyleClass().removeAll(oldClass);
                view.getTestButton().getStyleClass().add(view.getClassNames()[newCssClass]);

                view.getTestRadioButton().getStyleClass().remove(oldClass);
                view.getTestRadioButton().getStyleClass().add(view.getClassNames()[newCssClass]);

                oldClass = view.getClassNames()[newCssClass];
            }
        });

        view.getTestButton().setOnAction(new EventHandler<ActionEvent>()
        {
            @Override
            public void handle(ActionEvent event) {
                view.getTestButton().getStyleClass().add("button-clicked");
            }
        });
    }
}
