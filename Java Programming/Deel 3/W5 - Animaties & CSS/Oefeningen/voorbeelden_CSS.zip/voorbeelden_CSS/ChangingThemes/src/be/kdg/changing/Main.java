package be.kdg.changing;

import be.kdg.changing.view.ChangingView;
import be.kdg.changing.view.Presenter;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class Main extends Application
{
    @Override
    public void start(Stage primaryStage) throws Exception
    {
        ChangingView view = new ChangingView();

        new Presenter(view);

        Scene scene = new Scene(view);
        // Hierdoor kunnen we de css file in de hele scene gebruiken.
        scene.getStylesheets().add("be/kdg/changing/css/themes.css");

        primaryStage.setTitle("Test Themes");
        primaryStage.setWidth(250);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}

