package be.kdg.stopwatch.view;

import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Font;

public class StopwatchView extends GridPane {
    private Label hours;
    private Label hoursLabel;
    private Label firstColon;
    private Label minutes;
    private Label minutesLabel;
    private Label secondColon;
    private Label seconds;
    private Label secondsLabel;
    private Button start;
    private Button pause;
    private Button stop;

    public StopwatchView() {
        this.initialiseNodes();
        this.layoutNodes();
    }

    private void initialiseNodes() {
        Font giantFont = new Font(96);
        this.hours = new Label();
        this.hours.setFont(giantFont);
        this.hoursLabel = new Label("Uren");
        this.firstColon = new Label(":");
        this.firstColon.setFont(giantFont);
        this.minutes = new Label();
        this.minutes.setFont(giantFont);
        this.minutesLabel = new Label("Minuten");
        this.secondColon = new Label(":");
        this.secondColon.setFont(giantFont);
        this.seconds = new Label();
        this.seconds.setFont(giantFont);
        this.secondsLabel = new Label("Seconden");
        this.start = new Button("Start");
        this.pause = new Button("Pauze");
        this.stop = new Button("Stop");
    }

    private void layoutNodes() {
        //this.setGridLinesVisible(true);
        this.setPadding(new Insets(10.0));

        this.add(this.hours, 0, 0);
        this.add(this.hoursLabel, 0, 1);
        this.add(this.firstColon, 1, 0);
        this.add(this.minutes, 2, 0);
        this.add(this.minutesLabel, 2, 1);
        this.add(this.secondColon, 3, 0);
        this.add(this.seconds, 4, 0);
        this.add(this.secondsLabel, 4, 1);
        this.add(this.start, 0, 2);
        this.add(this.pause, 2, 2);
        this.add(this.stop, 4, 2);

        GridPane.setHalignment(this.hoursLabel, HPos.CENTER);
        GridPane.setHalignment(this.minutesLabel, HPos.CENTER);
        GridPane.setHalignment(this.secondsLabel, HPos.CENTER);
        GridPane.setHalignment(this.start, HPos.CENTER);
        GridPane.setHalignment(this.pause, HPos.CENTER);
        GridPane.setHalignment(this.stop, HPos.CENTER);
    }

    Label getHours() {
        return hours;
    }

    Label getMinutes() {
        return minutes;
    }

    Label getSeconds() {
        return seconds;
    }

    Button getStart() {
        return start;
    }

    Button getPause() {
        return pause;
    }

    Button getStop() {
        return stop;
    }
}
