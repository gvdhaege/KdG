package be.kdg.transition.view;

import javafx.animation.*;
import javafx.scene.Group;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.util.Duration;

public class View extends Group {
    private Canvas canvas;
    private Rectangle movingRectangle;
    private Rectangle[] fourCorners;

    public View() {
        this.initialiseNodes();
        this.layoutNodes();
        this.animate();
        //this.animatePath();
        //this.animateSerie();
    }

    private void initialiseNodes() {
        this.canvas = new Canvas(600, 600);
        GraphicsContext gc = this.canvas.getGraphicsContext2D();
        gc.setFill(Color.CORNFLOWERBLUE);
        gc.fillRect(0, 0, this.canvas.getWidth(), this.canvas.getHeight());

        this.movingRectangle = new Rectangle(100, 100, 100, 100);
        this.movingRectangle.setArcHeight(15);
        this.movingRectangle.setArcWidth(15);
        this.movingRectangle.setFill(Color.BLUEVIOLET);

        this.fourCorners = new Rectangle[4];
        this.fourCorners[0] = new Rectangle(100, 100, 100, 100);
        this.fourCorners[1] = new Rectangle(400, 100, 100, 100);
        this.fourCorners[2] = new Rectangle(400, 400, 100, 100);
        this.fourCorners[3] = new Rectangle(100, 400, 100, 100);

        for (Rectangle r : this.fourCorners) {
            r.setFill(Color.DARKGRAY);
        }
    }

    private void layoutNodes() {
        this.getChildren().add(this.canvas);
        this.getChildren().addAll(this.fourCorners);
        this.getChildren().add(this.movingRectangle);
    }

    private void animate() {
        ////////////////////////////////////
        // In de slides gaan we tot hier: //
        ////////////////////////////////////

        /*TranslateTransition transition1 = new TranslateTransition();
        transition1.setNode(this.movingRectangle);
        transition1.setDuration(Duration.seconds(1));
        transition1.setByX(300);
        transition1.setCycleCount(1);
        transition1.setInterpolator(Interpolator.EASE_BOTH);
        //transition1.play();

        RotateTransition transition2 = new RotateTransition();
        transition2.setNode(this.movingRectangle);
        transition2.setDuration(Duration.millis(300));
        transition2.setByAngle(90);
        transition2.setCycleCount(1);
        transition2.setInterpolator(Interpolator.LINEAR);
        //transition2.play();

        SequentialTransition seqTransition = new SequentialTransition();
        seqTransition.setCycleCount(Timeline.INDEFINITE);
        seqTransition.getChildren().add(transition1);
        seqTransition.getChildren().add(transition2);
        seqTransition.play();*/

        //////////////////////////////////////
        // De finale versie best met arrays //
        //////////////////////////////////////
        TranslateTransition[] translateTransitions = new TranslateTransition[4];
        for (int i = 0; i < translateTransitions.length; i++) {
            translateTransitions[i] = new TranslateTransition();
            translateTransitions[i].setNode(this.movingRectangle);
            translateTransitions[i].setDuration(Duration.seconds(1));
            translateTransitions[i].setCycleCount(1);
            translateTransitions[i].setInterpolator(Interpolator.EASE_BOTH);
        }
        translateTransitions[0].setByX(300);
        translateTransitions[1].setByY(300);
        translateTransitions[2].setByX(-300);
        translateTransitions[3].setByY(-300);

        RotateTransition[] rotateTransitions = new RotateTransition[4];
        for (int i = 0; i < rotateTransitions.length; i++) {
            rotateTransitions[i] = new RotateTransition();
            rotateTransitions[i].setNode(this.movingRectangle);
            rotateTransitions[i].setDuration(Duration.millis(300));
            rotateTransitions[i].setByAngle(90);
            rotateTransitions[i].setCycleCount(1);
            rotateTransitions[i].setInterpolator(Interpolator.LINEAR);
        }

        SequentialTransition seqTransition = new SequentialTransition();
        seqTransition.setCycleCount(Timeline.INDEFINITE);
        for (int i = 0; i < 4; i++) {
            seqTransition.getChildren().add(translateTransitions[i]);
            seqTransition.getChildren().add(rotateTransitions[i]);
        }
        seqTransition.play();
    }

    /*private void animatePath() {
        Path path = new Path();
        path.getElements().add(new MoveTo(150, 150));
        path.getElements().add(new LineTo(450, 150));
        path.getElements().add(new LineTo(450, 450));
        path.getElements().add(new LineTo(150, 450));
        path.getElements().add(new ClosePath());

        PathTransition pathTransition = new PathTransition();
        pathTransition.setCycleCount(Timeline.INDEFINITE);
        pathTransition.setPath(path);
        pathTransition.setNode(this.movingRectangle);

        // Spelen met de lengte:
        pathTransition.setDuration(Duration.millis(4000));

        // Spelen met de vertraging aan het begin/einde:
        //pathTransition.setInterpolator(Interpolator.LINEAR);
        pathTransition.setInterpolator(Interpolator.EASE_BOTH);

        // Spelen met de orientatie bij bochten:
        pathTransition.setOrientation(PathTransition.OrientationType.ORTHOGONAL_TO_TANGENT);
        //pathTransition.setOrientation(PathTransition.OrientationType.NONE);

        // Terugkeren?
        //pathTransition.setAutoReverse(true);

        pathTransition.play();
    }

    private void animateSerie() {
        Path[] paths = new Path[4];
        paths[0] = new Path();
        paths[0].getElements().add(new MoveTo(150, 150));
        paths[0].getElements().add(new LineTo(450, 150));

        paths[1] = new Path();
        paths[1].getElements().add(new MoveTo(450, 150));
        paths[1].getElements().add(new LineTo(450, 450));

        paths[2] = new Path();
        paths[2].getElements().add(new MoveTo(450, 450));
        paths[2].getElements().add(new LineTo(150, 450));

        paths[3] = new Path();
        paths[3].getElements().add(new MoveTo(150, 450));
        paths[3].getElements().add(new LineTo(150, 150));

        PathTransition[] pathTransitions = new PathTransition[4];
        for (int i = 0; i < pathTransitions.length; i++) {
            pathTransitions[i] = new PathTransition();
            pathTransitions[i].setCycleCount(1);
            pathTransitions[i].setPath(paths[i]);
            pathTransitions[i].setNode(this.movingRectangle);
            pathTransitions[i].setDuration(Duration.millis(1000));
            pathTransitions[i].setInterpolator(Interpolator.EASE_BOTH);
        }

        RotateTransition[] rotateTransitions = new RotateTransition[4];
        for (int i = 0; i < rotateTransitions.length; i++) {
            rotateTransitions[i] = new RotateTransition();
            rotateTransitions[i].setCycleCount(1);
            rotateTransitions[i].setNode(this.movingRectangle);
            rotateTransitions[i].setDuration(Duration.millis(300));
            rotateTransitions[i].setInterpolator(Interpolator.LINEAR);
            rotateTransitions[i].setByAngle(90);
        }

        SequentialTransition sequentialTransition = new SequentialTransition();
        sequentialTransition.setCycleCount(Timeline.INDEFINITE);
        sequentialTransition.getChildren().add(pathTransitions[0]);
        sequentialTransition.getChildren().add(rotateTransitions[0]);
        sequentialTransition.getChildren().add(pathTransitions[1]);
        sequentialTransition.getChildren().add(rotateTransitions[1]);
        sequentialTransition.getChildren().add(pathTransitions[2]);
        sequentialTransition.getChildren().add(rotateTransitions[2]);
        sequentialTransition.getChildren().add(pathTransitions[3]);
        sequentialTransition.getChildren().add(rotateTransitions[3]);
        sequentialTransition.play();
    }*/
}
