package be.kdg.customtransition.view;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.scene.layout.BorderPane;
import javafx.scene.text.Font;

public class View extends BorderPane {
    private Label timeDisplay;
    private ProgressBar timeProgress;

    public View() {
        this.initialiseNodes();
        this.layoutNodes();
    }

    private void initialiseNodes() {
        this.timeDisplay = new Label();
        this.timeProgress = new ProgressBar();
    }

    private void layoutNodes() {
        this.timeDisplay.setFont(new Font(24.0));
        BorderPane.setAlignment(this.timeDisplay, Pos.CENTER);
        BorderPane.setMargin(this.timeDisplay, new Insets(10.0));
        this.setTop(this.timeDisplay);
        BorderPane.setAlignment(this.timeProgress, Pos.CENTER);
        BorderPane.setMargin(this.timeProgress, new Insets(10.0));
        this.setBottom(this.timeProgress);
    }

    Label getTimeDisplay() {
        return timeDisplay;
    }

    ProgressBar getTimeProgress() {
        return timeProgress;
    }
}
