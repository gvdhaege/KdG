package be.kdg.fly_uitbreiding.view;

public class FlyPresenter {
    private final FlyPane view;
    private final FlyTransition flyTransition;

    public FlyPresenter(FlyPane view) {
        this.view = view;
        this.flyTransition = new FlyTransition(this.view);
        this.addEventHandlers();
        this.updateView();
    }

    private void addEventHandlers() {
        this.view.getSpeedSlider().setOnMouseReleased(event -> updateView());
    }

    private void updateView() {
        this.flyTransition.stop();
        this.flyTransition.setCycleDuration(2.0 - this.view.getSpeedSlider().getValue());
        this.flyTransition.play();
    }
}
