package be.kdg.transition;

import be.kdg.transition.view.View;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class Main extends Application {
    @Override
    public void start(Stage primaryStage) {
        final View view = new View();
        primaryStage.setScene(new Scene(view));
        primaryStage.setTitle("Transition");
        primaryStage.show();
    }

    public static void main(String[] args) {
        Application.launch(args);
    }
}
