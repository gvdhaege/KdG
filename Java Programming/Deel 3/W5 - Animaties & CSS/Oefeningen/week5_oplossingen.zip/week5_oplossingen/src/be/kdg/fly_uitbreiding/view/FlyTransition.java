package be.kdg.fly_uitbreiding.view;

import javafx.animation.Interpolator;
import javafx.animation.Transition;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;
import javafx.util.Duration;

public class FlyTransition extends Transition {
    private static final double DEFAULT_DURATION = 450.0;

    private final FlyPane view;
    private int imageNumber;

    public FlyTransition(FlyPane view) {
        this.view = view;

        this.setCycleDuration(1.0);
        this.setAutoReverse(true);
        this.setCycleCount(INDEFINITE);
        this.setInterpolator(Interpolator.LINEAR);

        // Initialise at zero so that it starts drawing right away.
        this.imageNumber = 0;
    }

    public void setCycleDuration(double factor) {
        final Duration newDuration = Duration.millis(DEFAULT_DURATION * factor);
        this.setCycleDuration(newDuration);
    }

    @Override
    protected void interpolate(double frac) {
        final int newImageNumber = (int)(frac * 5 + 1);

        if (newImageNumber != this.imageNumber) {
            GraphicsContext gc = this.view.getCanvas().getGraphicsContext2D();
            gc.setFill(Color.BLUE);

            final double canvasWidth = this.view.getCanvas().getWidth();
            final double canvasHeight = this.view.getCanvas().getHeight();
            final WingManImage frame = WingManImage.get(newImageNumber);
            if (frame != null) {
                final double imageWidth = frame.getImage().getWidth();
                final double imageHeight = frame.getImage().getHeight();

                gc.fillRect(0.0, 0.0, canvasWidth, canvasHeight);
                gc.drawImage(frame.getImage(), (canvasWidth - imageWidth) / 2, (canvasHeight - imageHeight) / 2 + frame.getyOffset());
                this.imageNumber = newImageNumber;
            }
        }
    }
}
