package be.kdg.ssp.view;

import be.kdg.ssp.model.SSPEngine;
import javafx.animation.Transition;
import javafx.util.Duration;

public class SSPTransition extends Transition {
    private final SSPEngine model;
    private final SSPView view;

    public SSPTransition(SSPEngine model, SSPView view) {
        this.model = model;
        this.view = view;
        this.setCycleDuration(Duration.seconds(3));

        this.setOnFinished(event -> {
            this.view.getTextField().setText(this.model.play().getTekst());
            this.view.getTextField().setTextFill(SSPView.STANDARD_COLOR);
            this.view.getPlayButton().setDisable(false);
        });
    }

    @Override
    protected void interpolate(double frac) {
        this.view.getTextField().setText(String.valueOf((int)((1.0 - frac) * 3.0 + 1.0)));
    }
}
