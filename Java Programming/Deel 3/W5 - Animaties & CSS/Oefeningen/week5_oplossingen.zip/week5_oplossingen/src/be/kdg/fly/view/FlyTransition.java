package be.kdg.fly.view;

import javafx.animation.Interpolator;
import javafx.animation.Transition;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;
import javafx.util.Duration;

public class FlyTransition extends Transition {
    private final FlyPane view;
    private int previousImageNumber;

    public FlyTransition(FlyPane view) {
        this.view = view;
        this.previousImageNumber = 0; // Starten op 0 zodat er onmiddellijk getekend wordt

        this.setCycleDuration(Duration.millis(450));
        this.setAutoReverse(true);
        this.setCycleCount(INDEFINITE);
        this.setInterpolator(Interpolator.LINEAR);
    }

    @Override
    protected void interpolate(double frac) {
        final int newImageNumber = (int)(frac * 5 + 1);

        if (newImageNumber != this.previousImageNumber) {
            GraphicsContext gc = this.view.getCanvas().getGraphicsContext2D();
            gc.setFill(Color.BLUE);

            final double canvasWidth = this.view.getCanvas().getWidth();
            final double canvasHeight = this.view.getCanvas().getHeight();
            final WingManImage frame = WingManImage.get(newImageNumber);
            if (frame != null) {
                final double imageWidth = frame.getImage().getWidth();
                final double imageHeight = frame.getImage().getHeight();

                gc.fillRect(0.0, 0.0, canvasWidth, canvasHeight);
                gc.drawImage(frame.getImage(), (canvasWidth - imageWidth) / 2, (canvasHeight - imageHeight) / 2 + frame.getyOffset());
                this.previousImageNumber = newImageNumber;
            }
        }
    }
}
