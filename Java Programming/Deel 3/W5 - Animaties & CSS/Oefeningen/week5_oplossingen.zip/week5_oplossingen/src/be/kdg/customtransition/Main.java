package be.kdg.customtransition;

import be.kdg.customtransition.view.Presenter;
import be.kdg.customtransition.view.View;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class Main extends Application {
    @Override
    public void start(Stage primaryStage) {
        View view = new View();
        new Presenter(view);
        primaryStage.setScene(new Scene(view));
        primaryStage.setResizable(false);
        primaryStage.setTitle("Custom Transition");
        primaryStage.show();
    }

    public static void main(String[] args) {
        Application.launch(args);
    }
}
