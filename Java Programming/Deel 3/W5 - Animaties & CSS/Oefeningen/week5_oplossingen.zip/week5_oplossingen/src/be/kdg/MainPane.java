package be.kdg;

import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.Separator;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class MainPane extends GridPane {
    private static final double BUTTON_WIDTH = 250.0;

    public MainPane() {
        this.setPadding(new Insets(15.0, 15.0, 15.0, 15.0));
        this.setVgap(15.0);
        this.setHgap(15.0);

        final Button hypnose = new Button("Hypnose");
        hypnose.setMinWidth(BUTTON_WIDTH);
        hypnose.setOnAction(event ->
                Platform.runLater(() ->
                        new be.kdg.hypnose.Main().start(new Stage())
                )
        );
        this.add(hypnose, 0, 0);

        final Button ssp = new Button("Steen Schaar Papier");
        ssp.setMinWidth(BUTTON_WIDTH);
        ssp.setOnAction(event ->
                Platform.runLater(() ->
                        new be.kdg.ssp.Main().start(new Stage())
                )
        );
        this.add(ssp, 0, 1);

        final Button fly = new Button("Fly");
        fly.setMinWidth(BUTTON_WIDTH);
        fly.setOnAction(event ->
                Platform.runLater(() ->
                        new be.kdg.fly.Main().start(new Stage())
                )
        );
        this.add(fly, 0, 2);

        final Button flyUitbreiding = new Button("Fly Uitbreiding");
        flyUitbreiding.setMinWidth(BUTTON_WIDTH);
        flyUitbreiding.setOnAction(event ->
                Platform.runLater(() ->
                        new be.kdg.fly_uitbreiding.Main().start(new Stage())
                )
        );
        this.add(flyUitbreiding, 0, 3);

        final Button mainMenu = new Button("Main Menu");
        mainMenu.setMinWidth(BUTTON_WIDTH);
        mainMenu.setOnAction(event ->
                Platform.runLater(() ->
                        new be.kdg.mainmenu.Main().start(new Stage())
                )
        );
        this.add(mainMenu, 0, 4);

        this.add(new Separator(), 0, 5);

        final Button transition = new Button("Oefening Slides Transition");
        transition.setMinWidth(BUTTON_WIDTH);
        transition.setOnAction(event ->
                Platform.runLater(() ->
                        new be.kdg.transition.Main().start(new Stage())
                )
        );
        this.add(transition, 0, 6);

        final Button custom = new Button("Demo Slides Custom Transition");
        custom.setMinWidth(BUTTON_WIDTH);
        custom.setOnAction(event ->
                Platform.runLater(() ->
                        new be.kdg.customtransition.Main().start(new Stage())
                )
        );
        this.add(custom, 0, 7);
    }
}
