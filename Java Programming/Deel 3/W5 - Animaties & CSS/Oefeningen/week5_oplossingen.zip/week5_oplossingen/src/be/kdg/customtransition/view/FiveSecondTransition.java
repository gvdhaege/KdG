package be.kdg.customtransition.view;

import javafx.animation.Interpolator;
import javafx.animation.Timeline;
import javafx.animation.Transition;
import javafx.util.Duration;

public class FiveSecondTransition extends Transition {
    private final View view;

    public FiveSecondTransition(View view) {
        this.view = view;
        this.setCycleDuration(Duration.seconds(5));
        this.setCycleCount(Timeline.INDEFINITE);
        this.setInterpolator(Interpolator.LINEAR);
    }

    @Override
    protected void interpolate(double frac) {
        this.view.getTimeDisplay().setText(String.format("%.1f", frac * 5.0));
        this.view.getTimeProgress().setProgress(frac);
    }
}
