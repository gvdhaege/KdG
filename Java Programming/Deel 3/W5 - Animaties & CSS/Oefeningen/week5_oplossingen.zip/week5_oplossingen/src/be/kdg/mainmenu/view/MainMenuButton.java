package be.kdg.mainmenu.view;

import javafx.scene.control.Button;

public class MainMenuButton extends Button {
    public MainMenuButton(String text) {
        super(text);

        this.setMinSize(240.0, 80.0);
        this.setMaxSize(240.0, 80.0);

        this.getStyleClass().add("mainMenuButton");
    }
}
