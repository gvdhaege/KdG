package be.kdg.customtransition.view;

public class Presenter {
    private final View view;

    public Presenter(View view) {
        this.view = view;
        //this.addEventHandlers();
        this.updateView();
    }

    /*private void addEventHandlers() {
    }*/

    private void updateView() {
        FiveSecondTransition transition = new FiveSecondTransition(this.view);
        transition.play();
    }
}
