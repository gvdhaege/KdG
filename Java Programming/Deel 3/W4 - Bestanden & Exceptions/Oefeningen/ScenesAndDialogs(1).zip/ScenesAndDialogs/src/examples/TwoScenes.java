package examples;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class TwoScenes extends Application
{
    private Scene mainScene;
    private Scene secondScene;
    private Stage stage;

    @Override public void start(Stage stage)
    {
        this.stage   = stage;
        mainScene    = createMainScene();

        stage.setScene(mainScene);
        stage.show();
    }

    private Scene createMainScene()
    {
        VBox layout = new VBox(10);
        layout.setStyle("-fx-background-color: darkcyan; -fx-padding: 10;");
        layout.setAlignment(Pos.CENTER);

        Button button = new Button("Click Me.");
        button.setOnAction(new EventHandler<ActionEvent>()
        {
            @Override
            public void handle(ActionEvent event)
            {
                secondScene = createSecondScene();
                stage.setScene(secondScene);
                stage.show();
            }
        });
        layout.getChildren().add(button);

        Scene scene = new Scene(layout, 500, 300);
        return scene;
    }

    private Scene createSecondScene()
    {
        VBox layout = new VBox(10);
        layout.setStyle("-fx-background-color: indianred; -fx-padding: 10;");
        layout.setAlignment(Pos.CENTER);

        Button button = new Button("Click Me.");
        layout.getChildren().add(button);

        Scene scene = new Scene(layout, 200, 200);
        return scene;
    }
}
