

public class CharacterFile {
    private static final String BESTANDSNAAM = "leeftijden.txt";
    private static final int[] leeftijd = {
            24, 18, 34, 42
    };

    private static final String[] namen = {
            "Jan", "Els", "Jos", "Freya"
    };

    public static void main(String[] args) {
        schrijfBestand();
        leesBestand();
    }

    private static void schrijfBestand() {

    }

    private static void leesBestand() {

    }

}


