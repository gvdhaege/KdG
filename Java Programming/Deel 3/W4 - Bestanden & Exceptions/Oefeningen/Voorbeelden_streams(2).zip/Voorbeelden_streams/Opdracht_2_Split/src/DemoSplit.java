
public class DemoSplit {
    private static final String tekst = "Bietschhornhutte#2565#Lotschental, Blatten, Wallis\n" +
            "Tallihutte#1716#Furen, Innertkirchen, Engelberg, Berner Oberland\n" +
            "Capanna Cristalina#2349#Ossasco, Bedretto, Ticino\n" +
            "Rifugio Al Legn#1804#Brissago,Lago Maggiore,Ticino\n" +
            "Konkordiahutten#2850#Grosser Aletschgletscher, Berner Oberland\n" +
            "Monte Rosa Hutte#2795#Zermatt, Rotenboden, Wallis\n" +
            "Fletschhornhutte#3040#Saas Balen, Wallis\n" +
            "Cabane de Tracuit#3256#Zinal, Valais\n" +
            "Weisshornhutte#2932#Randa, Mattertal, Wallis";

    public static void main(String[] args) {

    }
}
