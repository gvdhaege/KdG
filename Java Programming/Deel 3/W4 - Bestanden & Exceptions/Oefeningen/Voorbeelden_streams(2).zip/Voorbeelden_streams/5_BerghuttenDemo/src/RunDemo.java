/**
 * Mark Goovaerts
 * 19/02/2015
 */
public class RunDemo {
    public static void main(String[] args) {
        new DemoBerghutten();
    }
}
