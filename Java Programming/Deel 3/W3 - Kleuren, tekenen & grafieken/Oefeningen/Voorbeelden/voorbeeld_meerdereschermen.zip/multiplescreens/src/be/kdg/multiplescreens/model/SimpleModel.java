package be.kdg.multiplescreens.model;

/**
 * Created by vochtenh on 17/02/2016.
 */
public class SimpleModel {
    //DUMMY MODEL, IN DIT VOORBEELD VOLLEDIG LEEG...
}
