package utilities;

public class Globals
{
    public enum Direction {HORIZONTAL, VERTICAL};
}
