package be.kdg.engels.view;

import javafx.scene.chart.PieChart;
import javafx.scene.layout.BorderPane;

public class EngelsView extends BorderPane {

    public EngelsView() {
        this.initialiseNodes();
        this.layoutNodes();
    }

    private void initialiseNodes() {

    }

    private void layoutNodes() {

    }

}
