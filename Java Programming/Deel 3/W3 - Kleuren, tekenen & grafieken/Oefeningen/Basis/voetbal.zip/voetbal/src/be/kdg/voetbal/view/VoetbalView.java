package be.kdg.voetbal.view;

import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.layout.BorderPane;

public class VoetbalView extends BorderPane {


    public VoetbalView() {
        this.initialiseNodes();
        this.layoutNodes();
    }

    private void initialiseNodes() {

    }

    private void layoutNodes() {

    }


}
