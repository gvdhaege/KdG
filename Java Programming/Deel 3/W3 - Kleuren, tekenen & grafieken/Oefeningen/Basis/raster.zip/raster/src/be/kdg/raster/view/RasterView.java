package be.kdg.raster.view;

import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.layout.BorderPane;

public class RasterView extends BorderPane {
    public RasterView() {
        this.initialiseNodes();
        this.layoutNodes();
    }

    private void initialiseNodes() {

    }

    private void layoutNodes() {

    }

    void drawRaster(int rows, int columns) {

    }
}
