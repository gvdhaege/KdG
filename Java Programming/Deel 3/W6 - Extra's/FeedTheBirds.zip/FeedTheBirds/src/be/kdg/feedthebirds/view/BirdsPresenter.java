package be.kdg.feedthebirds.view;


import javafx.event.EventHandler;
import javafx.scene.image.ImageView;
import javafx.scene.input.*;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;

import java.io.File;

public class BirdsPresenter {
    private BirdsView view;
    private Media burpSound;

    public BirdsPresenter(BirdsView view) {
        this.view = view;
        addEventHandlers();
        burpSound = new Media(new File("res/burp.wav").toURI().toString());
    }

    //Check de tutorial op: https://docs.oracle.com/javase/8/javafx/events-tutorial/drag-drop.htm
    private void addEventHandlers() {
        //1) voeg OnDragDetected EventHandler toe aan de source (imageviews met wormen):
        EventHandler<MouseEvent> dragDetected = new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                ImageView source = (ImageView) event.getSource();
                //Het image wordt in het DragBoard gestopt tijdens de transfer
                Dragboard dragboard = source.startDragAndDrop(TransferMode.MOVE);
                ClipboardContent content = new ClipboardContent();
                content.putImage(source.getImage());
                dragboard.setContent(content);
                event.consume();
            }
        };
        for (int i=0;i<5;i++) {
            view.getLeftLabels()[i].setOnDragDetected(dragDetected);
            view.getRightLabels()[i].setOnDragDetected(dragDetected);
        }
        //2) voeg OnDragOver EventHandler toe aan het target (imageview met vogelnest)
        //   dit zorgt ervoor dat het target de worm kan accepteren.
        ImageView target = view.getIvBirds();
        target.setOnDragOver(new EventHandler<DragEvent>() {
            public void handle(DragEvent event) {
                if (event.getGestureSource() != target &&
                        event.getDragboard().hasImage()) {
                    event.acceptTransferModes(TransferMode.MOVE);
                }
                event.consume();
            }
        });
        //3) voeg OnDragDropped EventHandler toe aan target
        //   deze wordt uitgevoerd zodra de drop gebeurt.
        //   We spelen een geluidje en geven door dat de drop gelukt is
        target.setOnDragDropped(new EventHandler<DragEvent>() {
            public void handle(DragEvent event) {
                Dragboard db = event.getDragboard();
                boolean success = false;
                if (db.hasImage()) {
                    new MediaPlayer(burpSound).play();
                    success = true;
                }
                event.setDropCompleted(success);
                event.consume();
            }
        });
        //4) voeg OnDragDone EventHandlers toe aan sources
        //   we verwijderen de image van de imageview
        EventHandler<DragEvent> dragDone = new EventHandler<DragEvent>() {
            public void handle(DragEvent event) {
                ImageView source = (ImageView) event.getSource();
                if (event.getTransferMode() == TransferMode.MOVE) {
                    source.setImage(null);
                }
                event.consume();
            }
        };
        for (int i=0;i<5;i++) {
            view.getLeftLabels()[i].setOnDragDone(dragDone);
            view.getRightLabels()[i].setOnDragDone(dragDone);
        }
    }
}
