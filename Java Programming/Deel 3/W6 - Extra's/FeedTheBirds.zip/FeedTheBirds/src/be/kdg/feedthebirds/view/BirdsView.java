package be.kdg.feedthebirds.view;

import javafx.geometry.Insets;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;

public class BirdsView extends BorderPane {
    private ImageView ivBirds;
    private ImageView[] leftLabels = new ImageView[5];
    private ImageView[] rightLabels = new ImageView[5];

    public BirdsView() {
        initialiseNodes();
        layoutNodes();
    }

    private void initialiseNodes() {
        ivBirds = new ImageView(new Image("birds.gif"));
        for (int i=0;i<5;i++) {
            leftLabels[i] = new ImageView(new Image("worm.gif"));
            rightLabels[i] = new ImageView(new Image("worm.gif"));
        }
    }

    private void layoutNodes() {
        VBox leftPane = new VBox(leftLabels);
        leftPane.setSpacing(20);
        VBox rightPane = new VBox(rightLabels);
        rightPane.setSpacing(20);
        for (int i=0;i<5;i++) {
            VBox.setMargin(leftLabels[i],new Insets(20));
            VBox.setMargin(rightLabels[i],new Insets(20));
        }
        setLeft(leftPane);
        setRight(rightPane);
        setCenter(ivBirds);
        setStyle("-fx-background-image: url(trees.jpg);");
    }

    ImageView getIvBirds() {
        return ivBirds;
    }

    ImageView[] getLeftLabels() {
        return leftLabels;
    }

    ImageView[] getRightLabels() {
        return rightLabels;
    }
}
